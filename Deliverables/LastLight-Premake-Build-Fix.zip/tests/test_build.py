import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('lastlight_build', ROOT / 'scripts/build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)


class BuildEnvironmentTests(unittest.TestCase):
    def test_existing_developer_environment_skips_vswhere(self):
        env = {'PATH': 'compiler-bin', 'INCLUDE': 'include-path', 'LIB': 'lib-path', 'VSCMD_ARG_TGT_ARCH': 'x64'}
        with patch.dict(build.os.environ, env, clear=True), patch.object(build.shutil, 'which', return_value='cl.exe'), patch.object(build, 'find_vcvars') as lookup:
            self.assertEqual(build.vs_environment(), env)
            lookup.assert_not_called()

    def test_visual_studio_supplied_tools_path_with_spaces(self):
        with tempfile.TemporaryDirectory(prefix='Visual Studio ') as directory:
            vcvars = Path(directory) / 'VC/Auxiliary/Build/vcvars64.bat'
            vcvars.parent.mkdir(parents=True)
            vcvars.write_text('@echo off')
            output = 'Path=compiler-bin\nInclude=include-path\nLib=lib-path\nVSCMD_ARG_TGT_ARCH=x64\n'
            with patch.object(build.subprocess, 'check_output', return_value=output) as call, patch.object(build.shutil, 'which', return_value='cl.exe'):
                env = build.vs_environment(vcvars)
            self.assertEqual(env['INCLUDE'], 'include-path')
            self.assertEqual(env['PATH'], 'compiler-bin')
            self.assertNotIn('Path', env)
            command = call.call_args.args[0]
            self.assertEqual(command[1:4], ['/d', '/s', '/c'])
            self.assertIn('"' + str(vcvars) + '"', command[4])
            self.assertIn('>nul && set', command[4])

    def test_preview_and_build_tools_are_not_filtered_out(self):
        with tempfile.TemporaryDirectory(prefix='VS installations ') as directory:
            root = Path(directory)
            locator = root / 'Microsoft Visual Studio/Installer/vswhere.exe'
            locator.parent.mkdir(parents=True)
            locator.write_text('locator placeholder')
            install = root / 'Build Tools Preview'
            script = install / 'VC/Auxiliary/Build/vcvars64.bat'
            script.parent.mkdir(parents=True)
            script.write_text('tools placeholder')
            response = json.dumps([{'installationPath': str(install), 'installationVersion': '17.14.1', 'isPrerelease': True}])
            with patch.object(build.subprocess, 'check_output', return_value=response) as call:
                result = build.find_vcvars(env={'ProgramFiles(x86)': str(root)})
            self.assertEqual(result, script)
            args = call.call_args.args[0]
            self.assertIn('-prerelease', args)
            self.assertIn('*', args)
            self.assertNotIn('-version', args)
            self.assertNotIn('-requires', args)

    def test_missing_compiler_is_reported_without_claiming_premake_supplies_it(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(RuntimeError, 'Premake does not include a compiler'):
                build.find_vcvars(env={'ProgramFiles(x86)': directory})

    def test_x86_environment_requires_x64_initialization(self):
        with patch.object(build.shutil, 'which', return_value='cl.exe'):
            self.assertFalse(build.configured_msvc({'PATH': 'bin', 'LIB': 'lib', 'INCLUDE': 'include', 'VSCMD_ARG_TGT_ARCH': 'x86'}))


if __name__ == '__main__':
    unittest.main()
