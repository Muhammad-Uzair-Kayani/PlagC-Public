@echo off
setlocal
pushd "%~dp0" || exit /b 1
call BuildGame.bat %*
set "result=%errorlevel%"
popd
exit /b %result%
