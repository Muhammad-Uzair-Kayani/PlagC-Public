# Executed validation — November 14, 2026

## Source build

Godot 4.5.1-stable at f62fdbde15035c5576dad93e586201f4d41ef0cb was cloned
and compiled from source with the external built-in C++ module. Linux x86_64,
SCons 4.11.1, template_debug, Compatibility renderer, GodotPhysics3D and native
navigation. The validation build uses the headless display backend. The Godot
submodule stayed clean. The first full engine build took about 16 minutes on
this three-CPU environment; that is not a Windows/8 GB build-time estimate.

## Executed checks

- Engine-neutral C++ domain tests: cooldowns/ammo, timed reload/cancel, healing,
  timed revive/single resource consumption, bleed-out, dead/downed action
  rejection, social updates, normalized directional/locomotion weights.
- Four Python groups: archive path safety, PCK directory/hash/footer format,
  neural masks/serialization, real loopback service batching/duplicate rejection.
- Actual source-built engine: capsule/world collision and grounding, blocked
  shot followed by a valid shot, reload accounting, distinct-actor co-op gate,
  semantically restored saves with malformed save rejection, Python inference
  with zero transport fallback, explicit recovery from a missing Python process, solo bypass and full-team mission completion.
- Engine-loaded separate PCK and unsigned appended-PCK executable both ran the
  native collision test successfully. These checks used the actual engine,
  not a mock pack reader alone.
- Submodule setup registered a real 160000 gitlink at the pinned revision.

The authored solo completed in about 40.78 simulated seconds. Default seeded
team autoplay completed in about 31.70 seconds with four survivors extracted.
The gate test increased native navigation polygons from 147 to 156 after
opening/rebaking. Positive native test logs contained no engine warnings/errors after
fixing the navigation height convention and initializing the script cache. The
intentional missing-process test logs its expected launch error, records one
fallback, and continues successfully.

An integration failure was fixed during development: Recast's generated floor
was at y=0.5 while the controller's origin was at foot height, so agents could
stall at a vertically offset first waypoint. The current test world explicitly
sets the corresponding agent path-height offset. A different imported map
requires verifying this coordinate convention and navigation settings again.

## Neural pipeline evidence

A real two-genome, one-generation run evaluated eight Godot episodes on seeds
101–104 and wrote population/RNG/checkpoint data. All eight evaluations used
Python without fallback. One checkpoint champion was evaluated on separate
seeds 901–904, compared against authored and constrained-random intentions.
All three controllers extracted 80% of survivors in this small test. Neural
mean completion time was about 31.12 seconds, rules 30.22, random 34.19.
This does not demonstrate improvement over rules or learned cooperation.
The generated sample CSV/JSON and evaluated candidate are bundled; full logs
and population artifacts remain generated output outside source control.

## Remaining gates

- Windows/MSVC compilation and windowed rendering have not been executed in
  this Linux environment. The Windows build configuration selects VS2022,
  x86_64, GUI subsystem and static C++ runtime; target-machine testing is still
  required. No measured Vega FPS or 8 GB runtime-memory claim is made.
- Large UAL/pistol/map uploads could not be transferred under the 32 MiB tool
  limit. Their actual import/retargeting/map integration remains blocked. The
  source prototype uses labelled procedural visuals and a test level.
- Imported AnimationPlayer clip bindings are a verified-asset integration hook,
  not a completed retargeted UAL blend-tree implementation. Weapon sockets,
  imported map collision, animation events, audio and final presentation need
  the accessible asset files and a visual validation pass.
- Prototype saves preserve gameplay state but do not serialize Godot contact
  caches or promise bit-exact physics replay across machines/engine versions.

## Windows setup recovery update

A Windows user log showed MAX_PATH failures while checking out Godot's long
Mono test filenames, followed by an incomplete-checkout dirty-state error.
Setup now passes core.longpaths=true to all Git commands and inherited clone
helpers, persists the local setting, and offers explicit missing-file repair.
It reconstructs an empty index without overwriting existing working files,
restores absent paths using literal NUL-delimited pathspecs, and preserves
existing edits/staged changes. Nine Python tests passed, including real local
Git fixtures for interrupted index recovery and resume without recloning.
Windows/MSVC execution still requires validation on the target machine.
