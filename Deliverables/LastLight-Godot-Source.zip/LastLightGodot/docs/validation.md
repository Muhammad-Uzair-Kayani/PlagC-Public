# Executed validation

## Native Windows acceptance

The complete acceptance job is recorded at:
https://github.com/Muhammad-Uzair-Kayani/PlagC-Public/actions/runs/43598877158

Environment: native Windows Server 2022 runner, Visual Studio 2022/MSVC x64,
Python 3.12, SCons 4.11.1, Godot 4.5.1 commit
`f62fdbde15035c5576dad93e586201f4d41ef0cb`. The source directory contains spaces.
This verifies compilation and headless Windows execution; it is not a Windows
10/Vega GPU rendering or frame-rate measurement.

The acceptance script, `tests/windows_full_build.py`, performs these checks:

- Setup registers and checks out the pinned Godot submodule and installs the
  project-local build tools.
- A real C++/Windows SDK program is compiled, linked with a compiled resource,
  and executed. The complete Godot build graph is also configured.
- The full Godot engine and external C++ game module compile and link together
  as a Windows executable. The first cold CI compile took about 21 minutes
  with four jobs; later cached builds took under 30 seconds. These timings
  describe the CI machine, not the user's hardware. The normal build defaults
  to one job for an 8 GB machine.
- All 29 Python/tool/native regression tests pass. Native tests run real cmd,
  the actual batch wrapper, C++ domain tests, and a SCons C++/resource build
  with Visual Studio installation enumeration deliberately disabled.
- Premake generates the VS2022 solution, then MSBuild builds that actual
  generated solution through BuildFromVS.bat.
- Nine real Windows engine cases pass: collision/floor recovery, combat and
  gate LOS, cooperative gate activation, save/load validation, Python policy
  transport, missing-Python fallback, Python process-exit fallback, solo mission
  completion, and team mission completion.
- A two-candidate, one-generation training smoke run evaluates eight real
  Godot episodes. Evaluation exercises neural, authored and constrained-random
  controllers on twelve held-out episodes. Transport fallback rejects neural
  episodes; the successful run therefore exercises actual Python responses.
- The packaged Windows executable launches without a source-project path,
  loads its separate PCK, and runs both physics and Python-service checks.
  An executable with an appended PCK also launches successfully.
- PE headers report the Windows GUI subsystem. The dependency check rejects
  dynamic MSVC C++ runtime imports (vcruntime140, msvcp140, ucrtbase.dll).

Build and test logs, executable headers/dependencies, and JSON gameplay reports
are retained in the workflow's `LastLight-Windows-Validation` artifact. The
source ZIP includes the test procedure; engine binaries and generated reports
are excluded from the source distribution.

## Local Linux regression

All 24 portable Python checks pass; five Windows-only checks are skipped on
Linux and executed in Windows acceptance. The standalone C++ domain suite and
all nine source-built Godot integration cases pass. The Python process-exit
case continues through authored fallback without recursion or stale socket
messages. The normal positive cases produce no engine warnings/errors; the
missing-executable case deliberately triggers the expected process-launch
failure.

The latest local training smoke run evaluated eight episodes without Python
fallback and wrote its model/checkpoint. Twelve held-out episodes exercised
all three controller choices. This establishes pipeline operation, not a
converged or improved neural controller. The default game uses authored AI.

## Corrections covered by this audit

Godot previously selected MinGW when SCons could not enumerate a working VS
installation. The project-owned SCons entry point now uses the initialized
MSVC environment, preserves compiler/SDK paths and supplies tool-family
metadata. The engine submodule and installed SCons files are not patched.
Actual compilation preflights replace assumptions about installer metadata.

The working IDE tools path is remembered locally, and standard existing VS
locations are checked when installer registration is absent. Setup canonicalizes
Windows short-path aliases before comparing repository roots. Existing long-path
checkout and missing-file repair checks preserve local edits.

Python shutdown detaches its peer before attempting a final message, preventing
recursive shutdown on write failure. It clears partial messages, and avoids
re-probing an already reaped process. Test runners delete stale result files;
Windows gameplay checks isolate application data from the player's saves.
Complete build output is retained in `reports/godot-build.log` as well as the
Visual Studio Output pane.

## Remaining target-machine checks

The bundled game still uses labelled procedural actors, weapons and a test
level. The large UAL, pistol and map uploads were not imported; see
[assets.md](assets.md). Imported animation bindings are an integration hook,
not a verified retargeted UAL animation tree. Final assets, animation events,
audio/presentation, real windowed rendering and performance on the target Vega
iGPU still require their own asset/visual acceptance pass.

Saves preserve gameplay state, not Godot contact caches or bit-exact physics
replay across platforms or engine versions.
