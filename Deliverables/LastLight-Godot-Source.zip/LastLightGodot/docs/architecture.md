# Engine/client boundary

Godot source is an unchanged pinned gitlink. SCons `custom_modules` compiles the
external modules/last_light directory into the engine executable. This is not a
GDExtension and the client does not use a separately built game DLL.

The game node creates the low-end test scene, CharacterBody3D actors, colliders,
NavigationRegion3D and agents, SpringArm3D camera, lights, UI and procedural rig.
Physics runs at 60 Hz, AI at 5 Hz and the HUD at 10 Hz; drawing is capped at 30
FPS by default. The API boundary is actual movement/physics queries, not the
old console grid's authoritative movement. Navigation is baked from the same
static colliders and rebaked when the cooperative gate opens.

`domain.h` is engine-neutral C++: inventory, health/life states, timed actions,
cooldowns, social evidence and normalized blend parameters. Godot spatial code
validates range, LOS, actual collision hits and revival position. Node state
and inventory remain authoritative in C++; Python only returns intentions.

Python is a persistent loopback TCP process with bounded NDJSON messages,
request/episode correlation and per-process handshake. It has no engine object
references. Gameplay can continue using the authored controller if transport
fails. In accelerated headless evaluation the simulation waits for a pending
policy reply; interactive play remains asynchronous. Do not claim identical
physics trajectories across machines or Godot versions from a shared seed.

Saves include world/objective flags, actor poses/velocities, action timers,
inventory, blend weights and social memories. Validation builds a candidate
state before applying it. Physics contact caches/navigation internals are not
serialized, so save continuation is semantically valid, not bit-exact replay
of a physics engine. The source pin is part of compatibility expectations.

`game/content/assets.json` deliberately has no unverified scene bindings. The
procedural rig demonstrates motion and calculated blend values. Imported
characters can select named AnimationPlayer clips with crossfades. A complete
retargeted UAL rig, weapon sockets and a final map/collision/navmesh are pending
asset access and validation; they are not silently simulated by filenames.
