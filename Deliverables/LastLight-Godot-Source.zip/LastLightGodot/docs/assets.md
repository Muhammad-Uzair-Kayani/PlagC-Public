# Asset integration gate

The original UAL, pistol and map packages are not bundled here. Their uploads
exceeded this execution environment's per-file transfer limit. The sword ZIP
was inspected: source/Sword.rar and texture images, including a DirectX normal
map. The nested RAR was listed and contains Sword_Low_Done.FBX and textures. Its geometry, import result and licence were not verified. Do not infer import,
retargeting, quality or redistribution permission from a filename.

Place your licensed originals outside Git, for example assets/incoming/.

```cmd
.tools\venv\Scripts\python.exe scripts\prepare_assets.py --ual "assets\incoming\Universal Animation Library 2[Standard].zip" --sword "assets\incoming\sword.zip" --pistol "assets\incoming\9mm-pistol.zip" --map "assets\incoming\halo-3-map-retextured-and-remodelled-4k-pbr.zip" --texture-size 1024
BuildGame.bat --editor --jobs 1
```

The preparation tool rejects traversal/links, never executes archive content,
limits expanded size, caps texture dimensions and flips the green channel of
textures explicitly named DirectX normal maps. It does not silently guess a
skeleton or select a map as collision geometry. Nested RARs are reported for
manual extraction with your archive tool before running the custom editor.

After import, inspect the skeleton/rest pose, clip names, unit scale, model
forward axis, weapon sockets, loop flags and normal orientation. Bind a verified
character scene and animation names in game/content/assets.json. Procedural
visuals remain active until a verified scene is bound. A supplied map needs
collision and navigation authored to match its playable section, mission
positions and solo route; do not place arbitrary map graphics over unrelated
procedural collision and call it integrated.

For Vega integrated graphics, use a small playable section, 512–1024 textures,
simple materials, no dynamic shadows initially, and at most two active bots.
Retargeted locomotion should be in-place; the character controller is the sole
movement authority. Root motion must not move the character a second time.
