extends Control

var state: Dictionary = {}

func _draw() -> void:
    if state.is_empty(): return
    var rows: Array = state.get("map_rows", [])
    if rows.is_empty(): return
    var cell := minf(size.x / 21.0, size.y / 17.0)
    var offset := (size - Vector2(21,17)*cell)*0.5
    draw_rect(Rect2(offset, Vector2(21,17)*cell), Color("101b23"))
    for z in range(rows.size()):
        for x in range(str(rows[z]).length()):
            if str(rows[z])[x] == "#":
                draw_rect(Rect2(offset+Vector2(x,z)*cell,Vector2.ONE*cell),Color("47515c"))
    var objective: Vector2 = state.get("objective_position", Vector2.ZERO)
    draw_circle(offset+(objective/2.0+Vector2.ONE*0.5)*cell,4,Color("f5be64"))
    for item in state.get("items", []):
        var p: Vector2=item["position"]
        draw_circle(offset+(p/2.0+Vector2.ONE*0.5)*cell,2,Color("6cd2e0"))
    for actor in state.get("team", []):
        if not actor.get("known", false): continue
        var p: Vector2=actor["position"]
        var color := Color("f1f6f7") if actor["id"]==1 else Color("69c2b5")
        if actor.get("health",100)<=0: color=Color("e17474")
        draw_circle(offset+(p/2.0+Vector2.ONE*0.5)*cell,3,color)
