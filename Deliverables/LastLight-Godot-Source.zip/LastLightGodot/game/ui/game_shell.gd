extends LastLightGame

const GOLD := Color("edba70")
const TEAL := Color("67c6b7")
const INK := Color("111b24")
const TEXT := Color("ecf0ef")
const MUTED := Color("9aabb7")
const MiniMap = preload("res://ui/minimap.gd")

var canvas: CanvasLayer
var root: Control
var modal: PanelContainer
var modal_body: VBoxContainer
var shade: ColorRect
var hud_root: Control
var objective_label: Label
var objective_detail: Label
var stat_label: Label
var health_bar: ProgressBar
var stamina_bar: ProgressBar
var hunger_bar: ProgressBar
var ammo_label: Label
var prompt_label: Label
var toast_label: Label
var action_label: Label
var squad_rows: Array[Label] = []
var debug_label: Label
var map_control: Control
var state: Dictionary = {}
var visible_mode := ""
var panel_screen := ""
var refresh := 0.0
var selected_bots := 2
var sensitivity := 0.0025
var invert_y := false
var resolution := 0
var volume := 0.6
var fps_cap := 30
var last_sound_event := -1
var audio: AudioStreamPlayer
var sounds: Dictionary = {}
var last_player_health := 100
var flash: ColorRect
var modal_status: Label
var crosshair: Label
var tutorial_tip: Label

func _ready() -> void:
    call_deferred("_build_frontend")

func _style(color: Color, radius: int = 10, border: Color = Color.TRANSPARENT) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color=color
    style.corner_radius_top_left=radius
    style.corner_radius_top_right=radius
    style.corner_radius_bottom_left=radius
    style.corner_radius_bottom_right=radius
    style.border_color=border
    style.set_border_width_all(1 if border.a>0 else 0)
    style.content_margin_left=18
    style.content_margin_right=18
    style.content_margin_top=14
    style.content_margin_bottom=14
    return style

func _label(text: String, font_size: int = 16, color: Color = TEXT) -> Label:
    var label := Label.new()
    label.text=text
    label.add_theme_font_size_override("font_size",font_size)
    label.add_theme_color_override("font_color",color)
    return label

func _button(text: String, callback: Callable, primary: bool = false) -> Button:
    var button := Button.new()
    button.text=text
    button.custom_minimum_size=Vector2(0,40)
    button.add_theme_font_size_override("font_size",16)
    for state_name in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]:
        button.add_theme_color_override(state_name,INK if primary else TEXT)
    button.add_theme_stylebox_override("normal",_style(GOLD if primary else Color("24333f"),6))
    button.add_theme_stylebox_override("hover",_style(Color("f5ce94") if primary else Color("334b58"),6))
    button.add_theme_stylebox_override("pressed",_style(TEAL if primary else Color("3b5a66"),6))
    button.pressed.connect(callback)
    return button

func _panel(parent: Node, anchor: int, position: Vector2, minimum: Vector2) -> PanelContainer:
    var panel := PanelContainer.new()
    parent.add_child(panel)
    panel.set_anchors_and_offsets_preset(anchor)
    panel.offset_left=position.x
    panel.offset_top=position.y
    panel.offset_right=position.x+minimum.x
    panel.offset_bottom=position.y+minimum.y
    panel.custom_minimum_size=minimum
    panel.add_theme_stylebox_override("panel",_style(Color(INK,0.9),9,Color("344753")))
    panel.mouse_filter=Control.MOUSE_FILTER_IGNORE
    return panel

func _build_frontend() -> void:
    if Engine.is_editor_hint(): return
    attach_frontend()
    if DisplayServer.get_name()=="headless":return
    _load_options()
    canvas=CanvasLayer.new()
    canvas.layer=20
    add_child(canvas)
    root=Control.new()
    canvas.add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter=Control.MOUSE_FILTER_IGNORE
    var theme := Theme.new()
    theme.default_font_size=16
    root.theme=theme
    hud_root=Control.new()
    root.add_child(hud_root)
    hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud_root.mouse_filter=Control.MOUSE_FILTER_IGNORE
    _build_hud()
    shade=ColorRect.new()
    root.add_child(shade)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color=Color(0.025,0.045,0.065,0.79)
    modal=PanelContainer.new()
    root.add_child(modal)
    modal.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    modal.custom_minimum_size=Vector2(440,0)
    modal.add_theme_stylebox_override("panel",_style(Color("15232e"),14,Color("3c4d58")))
    modal_body=VBoxContainer.new()
    modal_body.add_theme_constant_override("separation",10)
    modal.resized.connect(_layout)
    modal.add_child(modal_body)
    audio=AudioStreamPlayer.new()
    add_child(audio)
    audio.volume_db=linear_to_db(maxf(volume,0.001))
    for name in ["pickup","radio","hurt","shot","gate","revive"]:
        var path: String = "res://audio/"+str(name)+".wav"
        if FileAccess.file_exists(path): sounds[name]=AudioStreamWAV.load_from_buffer(FileAccess.get_file_as_bytes(path))
    get_viewport().size_changed.connect(_layout)
    get_window().focus_exited.connect(func():
        if state.get("mode","")=="playing":game_command("pause"))
    root.move_child(toast_label,root.get_child_count()-1)
    _layout()
    _refresh_state()

func _build_hud() -> void:
    var objective_panel := _panel(hud_root,Control.PRESET_TOP_LEFT,Vector2(16,16),Vector2(350,74))
    var objective_box := VBoxContainer.new()
    objective_panel.add_child(objective_box)
    objective_box.add_child(_label("LAST LIGHT   /   SURVIVAL",12,GOLD))
    objective_label=_label("Recover the yard key",20)
    objective_box.add_child(objective_label)
    objective_detail=_label("",13,MUTED)
    objective_box.add_child(objective_detail)
    var stats := _panel(hud_root,Control.PRESET_BOTTOM_LEFT,Vector2(16,-126),Vector2(320,110))
    var stats_box := VBoxContainer.new()
    stats.add_child(stats_box)
    stat_label=_label("YOU",13,GOLD)
    stats_box.add_child(stat_label)
    health_bar=_bar(stats_box,Color("d98983"))
    stamina_bar=_bar(stats_box,TEAL)
    hunger_bar=_bar(stats_box,GOLD)
    var ammo := _panel(hud_root,Control.PRESET_BOTTOM_RIGHT,Vector2(-194,-105),Vector2(178,89))
    var ammo_box := VBoxContainer.new()
    ammo.add_child(ammo_box)
    ammo_label=_label("UNARMED",20,GOLD)
    ammo_box.add_child(ammo_label)
    action_label=_label("",13,MUTED)
    ammo_box.add_child(action_label)
    var squad := _panel(hud_root,Control.PRESET_TOP_RIGHT,Vector2(-240,16),Vector2(224,170))
    var squad_box := VBoxContainer.new()
    squad.add_child(squad_box)
    squad_box.add_child(_label("SURVIVORS",12,GOLD))
    for i in range(4):
        var row := _label("",13)
        row.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
        squad_box.add_child(row)
        squad_rows.append(row)
    map_control=MiniMap.new()
    hud_root.add_child(map_control)
    map_control.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
    map_control.offset_left=-210
    map_control.offset_right=-20
    map_control.offset_top=206
    map_control.offset_bottom=360
    map_control.custom_minimum_size=Vector2(190,154)
    map_control.size=Vector2(190,154)
    map_control.mouse_filter=Control.MOUSE_FILTER_IGNORE
    prompt_label=_label("",17,GOLD)
    hud_root.add_child(prompt_label)
    prompt_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    prompt_label.offset_left=-220
    prompt_label.offset_right=220
    prompt_label.offset_top=-162
    prompt_label.offset_bottom=-134
    prompt_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    toast_label=_label("",14,TEXT)
    toast_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    root.add_child(toast_label)
    toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
    toast_label.offset_left=-220
    toast_label.offset_right=220
    toast_label.offset_top=115
    toast_label.offset_bottom=155
    toast_label.custom_minimum_size=Vector2(400,0)
    toast_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    crosshair = _label("·",32,Color(1,1,1,.8))
    hud_root.add_child(crosshair)
    crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    crosshair.offset_left=-6
    crosshair.offset_right=6
    crosshair.offset_top=-22
    crosshair.offset_bottom=22
    debug_label=_label("",13,TEAL)
    hud_root.add_child(debug_label)
    debug_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
    debug_label.offset_left=16
    debug_label.offset_right=600
    debug_label.offset_top=-212
    debug_label.offset_bottom=-165
    tutorial_tip=_label("WASD Move   ·   E Interact   ·   RMB Aim   ·   LMB Attack   ·   Esc Menu",12,MUTED)
    hud_root.add_child(tutorial_tip)
    tutorial_tip.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    tutorial_tip.offset_left=-360
    tutorial_tip.offset_right=360
    tutorial_tip.offset_top=-27
    tutorial_tip.offset_bottom=-5
    tutorial_tip.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    flash=ColorRect.new()
    hud_root.add_child(flash)
    flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    flash.color=Color(0.7,0.08,0.06,0)
    flash.mouse_filter=Control.MOUSE_FILTER_IGNORE

func _bar(parent: Node, color: Color) -> ProgressBar:
    var bar := ProgressBar.new()
    bar.custom_minimum_size=Vector2(280,11)
    bar.show_percentage=false
    var background:=StyleBoxFlat.new()
    background.bg_color=Color("26343e")
    background.set_corner_radius_all(3)
    var fill:=StyleBoxFlat.new()
    fill.bg_color=color
    fill.set_corner_radius_all(3)
    bar.add_theme_stylebox_override("background",background)
    bar.add_theme_stylebox_override("fill",fill)
    parent.add_child(bar)
    return bar

func _layout() -> void:
    if not is_instance_valid(root) or not is_instance_valid(modal):return
    var available := get_viewport().get_visible_rect().size
    var card_scale := minf(1.0,minf((available.x-32)/maxf(modal.size.x,1),(available.y-32)/maxf(modal.size.y,1)))
    modal.scale=Vector2.ONE*card_scale
    modal.position=(available-modal.size*card_scale)*.5

func _clear_modal() -> void:
    for child in modal_body.get_children():
        modal_body.remove_child(child)
        child.queue_free()

func _title(eyebrow: String, title: String, body: String) -> void:
    modal_body.add_child(_label(eyebrow,12,GOLD))
    modal_body.add_child(_label(title,34))
    var description := _label(body,14,MUTED)
    description.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    description.custom_minimum_size.x=390
    modal_body.add_child(description)

func _show_panel(screen: String) -> void:
    panel_screen=screen
    _clear_modal()
    if screen=="menu":
        _title("ADAPTIVE SOCIAL SURVIVAL","LAST LIGHT","Five survivors. One way out. Find supplies, recover the key and restore the signal. Cooperation can open the shortcut; a solo route always remains.")
        var scenarios := OptionButton.new()
        scenarios.add_item("Peaceful · no distractor bots",0)
        scenarios.add_item("Standard · two distractor bots",2)
        scenarios.add_item("Hostile · four distractor bots",4)
        scenarios.select(0 if selected_bots==0 else 2 if selected_bots==4 else 1)
        scenarios.item_selected.connect(func(index:int):selected_bots=scenarios.get_item_id(index))
        modal_body.add_child(scenarios)
        modal_body.add_child(_button("START SURVIVAL",func():game_command("start",{"bots":selected_bots}),true))
        var continue_button := _button("Continue saved mission",func():game_command("load"))
        continue_button.disabled=not state.get("save_available",false)
        modal_body.add_child(continue_button)
        modal_body.add_child(_button("Options",func():_show_panel("options")))
        modal_body.add_child(_button("How to play",func():_show_panel("help")))
        modal_body.add_child(_button("Quit",func():game_command("quit")))
    elif screen=="pause":
        _title("MISSION PAUSED","Take a breath","The world is paused. Your inventory and survivor progress are preserved.")
        modal_body.add_child(_button("RESUME",func():game_command("resume"),true))
        modal_body.add_child(_button("Save mission",func():game_command("save")))
        modal_body.add_child(_button("Load last save",func():game_command("load")))
        modal_body.add_child(_button("Options",func():_show_panel("options")))
        modal_body.add_child(_button("How to play",func():_show_panel("help")))
        modal_body.add_child(_button("Return to main menu",func():game_command("menu")))
    elif screen=="options":
        _title("OPTIONS","Make it comfortable","Settings are saved locally. The low preset is intended for integrated graphics.")
        modal_body.add_child(_label("Mouse sensitivity",14,MUTED))
        var slider := HSlider.new()
        slider.min_value=.0005;slider.max_value=.006;slider.step=.0001;slider.value=sensitivity
        slider.value_changed.connect(func(value:float):sensitivity=value;_save_options())
        modal_body.add_child(slider)
        var invert := CheckButton.new()
        invert.text="Invert vertical mouse";invert.button_pressed=invert_y
        invert.toggled.connect(func(value:bool):invert_y=value;_save_options())
        modal_body.add_child(invert)
        var quality := OptionButton.new()
        quality.add_item("Low · 960 × 540 · 30 FPS",0)
        quality.add_item("Balanced · 1280 × 720 · 30 FPS",1)
        quality.add_item("Smooth · 1280 × 720 · 60 FPS",2)
        quality.select(resolution)
        quality.item_selected.connect(func(index:int):resolution=index;_save_options();_apply_display())
        modal_body.add_child(quality)
        modal_body.add_child(_label("Sound effects",14,MUTED))
        var volume_slider := HSlider.new()
        volume_slider.min_value=0;volume_slider.max_value=1;volume_slider.step=.05;volume_slider.value=volume
        volume_slider.value_changed.connect(func(value:float):volume=value;_save_options();audio.volume_db=linear_to_db(maxf(volume,.001)))
        modal_body.add_child(volume_slider)
        modal_body.add_child(_button("Back",func():_show_panel("menu" if not state.get("started",false) else "pause"),true))
    elif screen=="help":
        _title("FIELD GUIDE","Stay alive. Find a way.","Collect the yellow key, activate the radio, and reach the extraction pad. Hold E at one blue gate control while another survivor operates the other. You can take the southern bypass alone.")
        var controls := _label("WASD  Move     Mouse  Camera     Shift  Sprint\nCtrl  Crouch     Space  Jump     E  Interact / Revive\nRMB  Aim     LMB  Attack     1 / 2  Pistol / Sword\nR  Reload     H  Medkit     F  Food     G  Offer ammo\nF5  Save     F9  Load     Tab  Spectate\nF10  Watch the AI play     F1  Debug HUD",14,TEXT)
        modal_body.add_child(controls)
        modal_body.add_child(_button("Back",func():_show_panel("menu" if not state.get("started",false) else "pause"),true))
    elif screen=="results":
        var success: bool=state.get("victory",false)
        var elapsed := int(state.get("elapsed",0))
        _title("MISSION COMPLETE" if success else "MISSION ENDED","SURVIVORS EXTRACTED" if success else "THE SIGNAL WENT DARK", "%d of 5 survivors reached safety.\nTime %02d:%02d  ·  Revives %d  ·  Supplies collected %d" % [state.get("arrived",0),elapsed/60,elapsed%60,state.get("revives",0),state.get("pickups",0)])
        for actor in state.get("team",[]):
            modal_body.add_child(_label(str(actor["name"])+"  ·  "+str(actor["state"]),14,TEAL if actor["state"]=="Extracted" else MUTED))
        modal_body.add_child(_button("PLAY AGAIN",func():game_command("restart"),true))
        modal_body.add_child(_button("Quit",func():game_command("quit")))
    modal_status=_label("",12,TEAL)
    modal_status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    modal_status.custom_minimum_size.x=390
    modal_body.add_child(modal_status)
    modal.reset_size()
    call_deferred("_layout")
    var button := modal_body.find_children("*","Button",true,false)
    if not button.is_empty():button[0].grab_focus()

func _refresh_state() -> void:
    state=get_game_state()
    if state.is_empty():return
    var mode: String=state.get("mode","playing")
    if mode!=visible_mode:
        visible_mode=mode
        if mode!="playing":_show_panel(mode)
    modal.visible=mode!="playing"
    shade.visible=modal.visible
    hud_root.visible=mode=="playing"
    var objectives := ["Recover the yard key","Restore the radio signal","Reach the extraction pad"]
    objective_label.text=objectives[clampi(int(state.get("mission",0)),0,2)]
    var seconds := maxi(0,int(state.get("deadline",600))-int(state.get("elapsed",0)))
    objective_detail.text="%d m  ·  %02d:%02d remaining  ·  %d / 5 extracted" % [int(state.get("objective_distance",0)),seconds/60,seconds%60,state.get("arrived",0)]
    stat_label.text="YOU  ·  %d HP  ·  %d medkit  ·  %d food" % [state.get("health",100),state.get("medkits",0),state.get("food",0)]
    health_bar.value=state.get("health",100)
    stamina_bar.value=state.get("stamina",100)
    hunger_bar.value=state.get("hunger",100)
    var player_status: String=state.get("player_state","Idle")
    tutorial_tip.text="You reached safety  ·  Tab to spectate the remaining survivors" if player_status=="Extracted" else "Downed  ·  A teammate can revive you  ·  Tab to spectate" if player_status=="Downed" else "You died  ·  Tab to spectate  ·  Esc for menu" if player_status=="Dead" else "WASD Move   ·   E Interact   ·   RMB Aim   ·   LMB Attack   ·   Esc Menu"
    var weapon: String=state.get("weapon","UNARMED")
    crosshair.text="×" if state.get("hit_confirm",false) else "·"
    crosshair.modulate=GOLD if state.get("hit_confirm",false) else Color.WHITE
    ammo_label.text="%02d / %02d" % [state.get("rounds",0),state.get("reserve",0)] if weapon=="PISTOL" else weapon
    action_label.text=str(state.get("player_state","Idle"))
    if float(state.get("action_timer",0))>0:action_label.text+="  %.1fs" % state["action_timer"]
    prompt_label.text=str(state.get("hint",""))
    prompt_label.visible=not prompt_label.text.is_empty()
    toast_label.text=str(state.get("message",""))
    toast_label.visible=mode=="playing"
    if is_instance_valid(modal_status):
        modal_status.text=toast_label.text
        modal_status.visible=not modal_status.text.is_empty() and not modal_status.text.begins_with("Last Light ready")
    toast_label.offset_top=115 if mode=="playing" else get_viewport().get_visible_rect().size.y-60
    toast_label.offset_bottom=toast_label.offset_top+28
    for i in range(4):
        var actors: Array=state.get("team",[])
        if actors.size()<=i+1:continue
        var actor: Dictionary=actors[i+1]
        squad_rows[i].text="%s  ·  %s" % [actor["name"],str(actor["health"])+" HP" if actor["known"] else "No contact"]
        if actor["state"]=="Downed":squad_rows[i].text+="  /  NEEDS HELP"
        if actor["state"]=="Extracted":squad_rows[i].text=str(actor["name"])+"  /  SAFE"
        squad_rows[i].add_theme_color_override("font_color",TEAL if actor["state"]=="Extracted" else TEXT)
    map_control.set("state",state)
    map_control.queue_redraw()
    debug_label.visible=state.get("debug",false)
    debug_label.text="FPS %d   Nav %d   Python %s\nWASD / Shift / Ctrl / Space  ·  F10 autoplay %s" % [state.get("fps",0),state.get("navigation_polygons",0),"connected" if state.get("python",false) else "authored",state.get("autoplay",false)]
    var health := int(state.get("health",100))
    if health<last_player_health:
        flash.color.a=.25
        _play_sound("hurt")
    last_player_health=health
    for event in state.get("events",[]):
        var sequence := int(event.get("sequence",0))
        if sequence<=last_sound_event:continue
        last_sound_event=sequence
        var kind: String=event.get("kind","")
        if kind=="pickup" and event.get("actor",0)==1:_play_sound("pickup")
        if kind=="radio":_play_sound("radio")
        if kind=="help":_play_sound("gate")
        if kind in ["attack","shot"] and event.get("actor",0)==1:_play_sound("shot")

func _play_sound(name: String) -> void:
    if sounds.has(name) and is_instance_valid(audio):
        audio.stream=sounds[name]
        audio.play()

func _process(delta: float) -> void:
    if not is_instance_valid(root):return
    refresh+=delta
    if refresh>=.1:
        refresh=0
        _refresh_state()
    if is_instance_valid(flash):flash.color.a=move_toward(flash.color.a,0,delta*1.2)

func _load_options() -> void:
    var file := ConfigFile.new()
    if file.load("user://settings.cfg")==OK:
        sensitivity=_safe_number(file.get_value("input","sensitivity",.0025),.0025,.0005,.006)
        var inversion: Variant=file.get_value("input","invert_y",false)
        invert_y=inversion if inversion is bool else false
        resolution=int(_safe_number(file.get_value("display","preset",0),0,0,2))
        volume=_safe_number(file.get_value("sound","volume",.6),.6,0,1)
    apply_options({"sensitivity":sensitivity,"invert_y":invert_y})
    if DisplayServer.get_name()!="headless":_apply_display()

func _safe_number(value: Variant, fallback: float, low: float, high: float) -> float:
    if not (value is float or value is int):return fallback
    if not is_finite(float(value)):return fallback
    return clampf(float(value),low,high)

func _save_options() -> void:
    var file := ConfigFile.new()
    file.set_value("input","sensitivity",sensitivity)
    file.set_value("input","invert_y",invert_y)
    file.set_value("display","preset",resolution)
    file.set_value("sound","volume",volume)
    file.save("user://settings.cfg")
    apply_options({"sensitivity":sensitivity,"invert_y":invert_y})

func _apply_display() -> void:
    Engine.max_fps=60 if resolution==2 else 30
    if DisplayServer.get_name()!="headless":
        DisplayServer.window_set_size(Vector2i(960,540) if resolution==0 else Vector2i(1280,720))
