LAST LIGHT - ARCTIC UPGRADE - WINDOWS x64

Extract the WHOLE ZIP into a writable folder. Double-click Play.bat.
No Visual Studio, Premake, Godot editor or Python installation is needed.
Play-With-Neural-AI.bat enables the included portable Python guide.
Keep LastLight.exe and LastLight.pck together. Do not launch inside a ZIP viewer.
Verify-Game.bat verifies file hashes and runs 28 isolated headless gameplay
checks. Diagnostics go in diagnostics/, separate from your personal saves.

FIRST TEST
Choose Peaceful first. Start Survival. M opens the tactical map. Find the access
key, power the generator (fuel is faster; hand-crank works without fuel),
calibrate any two of three relays, then use the radio. Reach either extraction.
There are four independent survivors. Standard adds five distractor roles;
Hostile enables eight bots. F10 enables autoplay so you can inspect the agents.
The Arctic base spans 300x300 metres with 124 loot entries and 36 interactable
objects, including seven doors and 22 searchable supply crates.

WASD move; mouse camera; Shift sprint; Ctrl crouch; Space jump; Alt roll.
RMB aim; LMB fire/melee; R reload; 1 pistol; 2 sword; 3 SMG; 4 rifle; 5 shotgun.
E interact/pickup/revive; C close nearby door; H medkit; B bandage; F eat;
T drink; Q smoke; V decoy; G offer compatible ammo; Y invite a nearby teammate.
I survivor inspector; M tactical map; Esc pause; F5 save; F9 load; Tab spectate;
F10 autoplay; F1 diagnostics; X cancel an action.

INSPECT AND RESET
I opens the live inspector (the world continues). Select Maya, Rafi, Lian or
Omar. It shows six personality/social scores, remembered trust/fear, experience
history, learned intention biases, historical region risk, current resources,
chosen plan, alternative scores/costs/risk, and the remaining plan steps.
Reset this survivor clears that survivor's learned preferences and personal
memory immediately. Health and inventory are preserved. Further play can teach
new experiences immediately; reset is not a permanent learning freeze.
The main-menu checkbox resets all four profiles for a new game. Pause-menu
profiles can also be inspected/reset while the world is paused.

Profiles persist across missions and launches in:
%APPDATA%\Godot\app_userdata\Last Light\survivors-v1.json
Mission save: save.json in the same directory. Mission loading does not rewind
persistent learning. Loading a save made before a reset cannot resurrect the
reset profile. Old prototype mission saves use an incompatible schema and are
rejected safely; start a new Arctic mission. Settings are retained.

AI SYSTEMS
Bounded forward planning compares explicit prerequisites, alternative regional
routes, equipment, current threats and personal risk memories. Local skills
handle combat, self-care, retreat/smoke, doors, rescue and surplus sharing.
The optional Python MLP gives intention guidance. Individual output preferences
adapt online and persist; the shared pretrained base network remains fixed
during play. Separate GA training can evolve that base network using real
headless episodes. These are bounded game AI systems, not human reasoning.

New Arctic art uses five Kenney CC0 packs: Nature, Survival, Blaster, Furniture,
and City Industrial. UAL1 supplies locomotion; UAL2 supplies advanced actions.
Movement, stance, aim and action blending use the existing rigs. See asset
credits for the supplied pistol/sword terms and retained older test-map art.

BUILD AND LICENSE NOTES
Godot 4.5.1 and the C++ client compile into the GUI EXE with MSVC static CRT.
The optional Python guide runs as a separate process. Windows/GPU system
libraries remain dependencies. OpenGL 3.3 and a working driver are required.
Target Vega frame rate must be measured locally; start at 960x540/30 FPS.
BUILD-INFO.json records the exact native build/check run when packaged.
The bundled champion is from the earlier courtyard experiment; no claim of
Arctic neural superiority is made. See asset credits and engine/Python notices.
