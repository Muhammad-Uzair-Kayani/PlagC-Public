"""Register a pinned Godot gitlink and install the local build tool environment."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import venv
ROOT=Path(__file__).resolve().parents[1]
LOCK=json.loads((ROOT/'godot.lock.json').read_text())

def run(args,cwd=ROOT):
    subprocess.run(list(map(str,args)),cwd=cwd,check=True)

def engine_setup():
    result=subprocess.run(['git','rev-parse','--show-toplevel'],cwd=ROOT,text=True,capture_output=True)
    if result.returncode:
        run(['git','init']); repo=ROOT
    else:repo=Path(result.stdout.strip())
    relative=(ROOT/'vendor/godot').relative_to(repo).as_posix()
    recorded=subprocess.run(['git','ls-files','--stage','--',relative],cwd=repo,text=True,capture_output=True,check=True).stdout
    engine=ROOT/'vendor/godot'
    if not recorded.startswith('160000 '):
        if recorded.strip():raise RuntimeError('Godot location is already tracked as ordinary files; refusing to overwrite it')
        run(['git','submodule','add','--depth','1','--force','--',LOCK['repository'],relative],repo)
    else:run(['git','submodule','update','--init','--',relative],repo)
    dirty=subprocess.run(['git','status','--porcelain'],cwd=engine,text=True,capture_output=True,check=True).stdout
    if dirty.strip():raise RuntimeError('Godot submodule contains edits. Preserve them before switching the pinned revision.')
    have=subprocess.run(['git','cat-file','-e',LOCK['commit']+'^{commit}'],cwd=engine,capture_output=True)
    if have.returncode:run(['git','fetch','--depth','1','origin',LOCK['commit']],engine)
    run(['git','checkout','--detach',LOCK['commit']],engine)
    run(['git','add','--',relative],repo)
    print('Godot gitlink registered at:',relative)
    print('Commit your project files, repository-root .gitmodules and the staged gitlink before pushing.')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--engine-only',action='store_true');a=p.parse_args()
    if sys.version_info<(3,10):p.error('Python 3.10+ required')
    engine_setup()
    if not a.engine_only:
        directory=ROOT/'.tools/venv';venv.EnvBuilder(with_pip=True).create(directory)
        python=directory/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
        run([python,'-m','pip','install','-r',ROOT/'requirements-build.txt'])
        print('Build tools ready. Run BuildGame.bat on Windows.')
if __name__=='__main__':main()
