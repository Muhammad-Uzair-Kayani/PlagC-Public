"""Build the built-in game module with Godot, then package the Windows GUI app."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from pack import pack,embed
ROOT=Path(__file__).resolve().parents[1]
LOCK=json.loads((ROOT/'godot.lock.json').read_text())

def vs_environment():
    locator=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft Visual Studio/Installer/vswhere.exe'
    if not locator.exists():raise RuntimeError('Install Visual Studio 2022 C++ desktop tools and Windows SDK')
    location=subprocess.check_output([str(locator),'-latest','-products','*','-version','[17.0,18.0)','-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-property','installationPath'],text=True).strip()
    if not location:raise RuntimeError('VS2022 MSVC x64 workload not found')
    vcvars=Path(location)/'VC/Auxiliary/Build/vcvars64.bat'
    command=f'""{vcvars}" >nul && set"'
    output=subprocess.check_output([os.environ.get('COMSPEC','cmd.exe'),'/d','/s','/c',command],text=True)
    env=os.environ.copy()
    for line in output.splitlines():
        if '=' in line:
            key,value=line.split('=',1)
            if key:env[key]=value
    return env

def options(platform,target):
    flags=[f'platform={platform}',f'target={target}','arch=x86_64',f'custom_modules={ROOT / "modules"}',
           'modules_enabled_by_default=no','module_last_light_enabled=yes',
           'vulkan=no','opengl3=yes','lto=none','debug_symbols=no','optimize=size']
    for name in ('godot_physics_3d','navigation_3d','freetype','text_server_fb','svg','gltf','fbx','meshoptimizer','gdscript','regex','zip','jpg','webp'):
        flags.append(f'module_{name}_enabled=yes')
    if platform=='windows':flags+=['windows_subsystem=gui','use_static_cpp=yes','d3d12=no']
    return flags

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--jobs',type=int,default=1);p.add_argument('--debug',action='store_true');p.add_argument('--editor',action='store_true');p.add_argument('--embed',action='store_true');p.add_argument('--headless-linux',action='store_true');p.add_argument('--portable-python',type=Path,help='An extracted official Windows embeddable Python directory')
    a=p.parse_args()
    if not 1<=a.jobs<=8:p.error('--jobs must be 1..8; use 1 on an 8 GB machine')
    engine=ROOT/'vendor/godot'
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=engine,text=True).strip()
    if actual!=LOCK['commit']:raise RuntimeError('Godot revision differs from godot.lock.json; run Setup.bat')
    python=ROOT/'.tools/venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not python.exists():raise RuntimeError('Run Setup.bat first to install project-local SCons')
    platform='windows' if os.name=='nt' else 'linuxbsd';target='editor' if a.editor else 'template_debug' if a.debug else 'template_release'
    flags=options(platform,target)
    if a.headless_linux:flags+=['x11=no','wayland=no','dbus=no','speechd=no','fontconfig=no']
    env=vs_environment() if os.name=='nt' else os.environ.copy()
    subprocess.run([str(python),'-m','SCons',*flags,f'-j{a.jobs}'],cwd=engine,env=env,check=True)
    suffix='.exe' if os.name=='nt' else ''
    binary=engine/'bin'/f'godot.{platform}.{target}.x86_64{suffix}'
    if not binary.exists():raise RuntimeError('Expected Godot binary not produced: '+str(binary))
    if a.editor:
        subprocess.run([str(binary),'--headless','--path',str(ROOT/'game'),'--editor','--import'],check=True)
        print('Custom editor and asset import complete:',binary);return
    output=ROOT/'dist';output.mkdir(exist_ok=True)
    destination=output/('LastLight.exe' if os.name=='nt' else 'LastLight')
    cache=ROOT/'game/.godot/global_script_class_cache.cfg'
    if not cache.exists():cache.parent.mkdir(exist_ok=True);cache.write_text('list=[]\n')
    pck=output/'LastLight.pck';count=pack(ROOT/'game',pck)
    if a.embed:
        embed(binary,pck,destination);pck.unlink()
    else:shutil.copy2(binary,destination)
    shutil.copytree(ROOT/'python',output/'python',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
    if a.portable_python:
        if not (a.portable_python/'python.exe').is_file():raise RuntimeError('Expected extracted official embeddable Python directory')
        shutil.copytree(a.portable_python,output/'python-runtime',dirs_exist_ok=True)
    for name in ('LICENSE.txt','COPYRIGHT.txt','AUTHORS.md'):
        if (engine/name).exists():shutil.copy2(engine/name,output/('Godot-'+name))
    print(f'Ready: {destination}; {count} PCK files. Python remains a separate optional process.')
if __name__=='__main__':main()
