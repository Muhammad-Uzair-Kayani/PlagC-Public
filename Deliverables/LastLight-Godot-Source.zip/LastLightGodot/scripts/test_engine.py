"""Run integration checks against the source-built module, not a stock Godot binary."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]

def run(executable,case,frames=360,python=False,expect_fallback=False):
    output=ROOT/'reports';output.mkdir(exist_ok=True);report=output/(case+'.json')
    report.unlink(missing_ok=True)
    args=[str(executable),'--headless','--fixed-fps','60','--max-fps','0','--path',str(ROOT/'game'),'--','--smoke','--case',case,'--frames',str(frames),'--report',str(report)]
    args+=['--bots','1' if case=='combat' else '2' if case=='autoplay' else '0']
    if case.startswith('python_fault_'):args+=['--autoplay']
    if python:args+=['--python',sys.executable]
    if case=='fallback':args+=['--python',str(output/'missing-python-executable')]
    env=os.environ.copy();env['XDG_DATA_HOME']=str(output/'user-data')
    if os.name=='nt':
        env['APPDATA']=str(output/'user-data');env['LOCALAPPDATA']=str(output/'local-data')
    with (output/(case+'.log')).open('w') as log:
        p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=90)
    if p.returncode!=0 or not report.exists():raise RuntimeError(f'{case} failed; inspect {output/(case+".log")}')
    log_text=(output/(case+'.log')).read_text(errors='replace')
    if 'SCRIPT ERROR' in log_text or ('ERROR:' in log_text and case not in ('python_fault_malformed','fallback')):raise RuntimeError(f'{case}: engine/script error; inspect log')
    result=json.loads(report.read_text())
    if not result.get('test_passed') or result['navigation_polygons']<1:raise RuntimeError(f'{case}: invalid test report')
    if python and not expect_fallback and result['python_failures']:raise RuntimeError('Neural test used fallback')
    if (case=='fallback' or expect_fallback) and result['python_failures']<1:raise RuntimeError('Expected explicit authored fallback')
    print(case,'passed; navigation polygons:',result['navigation_polygons'])
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--engine',type=Path,required=True);p.add_argument('--autoplay',action='store_true');a=p.parse_args();engine=a.engine.resolve()
    for case in ('physics','combat','gate','gate_save','gate_negative','save','assets','social','melee','lifecycle'):run(engine,case)
    run(engine,'python',frames=120,python=True)
    run(engine,'fallback',frames=120)
    run(engine,'python_exit',frames=240,python=True,expect_fallback=True)
    for fault in ('malformed','stale','timeout','duplicate'):run(engine,'python_fault_'+fault,frames=240,python=True,expect_fallback=True)
    invalid_env=os.environ.copy();invalid_env['XDG_DATA_HOME']=str(ROOT/'reports/user-data')
    for values in (['--bots','9'],['--seed','abc'],['--controller','unknown'],['--frames'],['--unknown']):
        invalid=subprocess.run([str(engine),'--headless','--path',str(ROOT/'game'),'--',*values],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=invalid_env,timeout=15)
        if invalid.returncode!=64:raise RuntimeError('Invalid CLI arguments were not rejected: '+str(values))
    if a.autoplay:
        peaceful=run(engine,'peaceful',frames=18000)
        if peaceful['phase']!='Victory' or peaceful['arrived']!=5:raise RuntimeError('Peaceful team did not all arrive')
        repeated=run(engine,'peaceful',frames=18000)
        def fingerprint(data):
            return (data['phase'],data['arrived'],data['shots_hit'],data['journal'],[(a['health'],a['state'],[round(v,3) for v in a['position']]) for a in data['actors']])
        if fingerprint(peaceful)!=fingerprint(repeated):raise RuntimeError('Same-build seeded run diverged')
        print('same-build seeded replay passed')
        for case in ('solo','autoplay'):
            r=run(engine,case,frames=18000)
            if r['phase']!='Victory':raise RuntimeError('Authored survivors did not complete '+case)
if __name__=='__main__':main()
