"""Evolve the neural policy by evaluating real source-built Godot episodes."""
import argparse
import csv
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
from neural import Policy,GENES
ROOT=Path(__file__).resolve().parents[1]
TRAIN=(101,102,103,104)
TEST=(901,902,903,904)

def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,allow_nan=False));temp.replace(path)

def tuples(value):
    return tuple(tuples(x) for x in value) if isinstance(value,list) else value

def breed(population,scores,rng):
    ranked=sorted(range(len(population)),key=scores.__getitem__,reverse=True)
    children=[population[i][:] for i in ranked[:2]]
    def select():return population[max(rng.sample(range(len(population)),min(3,len(population))),key=scores.__getitem__)]
    while len(children)<len(population):
        a,b=select(),select()
        children.append([max(-5,min(5,(a[i] if rng.random()<.5 else b[i])+(rng.gauss(0,.2) if rng.random()<.08 else 0))) for i in range(GENES)])
    return children

def episode(executable,weights,seed,output,serial,controller='neural',frames=18000):
    output.mkdir(parents=True,exist_ok=True);report=output/f'episode-{serial}.json';model=output/'candidate.json'
    report.unlink(missing_ok=True)
    args=[str(Path(executable).resolve()),'--headless','--fixed-fps','60','--path',str(ROOT/'game'),'--','--autoplay','--seed',str(seed),'--controller',controller,'--frames',str(frames),'--report',str(report.resolve())]
    if controller=='neural':
        Policy(weights).save(model);args+=['--python',sys.executable,'--policy',str(model.resolve())]
    env=os.environ.copy();env.setdefault('XDG_DATA_HOME',str((output/'user-data').resolve()))
    with (output/f'episode-{serial}.log').open('w') as log:
        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=120)
    if result.returncode not in (0,2) or not report.exists():raise RuntimeError(f'Godot evaluation failed; see episode-{serial}.log')
    data=json.loads(report.read_text())
    if data['python_failures']:raise RuntimeError('Rejecting neural episode that used transport fallback')
    if data['navigation_polygons']<=0:raise RuntimeError('Invalid navigation world')
    return data

def train(args):
    output=Path(args.output).resolve();rng=random.Random(args.seed);history=[];start=0;champion=None;best=-float('inf')
    if args.resume:
        state=json.loads(Path(args.resume).read_text())
        if state.get('version')!=1 or tuple(state['training_seeds'])!=TRAIN:raise ValueError('incompatible checkpoint')
        population=[Policy(w).weights for w in state['population']];rng.setstate(tuples(state['rng_state']));history=state['history'];start=state['generation'];best=state['best'];champion=state['champion']
    else:population=[[rng.uniform(-1,1) for _ in range(GENES)] for _ in range(args.population)]
    for generation in range(start,start+args.generations):
        scores=[]
        for genome,weights in enumerate(population):
            samples=[episode(args.engine,weights,seed,output/'episodes',f'{generation}-{genome}-{seed}',frames=args.frames) for seed in TRAIN]
            scores.append(statistics.mean(float(d['fitness']) for d in samples))
        winner=max(range(len(population)),key=scores.__getitem__)
        if scores[winner]>best:best=scores[winner];champion=population[winner][:]
        history.append(dict(generation=generation,best=max(scores),mean=statistics.mean(scores),stdev=statistics.pstdev(scores)))
        print(json.dumps(history[-1]),flush=True)
        population=breed(population,scores,rng)
        Policy(champion).save(output/'champion.json')
        atomic(output/'latest.json',dict(version=1,training_seeds=TRAIN,generation=generation+1,population=population,rng_state=rng.getstate(),history=history,best=best,champion=champion))
        with (output/'generations.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['generation','best','mean','stdev']);w.writeheader();w.writerows(history)

def evaluate(args):
    weights=Policy.load(args.model).weights;output=Path(args.output).resolve();rows=[]
    for controller in ('neural','rule','random'):
        data=[episode(args.engine,weights,seed,output/'episodes',f'{controller}-{seed}',controller,args.frames) for seed in TEST]
        rows.append(dict(controller=controller,arrival_rate=statistics.mean(d['arrived']/5 for d in data),fitness=statistics.mean(d['fitness'] for d in data),fitness_stdev=statistics.pstdev(d['fitness'] for d in data),mean_seconds=statistics.mean(d['elapsed'] for d in data)))
    atomic(output/'comparison.json',rows);print(json.dumps(rows,indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['train','evaluate']);p.add_argument('--engine',required=True);p.add_argument('--output',default=str(ROOT/'reports/training'));p.add_argument('--population',type=int,default=30);p.add_argument('--generations',type=int,default=10);p.add_argument('--seed',type=int,default=42);p.add_argument('--resume');p.add_argument('--model');p.add_argument('--frames',type=int,default=18000);a=p.parse_args()
    if a.population<2 or a.generations<1:p.error('population >=2 and generations >=1 required')
    if a.command=='evaluate' and not a.model:p.error('--model required for evaluation')
    train(a) if a.command=='train' else evaluate(a)
if __name__=='__main__':main()
