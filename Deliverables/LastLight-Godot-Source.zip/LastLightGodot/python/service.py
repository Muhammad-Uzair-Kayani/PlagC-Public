"""Persistent, bounded NDJSON inference over authenticated loopback TCP."""
import argparse
import json
import socket
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from neural import Policy

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,required=True)
    parser.add_argument('--token',required=True)
    args=parser.parse_args()
    policy=Policy()
    with socket.create_connection(('127.0.0.1',args.port),timeout=3) as connection:
        connection.settimeout(None)
        stream=connection.makefile('rwb')
        def send(q):
            stream.write(json.dumps(q,allow_nan=False).encode()+b'\n');stream.flush()
        send(dict(v=1,type='connected',token=args.token))
        while True:
            line=stream.readline(65537)
            if not line:break
            if len(line)>65536:raise ValueError('request exceeds 64 KiB')
            q={}
            try:
                q=json.loads(line)
                if not isinstance(q,dict) or type(q.get('v')) is not int or q['v']!=1:
                    raise ValueError('schema version')
                for key in ('request_id','episode'):
                    if type(q.get(key)) is not int:raise ValueError('correlation ID')
                reply=dict(v=1,request_id=q['request_id'],episode=q['episode'])
                if q.get('type')=='shutdown':break
                if q['type']=='load_policy':
                    policy=Policy(q['weights']);reply['type']='loaded'
                elif q['type']=='infer_batch':
                    agents=q['agents']
                    if not isinstance(agents,list) or len(agents)>32:raise ValueError('invalid batch')
                    seen=set();actions=[]
                    for agent in agents:
                        actor=agent['id']
                        if type(actor) is not int or actor<=0 or actor in seen:raise ValueError('duplicate/invalid actor')
                        seen.add(actor)
                        actions.append(dict(id=actor,intent=policy.choose(agent['features'],agent['valid_actions']),target_id=0))
                    reply.update(type='intents',actions=actions)
                else:raise ValueError('unknown request')
            except (ValueError,KeyError,TypeError) as error:
                reply=dict(v=1,type='error',request_id=q.get('request_id') if isinstance(q,dict) else None,episode=q.get('episode') if isinstance(q,dict) else None,error=str(error))
            send(reply)
        stream.close()

if __name__=='__main__':
    try:main()
    except (OSError,ValueError) as error:
        print(f'Policy service: {error}',file=sys.stderr);raise SystemExit(1)
