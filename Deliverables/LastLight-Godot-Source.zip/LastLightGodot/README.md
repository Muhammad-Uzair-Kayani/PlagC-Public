# Current Arctic upgrade

Read **QUICKSTART-ARCTIC.txt** first. This revision replaces the default courtyard
with a 300x300m Arctic survival base, richer equipment and environmental actions,
bounded multi-step planning, and persistent inspectable/resettable survivor
profiles. The original courtyard remains as the `--world lab` regression world.
The historical MVP documentation and evaluation numbers below describe that
earlier world; they are not measurements of the new Arctic scenario.
See QUICKSTART-ARCTIC.txt and docs/arctic-upgrade.md for current validation status.

# Last Light — Godot source-module survival MVP

Windows 10 x64 / Visual Studio 2022 / low-end integrated graphics. The C++ game
is a built-in Godot module, not a GDExtension or a dynamically loaded game DLL.
Godot is pinned to **4.5.1-stable**, commit in `godot.lock.json`.

## Windows build

For an existing checkout affected by the compiler-detection errors, overwrite
project files from this ZIP and follow BUILD_AUDIT_FIX.txt. Keep your existing
`vendor/godot` and `.tools` directories.

Use a short project location such as `C:\Dev\LastLightGodot`. Git long-path
support is configured by setup before cloning. If an older setup attempt
failed with `Filename too long`, apply the updated script and run
`Setup.bat --repair-missing`; see WINDOWS_SETUP_FIX.txt.

Install Git, Python 3.10+ (with the `py` launcher), Visual Studio 2022 **Desktop
development with C++**, MSVC x64 tools and Windows SDK. Put your working `premake5.exe` beside GenerateProjects.bat or on PATH.
Premake generates the Visual Studio frontend; its build task invokes the
required Godot SCons build with the IDE-selected C++ environment.

```cmd
Setup.bat
GenerateProjects.bat vs2022
start "" "build\premake\vs2022\LastLightGodot.sln"
```

In Visual Studio choose **Release | x64**, set **LastLight** as startup project,
and press **Ctrl+F5**. Build/Clean/Rebuild are configured. The batch wrapper initializes MSVC and Python inherits the IDE-selected
compiler environment; a manually initialized
Developer Command Prompt is not required. There is no CMake step. Visual Studio
still needs its C++ compiler and Windows SDK installed.

Build diagnostics are retained in `reports/godot-build.log`.
`BuildGame.bat --configure-only` validates the compiler/SDK and complete Godot
build graph before a long engine compile.

The command-line alternative remains `BuildGame.bat --jobs 1` then RunGame.bat.
It accepts an existing x64 developer environment and detects Preview/Build Tools
installations as well as regular Visual Studio.

On an 8 GB machine use one compile job, keep the Windows page file enabled,
and allow substantial disk space for source and objects. LTO is disabled. The
first source build is lengthy; subsequent module-only rebuilds are incremental.
The acceptance procedure is in `tests/windows_full_build.py`; see
`docs/validation.md` for its recorded results. Target Vega performance still
requires measurement on your machine.

`dist/LastLight.exe` contains the engine and C++ game. `LastLight.pck` contains
resources. Windows GUI subsystem and static C++ runtime are selected. Windows,
GPU drivers and OS libraries remain external dependencies. `--embed` optionally
appends the PCK to an unsigned executable; use the separate PCK workflow when
preparing signed distributions unless an official exporter/signing process is
used. Python remains a separate optional process, never a statically linked
part of Godot.

### Copying the ZIP into your repository

Extract the whole `LastLightGodot` folder as a new subfolder in your existing
repository. Do not overwrite an existing repository-root `.gitmodules` file.
A ZIP cannot store a Git gitlink. Run `Setup.bat` inside this folder once after copying the files.
It finds your enclosing Git repository (or initializes this folder), registers
Godot at the correct relative location, checks out the locked commit and stages
the gitlink. It preserves dirty engine checkouts by refusing to switch them.
Commit the root repository's `.gitmodules`, gitlink, and your project sources.
Afterward normal `git submodule update --init --recursive` works. Do not track
the Godot source as ordinary files or edit engine files to install this module.

## Play the Arctic mission

Read `QUICKSTART-ARCTIC.txt` for all controls and local profile reset instructions.
Start with Peaceful, then Standard (five distractors) or Hostile (eight).
Find the access key, restore generator power, calibrate any two of three relays,
activate the radio, and reach either landing. The 300x300m base offers a western
forest approach, exposed bridge/road, cooperative shortcut, shelters, furnished
interiors, cover and competing supplies. Casualties and mission failure are possible.

WASD/mouse move and look; Shift sprint; Ctrl crouch; Space jump; Alt roll.
RMB aims and LMB attacks. 1/2 selects pistol/sword, 3/4/5 SMG/rifle/shotgun.
E interacts/picks up/revives; C closes doors; R reloads; H medkit; B bandage;
F food; T water; Q smoke; V decoy; Y teammate invitation; G compatible ammo.
I opens the live survivor inspector; M the tactical map; Escape pauses;
F5/F9 save/load; Tab spectates; F10 toggles autoplay; X cancels actions.

## Strategy, memory and learning

Four independent survivors maintain their own observations, personal traits,
relationships, historical region risk and learned intention preferences.
`strategy.h` searches explicit action prerequisites/effects over alternative
regional routes. Health, equipment, time, noise, present danger, personal risk
memories and optional neural intentions influence plan scoring. Local skills
handle rescue, self-care, fight/retreat, smoke, doors, supplies and surplus sharing.
Survivors reposition when a friendly survivor blocks their firing lane.

The I inspector exposes six 0..100 trait/social scores, survivor type, trust/fear,
recent evidence, learned biases, current condition, plan steps and alternative
cost/risk/utility scores. Reset one survivor live or from the pause menu; use
the main-menu checkbox to reset all four for a new mission. Reset preserves
health and inventory. Future play can teach new experiences immediately.
Profiles persist in `user://survivors-v1.json` until reset, separately from
mission saves. A mission load cannot restore pre-reset personal memories.

These systems are distinct: situational planning chooses a current strategy;
personal evidence updates traits/relationships/risk; individual learned output
biases adapt online. The optional shared 16-16-6 MLP remains fixed during play.
Offline GA training evolves its 374 weights using real engine episodes:

```cmd
py -3 python\train.py train --engine dist\LastLight.exe --world arctic --bots 5 --population 30 --generations 10 --workers 1
py -3 python\train.py train --engine dist\LastLight.exe --world arctic --bots 5 --resume reports\training\latest.json --generations 5
py -3 python\train.py evaluate --engine dist\LastLight.exe --world arctic --bots 5 --model reports\training\champion.json
```

Use `--frames 36000` for a longer training horizon. Checkpoints record map,
bot count and horizon and reject mismatched resumption. Training/validation/test
seeds are disjoint. Evaluation compares neural, rule, random plan selection
and a memory ablation. `--world lab --bots 2` selects the earlier courtyard
experiment. The bundled champion and `docs/samples` measurements come from
that earlier experiment; no Arctic neural superiority is claimed.
Automated episodes never load or write your personal survivor profiles.

Normal play works without Python. To enable the guide:

```cmd
RunGame.bat -- --python "C:\Path To Python\python.exe"
```

The optional authenticated loopback service validates bounded features, masks,
per-agent output biases and correlated replies. Timeout, invalid messages or
process failure falls back to the C++ controller. C++ remains authoritative.
`-- --autoplay --world arctic --controller rule --trace decisions.ndjson` records
observations, decisions, plans and scores. The limits of bounded game planning
and this small neural experiment are documented; this is not human reasoning.

## Art and animation

UAL1/UAL2 Standard supplies the 65-bone rig and available locomotion/action clips.
The native AnimationTree blends speed/direction, stance, aim and action layers,
with cross-fades between grounded/jump/landing/swim/downed states and timed
interaction/combat clips. CharacterBody3D drives physical movement; animations
run in place. Dedicated authored strafe/rifle clips and foot IK are not present.

The Arctic level uses five newly sourced Kenney CC0 packs: Nature, Survival,
Blaster, Furniture and City Industrial. Geometry is shared/batched for snow and
vegetation; lighting uses inexpensive moon/ambient plus warm local lights.
SMG/rifle/shotgun art comes from the Blaster kit; supplied pistol/sword models
are retained under their original terms. The older Dwarven courtyard remains
for regression tests. Prepared content ships in `game/game-content.pck` and
needs no editor import or local Blender. See `docs/assets.md` and asset credits.

## Verification

```cmd
TestGame.bat
```

This runs Python tool/protocol checks and actual engine cases for collision,
shooting through/around a gate, reload accounting, co-op activation, save/load,
Python and authored mission completion. A C++ domain test can also be built
with MSVC from a developer prompt:

```cmd
cl /std:c++17 /EHsc tests\domain_tests.cpp /Fe:domain_tests.exe
 domain_tests.exe
```

The engine integration runner requires your source-built executable. A stock
Godot binary does not contain LastLightGame and cannot run this project's scene.
See docs/validation.md for checks actually executed in this session.

To reproduce the ready-to-run ZIP after building, extract the official Python
3.12.10 x64 embeddable runtime, then run:

```cmd
py -3 scripts\package_windows.py --python-runtime C:\Dev\python-embed --output LastLight-Windows-x64.zip
```

The package includes Play/Neural launchers, asset/engine notices, a SHA-256
manifest and Verify-Game.bat with 20 gameplay checks.
