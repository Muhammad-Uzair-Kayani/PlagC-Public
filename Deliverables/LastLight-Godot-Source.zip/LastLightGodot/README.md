# Last Light — Godot source-module prototype

Windows 10 x64 / Visual Studio 2022 / low-end integrated graphics. The C++ game
is a built-in Godot module, not a GDExtension or a dynamically loaded game DLL.
Godot is pinned to **4.5.1-stable**, commit in `godot.lock.json`.

## Windows build

Use a short project location such as `C:\Dev\LastLightGodot`. Git long-path
support is configured by setup before cloning. If an older setup attempt
failed with `Filename too long`, apply the updated script and run
`Setup.bat --repair-missing`; see WINDOWS_SETUP_FIX.txt.

Install Git, Python 3.10+ (with the `py` launcher), Visual Studio 2022 **Desktop
development with C++**, MSVC x64 tools and Windows SDK. Premake is not used to
compile Godot. The wrapper invokes SCons with the VS2022 environment.

```cmd
Setup.bat
BuildGame.bat --jobs 1
RunGame.bat
```

On an 8 GB machine use one compile job, keep the Windows page file enabled,
and allow substantial disk space for source and objects. LTO is disabled. The
first source build is lengthy; subsequent module-only rebuilds are incremental.
No performance or Windows build claim should be inferred from Linux checks.

`dist/LastLight.exe` contains the engine and C++ game. `LastLight.pck` contains
resources. Windows GUI subsystem and static C++ runtime are selected. Windows,
GPU drivers and OS libraries remain external dependencies. `--embed` optionally
appends the PCK to an unsigned executable; use the separate PCK workflow when
preparing signed distributions unless an official exporter/signing process is
used. Python remains a separate optional process, never a statically linked
part of Godot.

### Copying the ZIP into your repository

Extract the whole `LastLightGodot` folder as a new subfolder in your existing
repository. Do not overwrite an existing repository-root `.gitmodules` file.
A ZIP cannot store a Git gitlink. Run `Setup.bat` inside this folder once after copying the files.
It finds your enclosing Git repository (or initializes this folder), registers
Godot at the correct relative location, checks out the locked commit and stages
the gitlink. It preserves dirty engine checkouts by refusing to switch them.
Commit the root repository's `.gitmodules`, gitlink, and your project sources.
Afterward normal `git submodule update --init --recursive` works. Do not track
the Godot source as ordinary files or edit engine files to install this module.

## Play

WASD move, mouse turns the third-person camera, Shift sprints, Ctrl crouches,
Space jumps. RMB aims; LMB attacks. 1 selects pistol, 2 selects sword. E picks
up supplies, operates controls, activates radio or revives a nearby survivor.
R reloads, H heals, F eats, G offers a round, X cancels a pending action.
Escape pauses; F5 saves; F9 loads; F10 toggles autoplay; Backspace restarts.
F1 displays blend parameters and navigation/AI diagnostics.

One human and four persistent survivor agents start in the yard. Separate
seeded bot spawns provide an aggressor and scavenger/runner disturbance.
Recover the yellow yard key, activate the radio across the barrier, then get
the surviving team to the green extraction pad. Two distinct actors holding
complementary blue controls for one second open the gate. A southern bypass
works without cooperation. A downed human can let teammates finish via F10.
Casualties are possible; loss of the team or the deadline ends the mission.

## What is real and what is a placeholder

Movement uses Godot CharacterBody3D and real collision. Navigation is baked
from the same static collision geometry. Shooting uses collision raycasts;
melee uses a shape overlap with LOS filtering. The procedural character rig
consumes calculated locomotion/gait/aim weights. These are working test actors,
not the uploaded animation library. Imported rigs use explicit animation names
with crossfades; a verified retargeted asset setup is still required for final
UAL animation integration.

The animation, pistol and map uploads exceeded the execution environment's
32 MiB transfer limit and have **not** been imported or inspected. This source
package therefore uses a clearly labelled procedural test map, actors and
weapons. It does not pretend to contain the supplied Halo map or UAL rigs.
See docs/assets.md for preparing your local originals. Asset integration and
measurement on the target Vega iGPU remain acceptance gates.

## Python policy and training

The runtime is optional; authored AI works without it. To enable inference:

```cmd
RunGame.bat -- --python "C:\Path To Python\python.exe"
```

The first `--` separates Godot arguments from game arguments. The built-in
module launches a persistent Python service with no console, on loopback only,
using a per-process handshake. Features/actions are bounded and request IDs are
checked. Timeout, process death or invalid replies trigger authored fallback.
For a portable distribution, extract an official Windows x64 embeddable Python
runtime and pass `BuildGame.bat --portable-python "C:\path\to\runtime"`.
Then launch with `-- --python "python-runtime\python.exe"` from dist.
The runtime is not included in this source-only archive.

```cmd
py -3 python\train.py train --engine dist\LastLight.exe --population 30 --generations 10
py -3 python\train.py train --engine dist\LastLight.exe --resume reports\training\latest.json --generations 5
py -3 python\train.py evaluate --engine dist\LastLight.exe --model reports\training\champion.json
```

The 374-gene 16-16-6 policy is evolved on real headless Godot episodes. Mandatory
self-care, rescue, key/radio objectives and immediate combat safety remain
rules. Neural intent affects ordinary extraction-stage choices. Fitness rewards
arrival and survival, not kills. Training and held-out seeds are disjoint.
The bundled model is the evaluated champion from a two-genome, one-generation
Godot pipeline check. This validates evaluation/checkpoint plumbing, not a
converged policy or learned social behaviour. See the measured comparison in
docs/samples/comparison.json; it did not improve arrival rate over the rules.

## Verification

```cmd
TestGame.bat
```

This runs Python tool/protocol checks and actual engine cases for collision,
shooting through/around a gate, reload accounting, co-op activation, save/load,
Python and authored mission completion. A C++ domain test can also be built
with MSVC from a developer prompt:

```cmd
cl /std:c++17 /EHsc tests\domain_tests.cpp /Fe:domain_tests.exe
 domain_tests.exe
```

The engine integration runner requires your source-built executable. A stock
Godot binary does not contain LastLightGame and cannot run this project's scene.
See docs/validation.md for checks actually executed in this session.
