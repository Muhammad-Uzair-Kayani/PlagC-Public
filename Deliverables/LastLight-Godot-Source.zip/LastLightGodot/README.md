# Last Light — Godot source-module survival MVP

Windows 10 x64 / Visual Studio 2022 / low-end integrated graphics. The C++ game
is a built-in Godot module, not a GDExtension or a dynamically loaded game DLL.
Godot is pinned to **4.5.1-stable**, commit in `godot.lock.json`.

## Windows build

For an existing checkout affected by the compiler-detection errors, overwrite
project files from this ZIP and follow BUILD_AUDIT_FIX.txt. Keep your existing
`vendor/godot` and `.tools` directories.

Use a short project location such as `C:\Dev\LastLightGodot`. Git long-path
support is configured by setup before cloning. If an older setup attempt
failed with `Filename too long`, apply the updated script and run
`Setup.bat --repair-missing`; see WINDOWS_SETUP_FIX.txt.

Install Git, Python 3.10+ (with the `py` launcher), Visual Studio 2022 **Desktop
development with C++**, MSVC x64 tools and Windows SDK. Put your working `premake5.exe` beside GenerateProjects.bat or on PATH.
Premake generates the Visual Studio frontend; its build task invokes the
required Godot SCons build with the IDE-selected C++ environment.

```cmd
Setup.bat
GenerateProjects.bat vs2022
start "" "build\premake\vs2022\LastLightGodot.sln"
```

In Visual Studio choose **Release | x64**, set **LastLight** as startup project,
and press **Ctrl+F5**. Build/Clean/Rebuild are configured. The batch wrapper initializes MSVC and Python inherits the IDE-selected
compiler environment; a manually initialized
Developer Command Prompt is not required. There is no CMake step. Visual Studio
still needs its C++ compiler and Windows SDK installed.

Build diagnostics are retained in `reports/godot-build.log`.
`BuildGame.bat --configure-only` validates the compiler/SDK and complete Godot
build graph before a long engine compile.

The command-line alternative remains `BuildGame.bat --jobs 1` then RunGame.bat.
It accepts an existing x64 developer environment and detects Preview/Build Tools
installations as well as regular Visual Studio.

On an 8 GB machine use one compile job, keep the Windows page file enabled,
and allow substantial disk space for source and objects. LTO is disabled. The
first source build is lengthy; subsequent module-only rebuilds are incremental.
The acceptance procedure is in `tests/windows_full_build.py`; see
`docs/validation.md` for its recorded results. Target Vega performance still
requires measurement on your machine.

`dist/LastLight.exe` contains the engine and C++ game. `LastLight.pck` contains
resources. Windows GUI subsystem and static C++ runtime are selected. Windows,
GPU drivers and OS libraries remain external dependencies. `--embed` optionally
appends the PCK to an unsigned executable; use the separate PCK workflow when
preparing signed distributions unless an official exporter/signing process is
used. Python remains a separate optional process, never a statically linked
part of Godot.

### Copying the ZIP into your repository

Extract the whole `LastLightGodot` folder as a new subfolder in your existing
repository. Do not overwrite an existing repository-root `.gitmodules` file.
A ZIP cannot store a Git gitlink. Run `Setup.bat` inside this folder once after copying the files.
It finds your enclosing Git repository (or initializes this folder), registers
Godot at the correct relative location, checks out the locked commit and stages
the gitlink. It preserves dirty engine checkouts by refusing to switch them.
Commit the root repository's `.gitmodules`, gitlink, and your project sources.
Afterward normal `git submodule update --init --recursive` works. Do not track
the Godot source as ordinary files or edit engine files to install this module.

## Play

WASD move, mouse turns the third-person camera, Shift sprints, Ctrl crouches,
Space jumps. RMB aims; LMB attacks. 1 selects pistol, 2 selects sword. E picks
up supplies, operates controls, activates radio or revives a nearby survivor.
R reloads, H heals, F eats, G offers a round, X cancels a pending action.
Escape pauses; F5 saves; F9 loads; F10 toggles autoplay; Backspace restarts.
F1 displays blend parameters and navigation/AI diagnostics.

One human and four persistent survivor agents start in the yard. Separate
seeded bot spawns provide an aggressor and scavenger/runner disturbance.
Recover the yellow yard key, activate the radio across the barrier, then get
the surviving team to the green extraction pad. Two distinct actors holding
complementary blue controls for one second open the gate. A southern bypass
works without cooperation. A downed human can let teammates finish via F10.
Casualties are possible; loss of the team or the deadline ends the mission.

## Integrated gameplay and presentation

Start, scenario selection, pause, local options, save/continue, results and
replay flow are included. The native client controls one player, four separate
survivors and up to four distractor bots. Health, hunger, stamina, healing,
revival, ammo/reload, delayed melee, inventory limits, witness-based social
memory, path replanning, cooperative gate, solo bypass and mission/loss states
are implemented. F10 lets you watch the authored or neural survivors finish.

The supplied UAL rig uses real skeletal AnimationTree blending, filtered aim
and timed actions; weapons attach to a hand bone. The Dwarven Expedition kit
from your newer download link supplies dungeon art over the playable courtyard.
Textures are reduced for low-end hardware. `game/game-content.pck` includes the
prepared art; no Godot editor import or local Blender install is required.
See docs/assets.md and game/content/ASSET-CREDITS.txt for asset scope and terms.
The Standard animation library uses forward movement clips; dedicated authored
strafe clips, foot IK, and a large authored campaign are outside this MVP.

## Python policy and training

The runtime is optional; authored AI works without it. To enable inference:

```cmd
RunGame.bat -- --python "C:\Path To Python\python.exe"
```

The first `--` separates Godot arguments from game arguments. The built-in
module launches a persistent Python service with no console, on loopback only,
using a per-process handshake. Features/actions are bounded and request IDs are
checked. Timeout, process death or invalid replies trigger authored fallback.
For a portable distribution, extract an official Windows x64 embeddable Python
runtime and pass `BuildGame.bat --portable-python "C:\path\to\runtime"`.
Then launch with `-- --python "python-runtime\python.exe"` from dist.
The runtime is not included in this source-only archive.

```cmd
py -3 python\train.py train --engine dist\LastLight.exe --population 30 --generations 10
py -3 python\train.py train --engine dist\LastLight.exe --resume reports\training\latest.json --generations 5
py -3 python\train.py evaluate --engine dist\LastLight.exe --model reports\training\champion.json
```

The 374-gene 16-16-6 policy is evolved on real headless Godot episodes. Mandatory
self-care, rescue, reload and immediate combat safety remain rules. Neural
intent affects ordinary choices during all mission stages. Fitness rewards
arrival and survival, not kills. Training and held-out seeds are disjoint.
Training supports bounded parallel episode workers (`--workers`, default 1),
validation selection, exact GA RNG/population checkpoint continuation and
held-out rule/random/memory-ablation comparisons. The source includes measured
training history and comparison reports under docs/samples. These are a small
semester-scale experiment, not a claim that evolution proves general social
intelligence. Fitness does not reward kills or repeated interactions.
See docs/contract.md for features, action masks and protocol semantics.
The shipped experiment used 30 candidates × 3 generations and 100-second
training episodes; held-out evaluation used 300 seconds. See docs/validation.md
for measured results and limits.

Use `-- --autoplay --controller rule --seed 42 --trace "C:\Dev\decisions.ndjson"`
to record decisions; the optional `scripts/plot_training.py` turns training and
comparison files into figures when matplotlib is installed.

## Verification

```cmd
TestGame.bat
```

This runs Python tool/protocol checks and actual engine cases for collision,
shooting through/around a gate, reload accounting, co-op activation, save/load,
Python and authored mission completion. A C++ domain test can also be built
with MSVC from a developer prompt:

```cmd
cl /std:c++17 /EHsc tests\domain_tests.cpp /Fe:domain_tests.exe
 domain_tests.exe
```

The engine integration runner requires your source-built executable. A stock
Godot binary does not contain LastLightGame and cannot run this project's scene.
See docs/validation.md for checks actually executed in this session.

To reproduce the ready-to-run ZIP after building, extract the official Python
3.12.10 x64 embeddable runtime, then run:

```cmd
py -3 scripts\package_windows.py --python-runtime C:\Dev\python-embed --output LastLight-Windows-x64.zip
```

The package includes Play/Neural launchers, asset/engine notices, a SHA-256
manifest and Verify-Game.bat with 20 gameplay checks.
