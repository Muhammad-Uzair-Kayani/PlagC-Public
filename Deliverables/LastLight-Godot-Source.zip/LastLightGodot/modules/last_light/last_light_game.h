#pragma once
#include "core/io/stream_peer_tcp.h"
#include "core/io/tcp_server.h"
#include "core/io/file_access.h"
#include "domain.h"
#include "world_contract.h"
#include "scene/3d/bone_attachment_3d.h"
#include "scene/3d/camera_3d.h"
#include "scene/3d/mesh_instance_3d.h"
#include "scene/3d/navigation/navigation_agent_3d.h"
#include "scene/3d/navigation/navigation_region_3d.h"
#include "scene/3d/node_3d.h"
#include "scene/3d/physics/character_body_3d.h"
#include "scene/3d/physics/collision_shape_3d.h"
#include "scene/3d/physics/spring_arm_3d.h"
#include "scene/3d/physics/static_body_3d.h"
#include "scene/3d/skeleton_3d.h"
#include "scene/animation/animation_player.h"
#include "scene/animation/animation_tree.h"
#include "scene/gui/label.h"
#include "scene/resources/3d/capsule_shape_3d.h"
#include "scene/resources/packed_scene.h"
#include <map>
#include <random>
#include <set>
#include <vector>
class LastLightGame : public Node3D {
	GDCLASS(LastLightGame, Node3D);
	struct Actor {
		int bot_role = 0;
		lastlight::Stats stats;
		CharacterBody3D *body = nullptr;
		Node3D *visual = nullptr, *left_leg = nullptr, *right_leg = nullptr, *left_arm = nullptr, *right_arm = nullptr;
		MeshInstance3D *pistol = nullptr, *sword = nullptr;
		NavigationAgent3D *nav = nullptr;
		AnimationPlayer *animation = nullptr;
		AnimationTree *animation_tree = nullptr;
		Skeleton3D *skeleton = nullptr;
		BoneAttachment3D *weapon_socket = nullptr;
		Node3D *pistol_model = nullptr, *sword_model = nullptr;
		CollisionShape3D *collider = nullptr;
		Ref<CapsuleShape3D> capsule;
		std::set<int> visible_actors, visible_items;
		Vector3 spawn_position, heard_position;
		double heard_until = 0, hit_feedback_time = -100;
		bool melee_pending = false;
		float travelled = 0, arrived_health = 0, arrived_time = 0;
		lastlight::Blend blend;
		std::map<int, lastlight::Belief> memory;
		Vector3 target, move;
		bool crouching = false, sprint = false, aiming = false, interacting = false, use_sword = false, jump = false;
		float yaw = 0, path_retry = 0, visual_yaw_offset = 0;
		String animation_state;
		String reason = "Spawned", intent = "Progress", last_clip;
	};
	struct Item {
		int id;
		String kind;
		Vector3 position;
		Node3D *visual = nullptr;
		bool available = true;
	};
	std::vector<Actor> actors;
	std::vector<Item> items;
	std::vector<String> map_rows;
	NavigationRegion3D *region = nullptr;
	StaticBody3D *gate = nullptr;
	MeshInstance3D *gate_mesh = nullptr;
	Node3D *gate_model = nullptr;
	float gate_lift = 0;
	bool gate_opening = false;
	Node3D *camera_rig = nullptr;
	SpringArm3D *arm = nullptr;
	Camera3D *camera = nullptr;
	Label *hud = nullptr;
	Label *message_label = nullptr;
	Label *legacy_crosshair = nullptr;
	bool frontend_attached = false, session_started = true, automated_run = false;
	String frontend_mode = "playing", interaction_hint;
	float mouse_sensitivity = .0025f;
	bool invert_mouse = false;
	int event_sequence = 0, cooperative_uses = 0, harmful_attacks = 0;
	Dictionary scene_cache;
	Ref<TCPServer> python_server;
	Ref<StreamPeerTCP> python_peer;
	int64_t python_pid = 0;
	String python_buffer, python_token;
	int request_id = 0, pending_request = 0;
	double request_time = 0;
	bool python_ready = false;
	std::map<int, String> policy;
	std::map<int, std::set<String>> request_masks;
	Dictionary config, assets;
	std::mt19937 rng;
	int seed = 42, mission = 0, spawn_count = 2;
	bool reported = false;
	bool integration_ok = true;
	Ref<FileAccess> trace_file;
	void integration_step();
	bool gate_open = false, key_found = false, radio_done = false, paused = false, victory = false, defeat = false, autoplay = false, smoke = false, debug_overlay = false;
	double elapsed = 0, ai_clock = 0, hud_clock = 0, gate_hold = 0;
	int camera_focus = 1;
	int physics_frames = 0, max_frames = 18000;
	int shots_hit = 0, wall_blocks = 0, revivals = 0, pickups = 0, python_failures = 0;
	float camera_yaw = -2.35619449f, camera_pitch = -.3f;
	String policy_path, controller = "rule";
	String message, report_path, script_case, python_executable, save_path = "user://save.json";
	double message_time = 0;
	Array journal;
	Vector3 key_position, radio_position, exit_position, control_a, control_b;
	Node3D *level_root = nullptr;
	static void _bind_methods();
	void _notification(int what);
	void input(const Ref<InputEvent> &event) override;
	void setup();
	void create_level();
	void create_actor(int id, const Vector3 &position, bool survivor, const Color &color);
	void physics(float dt);
	void decide(Actor &a);
	void move_actor(Actor &a, float dt);
	void animate(Actor &a, float dt, const Vector3 &delta);
	bool visible(const Actor &a, const Actor &b, float range = 18) const;
	bool clear_line(const Vector3 &from, const Vector3 &to) const;
	Actor *find_actor(int id);
	const Actor *find_actor(int id) const;
	void shoot(Actor &a);
	void melee(Actor &a);
	void interact(Actor &a);
	void emit_event(int actor, int target, const String &kind, const Vector3 &where);
	void update_objectives(float dt);
	void update_hud();
	void notify(const String &text);
	void restart();
	Node3D *make_box(Node3D *parent, const Vector3 &position, const Vector3 &size, const Color &color, bool collision = false);
	void try_asset(Actor &a);
	void decorate_level();
	Node3D *place_asset(const String &path, const Vector3 &position, const Vector3 &size, bool collision = false);
	Ref<Material> level_material(bool floor);
	Ref<PackedScene> load_asset_scene(const String &path);
	void setup_animation_graph(Actor &a);
	void update_animation_graph(Actor &a, float dt, const Vector3 &velocity);
	void configure_bots(int count);
	void sense(Actor &a);
	Dictionary build_observation(const Actor &a) const;
	void apply_melee(Actor &a);
	void start_python();
	void poll_python();
	void request_policy();
	void send_python(const Dictionary &data);
	void stop_python();
	Dictionary snapshot() const;
	bool restore(const Dictionary &data);
	bool save_game();
	bool load_game();
	void finish_report();

public:
	void attach_frontend();
	Dictionary get_game_state() const;
	bool game_command(const String &command, const Dictionary &payload = Dictionary());
	void apply_options(const Dictionary &options);
	LastLightGame() = default;
	~LastLightGame();
};
