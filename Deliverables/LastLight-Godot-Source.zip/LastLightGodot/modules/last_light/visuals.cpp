#include "core/io/resource_loader.h"
#include "last_light_game.h"
#include "modules/gltf/gltf_document.h"
#include "modules/gltf/gltf_state.h"
#include "scene/animation/animation_blend_space_1d.h"
#include "scene/animation/animation_blend_tree.h"
#include "scene/resources/animation_library.h"
#include "scene/resources/material.h"
#include "servers/display_server.h"

namespace {
AnimationPlayer *find_player(Node *node) {
	if (auto value = Object::cast_to<AnimationPlayer>(node)) {
		return value;
	}
	for (int i = 0; i < node->get_child_count(); ++i) {
		if (auto value = find_player(node->get_child(i))) {
			return value;
		}
	}
	return nullptr;
}
Skeleton3D *find_skeleton(Node *node) {
	if (auto value = Object::cast_to<Skeleton3D>(node)) {
		return value;
	}
	for (int i = 0; i < node->get_child_count(); ++i) {
		if (auto value = find_skeleton(node->get_child(i))) {
			return value;
		}
	}
	return nullptr;
}
Ref<AnimationNodeAnimation> clip(const String &name) {
	Ref<AnimationNodeAnimation> node;
	node.instantiate();
	node->set_animation(name);
	return node;
}
void tint(Node *node, const Color &color) {
	if (auto mesh = Object::cast_to<MeshInstance3D>(node); mesh && mesh->get_mesh().is_valid()) {
		if (mesh->get_mesh()->get_surface_count() > 0) {
			Ref<StandardMaterial3D> mat;
			mat.instantiate();
			mat->set_albedo(color);
			mat->set_roughness(.8);
			mesh->set_surface_override_material(0, mat);
		}
	}
	for (int i = 0; i < node->get_child_count(); ++i) {
		tint(node->get_child(i), color);
	}
}
} //namespace

Ref<PackedScene> LastLightGame::load_asset_scene(const String &path) {
	if (path.is_empty()) {
		return Ref<PackedScene>();
	}
	if (scene_cache.has(path)) {
		return scene_cache[path];
	}
	Ref<PackedScene> packed;
	if (path.get_extension().to_lower() == "glb") {
		Ref<GLTFDocument> document;
		document.instantiate();
		Ref<GLTFState> state;
		state.instantiate();
		if (document->append_from_file(path, state) != OK) {
			return packed;
		}
		Node *node = document->generate_scene(state);
		if (!node) {
			return packed;
		}
		packed.instantiate();
		if (packed->pack(node) != OK) {
			packed.unref();
		}
		memdelete(node);
	} else if (ResourceLoader::exists(path)) {
		packed = ResourceLoader::load(path);
	}
	if (packed.is_valid()) {
		scene_cache[path] = packed;
	}
	return packed;
}

void LastLightGame::try_asset(Actor &a) {
	Ref<PackedScene> packed = load_asset_scene(assets.get("survivor_scene", String()));
	if (packed.is_null()) {
		return;
	}
	Node *node = packed->instantiate();
	auto visual = Object::cast_to<Node3D>(node);
	if (!visual) {
		memdelete(node);
		return;
	}
	a.body->add_child(visual);
	const float scale = assets.get("survivor_scale", .94);
	visual->set_scale(Vector3(1, 1, 1) * scale);
	a.visual_yaw_offset = Math::deg_to_rad(float(assets.get("survivor_yaw_degrees", 180.)));
	a.visual->hide();
	a.visual = visual;
	a.animation = find_player(visual);
	a.skeleton = find_skeleton(visual);
	const Color colors[] = { Color(.22, .55, .64), Color(.66, .48, .3), Color(.34, .55, .43), Color(.5, .4, .64), Color(.26, .52, .59) };
	tint(visual, a.stats.survivor ? colors[(a.stats.id - 1) % 5] : a.bot_role == 0 ? Color(.6, .25, .23)
																				   : Color(.6, .5, .25));
	if (a.animation) {
		Ref<PackedScene> actions = load_asset_scene(assets.get("actions_scene", String()));
		if (actions.is_valid()) {
			Node *extra = actions->instantiate();
			if (auto player = find_player(extra); player && player->has_animation_library(StringName())) {
				a.animation->add_animation_library("extra", player->get_animation_library(StringName()));
			}
			memdelete(extra);
		}
		List<StringName> animations;
		a.animation->get_animation_list(&animations);
		for (const auto &name : animations) {
			Ref<Animation> animation = a.animation->get_animation(name);
			if (String(name).contains("Loop") || String(name) == "Sword_Idle") {
				animation->set_loop_mode(Animation::LOOP_LINEAR);
			}
		}
		setup_animation_graph(a);
	}
	visual->set_rotation(Vector3(0, a.yaw + a.visual_yaw_offset, 0));
	if (a.skeleton && a.skeleton->find_bone("hand_r") >= 0) {
		a.animation->play("Pistol_Aim_Neutral");
		a.animation->advance(0);
		a.animation->stop(true);
		Basis hand = a.skeleton->get_global_transform().basis * a.skeleton->get_bone_global_pose(a.skeleton->find_bone("hand_r")).basis;
		Basis calibration = hand.orthonormalized().inverse() * a.visual->get_global_transform().basis.orthonormalized();
		a.weapon_socket = memnew(BoneAttachment3D);
		a.skeleton->add_child(a.weapon_socket);
		a.weapon_socket->set_bone_name("hand_r");
		for (const String kind : { String("pistol"), String("sword") }) {
			Ref<PackedScene> weapon = load_asset_scene(assets.get(kind + "_scene", String()));
			if (weapon.is_null()) {
				continue;
			}
			auto model = Object::cast_to<Node3D>(weapon->instantiate());
			if (!model) {
				continue;
			}
			a.weapon_socket->add_child(model);
			Dictionary transforms = assets.get(kind + "_transform", Dictionary());
			Array translation = transforms.get("position", Array());
			Array rotation = transforms.get("rotation", Array());
			if (translation.size() == 3) {
				model->set_position(Vector3(translation[0], translation[1], translation[2]));
			}
			if (rotation.size() == 3) {
				model->set_rotation_degrees(Vector3(rotation[0], rotation[1], rotation[2]));
			}
			model->set_basis(calibration * model->get_basis());
			if (kind == "pistol") {
				a.pistol_model = model;
			} else {
				a.sword_model = model;
			}
		}
	}
}

void LastLightGame::setup_animation_graph(Actor &a) {
	if (!a.animation->has_animation("Idle_Loop")) {
		return;
	}
	Ref<AnimationNodeBlendTree> graph;
	graph.instantiate();
	Ref<AnimationNodeBlendSpace1D> movement;
	movement.instantiate();
	movement->set_min_space(0);
	movement->set_max_space(5);
	movement->add_blend_point(clip("Idle_Loop"), 0);
	movement->add_blend_point(clip("Walk_Loop"), 2);
	movement->add_blend_point(clip("Jog_Fwd_Loop"), 3.5);
	movement->add_blend_point(clip("Sprint_Loop"), 5);
	Ref<AnimationNodeBlendSpace1D> crouch;
	crouch.instantiate();
	crouch->set_min_space(0);
	crouch->set_max_space(1.5);
	crouch->add_blend_point(clip("Crouch_Idle_Loop"), 0);
	crouch->add_blend_point(clip("Crouch_Fwd_Loop"), 1.5);
	Ref<AnimationNodeBlend2> stance;
	stance.instantiate();
	graph->add_node("Move", movement);
	graph->add_node("Crouch", crouch);
	graph->add_node("Stance", stance);
	graph->connect_node("Stance", 0, "Move");
	graph->connect_node("Stance", 1, "Crouch");
	Ref<AnimationNodeBlendSpace1D> aim;
	aim.instantiate();
	aim->set_min_space(-1);
	aim->set_max_space(1);
	aim->add_blend_point(clip("Pistol_Aim_Down"), -1);
	aim->add_blend_point(clip("Pistol_Aim_Neutral"), 0);
	aim->add_blend_point(clip("Pistol_Aim_Up"), 1);
	graph->add_node("AimPose", aim);
	Ref<AnimationNodeBlend2> upper;
	upper.instantiate();
	upper->set_filter_enabled(true);
	Ref<AnimationNodeOneShot> action;
	action.instantiate();
	action->set_fade_in_time(.06);
	action->set_fade_out_time(.12);
	action->set_filter_enabled(true);
	Ref<Animation> sample = a.animation->get_animation("Pistol_Aim_Neutral");
	for (int t = 0; t < sample->get_track_count(); ++t) {
		NodePath path = sample->track_get_path(t);
		if (path.get_subname_count() == 0) {
			continue;
		}
		String bone = path.get_subname(0);
		if (bone.contains("spine") || bone.contains("clavicle") || bone.contains("arm") || bone.contains("hand") || bone.contains("finger") || bone.contains("thumb") || bone.contains("index") || bone.contains("middle") || bone.contains("ring") || bone.contains("pinky") || bone.contains("neck") || bone.to_lower().contains("head")) {
			upper->set_filter_path(path, true);
			action->set_filter_path(path, true);
		}
	}
	graph->add_node("Upper", upper);
	graph->connect_node("Upper", 0, "Stance");
	graph->connect_node("Upper", 1, "AimPose");
	graph->add_node("ActionClip", clip("Pistol_Shoot"));
	Ref<AnimationNodeTimeScale> action_speed;
	action_speed.instantiate();
	graph->add_node("ActionSpeed", action_speed);
	graph->connect_node("ActionSpeed", 0, "ActionClip");
	graph->add_node("Action", action);
	graph->connect_node("Action", 0, "Upper");
	graph->connect_node("Action", 1, "ActionSpeed");
	Ref<AnimationNodeBlend2> air;
	air.instantiate();
	graph->add_node("Air", air);
	graph->add_node("Jump", clip("Jump_Loop"));
	graph->connect_node("Air", 0, "Action");
	graph->connect_node("Air", 1, "Jump");
	graph->add_node("DeathClip", clip("Death01"));
	Ref<AnimationNodeBlend2> life;
	life.instantiate();
	graph->add_node("Life", life);
	graph->connect_node("Life", 0, "Air");
	graph->connect_node("Life", 1, "DeathClip");
	graph->connect_node("output", 0, "Life");
	a.animation_tree = memnew(AnimationTree);
	a.body->add_child(a.animation_tree);
	a.animation_tree->set_animation_player(a.animation_tree->get_path_to(a.animation));
	a.animation_tree->set_root_animation_node(graph);
	a.animation_tree->set_callback_mode_process(AnimationMixer::ANIMATION_CALLBACK_MODE_PROCESS_MANUAL);
	a.animation_tree->set_active(true);
}

void LastLightGame::update_animation_graph(Actor &a, float dt, const Vector3 &velocity) {
	if (DisplayServer::get_singleton()->get_name() == "headless" && physics_frames > 5 && script_case != "assets") {
		return;
	}
	auto tree = a.animation_tree;
	const bool dead = a.stats.state == lastlight::State::Dead || a.stats.state == lastlight::State::Downed;
	tree->set("parameters/Move/blend_position", velocity.length());
	tree->set("parameters/Crouch/blend_position", velocity.length());
	tree->set("parameters/Stance/blend_amount", a.blend.crouch + (a.crouching ? a.blend.idle : 0));
	tree->set("parameters/Upper/blend_amount", a.stats.inventory.pistol && !a.use_sword ? (a.aiming ? 1.f : .65f) : 0.f);
	tree->set("parameters/AimPose/blend_position", a.stats.id == 1 ? CLAMP(camera_pitch, -1.f, 1.f) : 0.f);
	tree->set("parameters/Air/blend_amount", a.stats.state == lastlight::State::Airborne ? 1.f : 0.f);
	tree->set("parameters/Life/blend_amount", dead ? 1.f : 0.f);
	const String state = lastlight::state_name(a.stats.state);
	if (state != a.animation_state) {
		String name;
		float duration = 1;
		if (a.stats.state == lastlight::State::Fire) {
			name = "Pistol_Shoot";
			duration = .25;
		}
		if (a.stats.state == lastlight::State::Reload) {
			name = "Pistol_Reload";
			duration = 1.7;
		}
		if (a.stats.state == lastlight::State::Melee) {
			name = a.stats.inventory.sword && a.use_sword ? "extra/Sword_Regular_A" : "Punch_Jab";
			duration = .55;
		}
		if (a.stats.state == lastlight::State::Heal) {
			name = "extra/Consume";
			duration = 1.5;
		}
		if (a.stats.state == lastlight::State::Revive) {
			name = "Fixing_Kneeling";
			duration = 2;
		}
		if (a.stats.state == lastlight::State::Stunned) {
			name = "Hit_Chest";
			duration = .3;
		}
		if (!name.is_empty() && a.animation->has_animation(name)) {
			Ref<AnimationNodeBlendTree> graph = tree->get_root_animation_node();
			Ref<AnimationNodeAnimation> action = graph->get_node("ActionClip");
			action->set_animation(name);
			tree->set("parameters/ActionSpeed/scale", a.animation->get_animation(name)->get_length() / duration);
			tree->set("parameters/Action/request", AnimationNodeOneShot::ONE_SHOT_REQUEST_FIRE);
		}
		a.animation_state = state;
	}
	tree->advance(dt);
}
