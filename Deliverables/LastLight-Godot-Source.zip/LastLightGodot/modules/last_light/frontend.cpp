#include "core/config/engine.h"
#include "core/input/input.h"
#include "core/io/file_access.h"
#include "core/os/os.h"
#include "last_light_game.h"
#include "scene/main/scene_tree.h"
#include "scene/resources/navigation_mesh.h"
#include <cmath>

namespace {
const char *names[] = { "You", "Maya", "Rafi", "Lian", "Omar" };
float distance_flat(Vector3 a, Vector3 b) {
	a.y = 0;
	b.y = 0;
	return a.distance_to(b);
}
} //namespace

void LastLightGame::configure_bots(int count) {
	spawn_count = CLAMP(count, 0, 4);
	for (auto &a : actors) {
		if (a.stats.survivor) {
			continue;
		}
		const bool active = a.stats.id - 10 < spawn_count;
		a.stats.health = active ? 100 : 0;
		a.stats.state = active ? lastlight::State::Idle : lastlight::State::Dead;
		a.stats.timer = a.stats.cooldown = a.stats.bleed = 0;
		a.stats.inventory.pistol = a.bot_role == 0;
		a.stats.inventory.rounds = a.bot_role == 0 ? 6 : 0;
		a.stats.inventory.reserve = 0;
		a.body->set_visible(active);
		a.body->set_collision_layer(active ? 2 : 0);
	}
}

void LastLightGame::sense(Actor &a) {
    for(auto &[id,belief]:a.memory) { if(elapsed-belief.last_attack>6) { belief.threat*=.985f; } }
	a.visible_actors.clear();
	a.visible_items.clear();
	if (!a.stats.active()) {
		return;
	}
	for (auto &other : actors) {
		if (visible(a, other)) {
			a.visible_actors.insert(other.stats.id);
			a.memory[other.stats.id].last_seen = elapsed;
		}
	}
	for (auto &item : items) {
		if (item.available && distance_flat(a.body->get_position(), item.position) < 14 &&
				clear_line(a.body->get_position() + Vector3(0, 1.2, 0), item.position)) {
			a.visible_items.insert(item.id);
		}
	}
}

void LastLightGame::attach_frontend() {
	frontend_attached = true;
	for (auto &a : actors) {
		if (a.animation_tree) {
			update_animation_graph(a, 1.f / 60, Vector3());
		}
	}
	if (hud) {
		hud->hide();
	}
	if (message_label) {
		message_label->hide();
	}
	if (legacy_crosshair) {
		legacy_crosshair->hide();
	}
	if (!automated_run) {
		session_started = false;
		paused = true;
		frontend_mode = "menu";
		Input::get_singleton()->set_mouse_mode(Input::MOUSE_MODE_VISIBLE);
	}
}

void LastLightGame::apply_options(const Dictionary &options) {
	Variant input = options.get("sensitivity", mouse_sensitivity);
	if (input.get_type() != Variant::FLOAT && input.get_type() != Variant::INT) { return; }
	const double sensitivity = input;
	if (std::isfinite(sensitivity)) {
		mouse_sensitivity = CLAMP(sensitivity, .0005, .01);
	}
	if (options.get("invert_y", Variant()).get_type() == Variant::BOOL) {
		invert_mouse = options["invert_y"];
	}
}

bool LastLightGame::game_command(const String &command, const Dictionary &payload) {
	if (command == "quit") {
		get_tree()->quit();
		return true;
	}
	if (command == "start" && !session_started) {
		Variant count = payload.get("bots", spawn_count);
		if (count.get_type() != Variant::INT || int(count) < 0 || int(count) > 4) {
			return false;
		}
		configure_bots(int(count));
		session_started = true;
		paused = false;
		frontend_mode = "playing";
		Input::get_singleton()->set_mouse_mode(Input::MOUSE_MODE_CAPTURED);
		notify("Recover the yard key. Helping survivors is optional; every survivor has a solo route.");
		return true;
	}
	if (command == "load") {
		if (!load_game()) {
			return false;
		}
		session_started = true;
		paused = false;
		frontend_mode = "playing";
		Input::get_singleton()->set_mouse_mode(Input::MOUSE_MODE_CAPTURED);
		return true;
	}
	if (command == "menu" || command == "restart") {
		restart();
		return true;
	}
	if (!session_started || victory || defeat) {
		return false;
	}
	if (command == "pause" || command == "resume") {
		paused = command == "pause";
		frontend_mode = paused ? "pause" : "playing";
		Input::get_singleton()->set_mouse_mode(paused ? Input::MOUSE_MODE_VISIBLE : Input::MOUSE_MODE_CAPTURED);
		return true;
	}
	if (command == "save") {
		return save_game();
	}
	if (command == "autoplay") {
		autoplay = !autoplay;
		return true;
	}
	if (paused) {
		return false;
	}
	auto player = find_actor(1);
	if (!player || !player->stats.active()) {
		return false;
	}
	if (command == "reload") {
		return lastlight::begin(player->stats, lastlight::State::Reload);
	}
	if (command == "heal") {
		return lastlight::begin(player->stats, lastlight::State::Heal);
	}
	if (command == "cancel") {
		lastlight::cancel(player->stats);
		return true;
	}
	return false;
}

Dictionary LastLightGame::get_game_state() const {
	Dictionary out;
	const Actor *p = find_actor(1);
	if (!p) {
		return out;
	}
	out["mode"] = victory || defeat ? "results" : frontend_mode;
	out["started"] = session_started;
	out["paused"] = paused;
	out["victory"] = victory;
	out["defeat"] = defeat;
	out["mission"] = mission;
	out["elapsed"] = elapsed;
	out["deadline"] = config.get("deadline_seconds", 600);
	out["health"] = p->stats.health;
	out["stamina"] = p->stats.stamina;
	out["hunger"] = p->stats.hunger;
	out["medkits"] = p->stats.inventory.medkits;
	out["food"] = p->stats.inventory.food;
	out["rounds"] = p->stats.inventory.rounds;
	out["reserve"] = p->stats.inventory.reserve;
	out["weapon"] = p->use_sword && p->stats.inventory.sword ? "SWORD" : p->stats.inventory.pistol && !p->use_sword ? "PISTOL"
																													: "UNARMED";
	out["player_state"] = lastlight::state_name(p->stats.state);
	out["action_timer"] = p->stats.timer;
	out["message"] = message_time > 0 ? message : String();
	out["hint"] = interaction_hint;
	out["debug"] = debug_overlay;
	out["autoplay"] = autoplay;
	out["python"] = python_ready;
	out["python_failures"] = python_failures;
	out["save_available"] = FileAccess::exists(save_path);
	out["bots"] = spawn_count;
	out["gate_open"] = gate_open;
	out["gate_hold"] = CLAMP(gate_hold, 0., 1.);
	out["hit_confirm"] = elapsed - p->hit_feedback_time < .18;
	out["shots_hit"] = shots_hit;
	out["revives"] = revivals;
	out["pickups"] = pickups;
	out["fps"] = Engine::get_singleton()->get_frames_per_second();
	out["navigation_polygons"] = region && region->get_navigation_mesh().is_valid() ? region->get_navigation_mesh()->get_polygon_count() : 0;
	Vector3 destination = mission == 0 ? key_position : mission == 1 ? radio_position
																	 : exit_position;
	out["objective_distance"] = distance_flat(p->body->get_position(), destination);
	out["player_position"] = Vector2(p->body->get_position().x, p->body->get_position().z);
	out["objective_position"] = Vector2(destination.x, destination.z);
	out["map_rows"] = config.get("map", Array());
	out["camera_yaw"] = camera_yaw;
	Array team, seen_items, events;
	int arrived = 0, alive = 0;
	for (auto &a : actors) {
		if (!a.stats.survivor) {
			continue;
		}
		bool known = a.stats.id == 1 || radio_done || p->visible_actors.count(a.stats.id);
		Dictionary row;
		row["id"] = a.stats.id;
		row["name"] = names[a.stats.id - 1];
		row["known"] = known;
		row["health"] = known ? a.stats.health : -1;
		row["state"] = known ? String(lastlight::state_name(a.stats.state)) : "Out of sight";
		row["reason"] = known ? a.reason : "No recent contact";
		row["position"] = known ? Vector2(a.body->get_position().x, a.body->get_position().z) : Vector2(-100, -100);
		auto memory = p->memory.find(a.stats.id);
		row["trust"] = memory == p->memory.end() ? 0.f : memory->second.trust;
		row["threat"] = memory == p->memory.end() ? 0.f : memory->second.threat;
		if (a.stats.state == lastlight::State::Extracted) {
			++arrived;
		}
		if (a.stats.health > 0) {
			++alive;
		}
		team.push_back(row);
	}
	for (auto &item : items) {
		if (item.available && p->visible_items.count(item.id)) {
			Dictionary row;
			row["kind"] = item.kind;
			row["position"] = Vector2(item.position.x, item.position.z);
			seen_items.push_back(row);
		}
	}
	for (int i = MAX(0, journal.size() - 6); i < journal.size(); ++i) {
		events.push_back(journal[i]);
	}
	out["team"] = team;
	out["items"] = seen_items;
	out["events"] = events;
	out["arrived"] = arrived;
	out["alive"] = alive;
	return out;
}
