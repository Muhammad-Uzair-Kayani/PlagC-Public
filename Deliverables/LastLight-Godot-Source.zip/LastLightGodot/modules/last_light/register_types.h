#pragma once
#include "modules/register_module_types.h"
void initialize_last_light_module(ModuleInitializationLevel p_level);
void uninitialize_last_light_module(ModuleInitializationLevel p_level);
