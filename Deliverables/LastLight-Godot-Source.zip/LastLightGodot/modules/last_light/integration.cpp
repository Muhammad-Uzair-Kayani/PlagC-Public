#include "last_light_game.h"
#include "scene/main/scene_tree.h"

void LastLightGame::integration_step() {
    using namespace lastlight;
    auto player=find_actor(1);
    auto peer=find_actor(2);
    if (script_case=="assets") {
        if(physics_frames==4) {
            integration_ok=gate_model!=nullptr;
            for(auto &actor:actors) {
                integration_ok=integration_ok && actor.skeleton && actor.animation_tree && actor.weapon_socket && actor.pistol_model && actor.sword_model;
                if(actor.animation) { for(const String &name:{String("Idle_Loop"),String("Walk_Loop"),String("Sprint_Loop"),String("Pistol_Reload"),String("extra/Sword_Regular_A")}) { integration_ok=integration_ok && actor.animation->has_animation(name); } }
            }
            player->stats.inventory.pistol=true;player->stats.inventory.rounds=1;
            player->target=player->body->get_position();player->nav->set_target_position(player->target);
        }
        if(physics_frames==30) { integration_ok=integration_ok && begin(player->stats,State::Reload); }
        if(physics_frames==60) { integration_ok=integration_ok && bool(player->animation_tree->get("parameters/Action/active")); }
        if(physics_frames==150) { integration_ok=integration_ok && player->stats.inventory.rounds==6; player->stats.inventory.sword=true;player->use_sword=true;melee(*player); }
        if(physics_frames==165) { integration_ok=integration_ok && player->stats.state==State::Melee && bool(player->animation_tree->get("parameters/Action/active")); }
    }
    if(script_case=="social") {
        if(physics_frames==4) {
            player->body->set_position(Vector3(8,.1,14));peer->body->set_position(Vector3(10,.1,14));
            find_actor(3)->body->set_position(Vector3(28,.1,14));
            emit_event(1,2,"help",Vector3(8,1,14));
            integration_ok=peer->memory[1].trust>.2f && find_actor(3)->memory[1].trust==0;
            emit_event(1,2,"attack",Vector3(8,1,14));
            integration_ok=integration_ok && peer->memory[1].threat>.5f && find_actor(3)->memory[1].threat==0;
        }
    }
    if(script_case=="gate_negative") {
        if(physics_frames==4) { peer->body->set_position(control_a+Vector3(0,.1,0));peer->interacting=true; }
        if(physics_frames==150) { integration_ok=integration_ok && !gate_open && gate_hold==0;peer->interacting=false; }
    }
    if(script_case=="melee") {
        if(physics_frames==4) {
            player->body->set_position(Vector3(8,.1,14));peer->body->set_position(Vector3(8,.1,12.8));
            player->stats.inventory.sword=true;player->use_sword=true;player->yaw=0;
            player->target=player->body->get_position();player->nav->set_target_position(player->target);
            peer->target=peer->body->get_position();peer->nav->set_target_position(peer->target);
            melee(*player);
        }
        if(physics_frames==12) { integration_ok=integration_ok && peer->stats.health==100; }
        if(physics_frames==40) { integration_ok=integration_ok && peer->stats.health==65; }
        if(physics_frames==80) { integration_ok=integration_ok && peer->stats.health==65;melee(*player);cancel(player->stats); }
        if(physics_frames==120) { integration_ok=integration_ok && peer->stats.health==65; }
    }
    if(script_case=="lifecycle") {
        if(physics_frames==4) {
            for(auto &actor:actors) { if(actor.stats.survivor){ actor.stats.health=0;actor.stats.state=State::Dead; } }
        }
    }
}
