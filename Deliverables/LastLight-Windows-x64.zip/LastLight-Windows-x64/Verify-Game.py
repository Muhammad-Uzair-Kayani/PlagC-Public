"""Validate the delivered binary and bundled Python, without build tools."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if os.name != 'nt':
        raise RuntimeError('This package is built for 64-bit Windows')
    for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        expected, relative = line.split('  ', 1)
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Missing or damaged package file: ' + relative)
    print('Package integrity passed.', flush=True)
    output = ROOT / 'diagnostics'
    output.mkdir(exist_ok=True)
    env = os.environ.copy()
    env['APPDATA'] = str(output / 'app-data')
    env['LOCALAPPDATA'] = str(output / 'local-data')
    for case in ('physics', 'combat', 'gate', 'save', 'python', 'fallback', 'python_exit', 'solo', 'autoplay'):
        report = output / (case + '.json')
        report.unlink(missing_ok=True)
        command = [str(ROOT / 'LastLight.exe'), '--headless', '--fixed-fps', '60', '--max-fps', '0', '--',
                   '--smoke', '--case', case, '--frames', '18000' if case in ('solo', 'autoplay') else '360',
                   '--bots', '1' if case == 'combat' else '2' if case == 'autoplay' else '0',
                   '--report', str(report)]
        if case in ('python', 'python_exit'):
            command += ['--python', str(ROOT / 'python-runtime/python.exe')]
        if case == 'fallback':
            command += ['--python', str(output / 'missing-python.exe')]
        with (output / (case + '.log')).open('w', encoding='utf-8') as log:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=120)
        if result.returncode or not report.is_file():
            raise RuntimeError(case + ' did not finish successfully; inspect diagnostics/' + case + '.log')
        data = json.loads(report.read_text(encoding='utf-8'))
        if not data.get('test_passed') or data.get('navigation_polygons', 0) < 1:
            raise RuntimeError(case + ' reported a gameplay failure')
        if case == 'python' and data['python_failures']:
            raise RuntimeError('Bundled Python failed to provide the policy service')
        if case in ('fallback', 'python_exit') and data['python_failures'] < 1:
            raise RuntimeError('Expected Python fallback was not exercised')
        if case in ('solo', 'autoplay') and data['phase'] != 'Victory':
            raise RuntimeError(case + ' did not complete the mission')
        print(case + ': passed', flush=True)
    print('All nine portable Windows game checks passed.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print('Verification failed: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
