LAST LIGHT - READY-TO-RUN WINDOWS x64 PROTOTYPE

1. Extract the WHOLE ZIP into a writable folder, such as your Desktop.
2. Open the LastLight-Windows-x64 folder.
3. Double-click Play.bat.

No Visual Studio, Premake, Godot editor, Python installation or build is needed.
Keep LastLight.exe and LastLight.pck together. Do not run inside the ZIP viewer.
Play.bat uses windowed 960x540, OpenGL Compatibility, and a 30 FPS cap.
You can also double-click LastLight.exe (default window is 1280x720).

OPTIONAL PYTHON / NEURAL TEST
Close the first game, then double-click Play-With-Neural-AI.bat.
An official portable Python 3.12.10 x64 runtime is included. It runs a local
policy service; C++ remains authoritative. Authored AI is the normal default
and is also the fallback if Python fails. This is not a fully trained policy.

CONTROLS
WASD: move      Mouse: camera       Shift: sprint     Ctrl: crouch
Space: jump     RMB: aim            LMB: attack       1/2: pistol/sword
E: interact/pick up/revive          R: reload         H: heal
F: eat         G: offer a round     X: cancel action
Esc: pause     F5: save             F9: load          F10: autoplay
Backspace: restart                 F1: controls/debug HUD

MISSION
One human and four survivor agents start in the yard, with two seeded bots.
Get the yellow key, activate the radio across the barrier, then reach the
green extraction pad. Two different actors holding the blue controls open
the gate; a southern bypass also works. F10 lets the AI demonstrate play.

AUTOMATED TESTS
Double-click Verify-Game.bat. It runs nine headless gameplay checks using
only files in this package. Results are written under diagnostics/. These
checks isolate test saves from your normal saved game. They do not measure
GPU rendering or FPS. Afterward, use Play.bat for your hardware/visual test.

SCOPE
This is the procedural prototype/test level. Uploaded UAL characters,
commercial/final models, pistol and map assets are not integrated here.
The executable was built with VS2022/MSVC x64, using Godot 4.5.1 source and
its built-in C++ game module. Engine code and C++ runtime are linked into the
EXE; normal Windows/GPU-driver libraries remain system dependencies.
Windows acceptance/build provenance is in BUILD-INFO.json.
Godot notices are in Godot-LICENSE.txt and Godot-COPYRIGHT.txt.
The portable Python license is in python-runtime/LICENSE.txt.
