LAST LIGHT - WINDOWS x64 SURVIVAL MVP

1. Extract the WHOLE ZIP into a writable folder, such as your Desktop.
2. Open LastLight-Windows-x64 and double-click Play.bat.
3. Choose Peaceful, Standard or Hostile, then START SURVIVAL.

No Visual Studio, Premake, Godot editor, Python install or compilation is needed.
Keep LastLight.exe and LastLight.pck together. Do not launch inside a ZIP viewer.
Default: windowed 960x540, 30 FPS, OpenGL Compatibility. Options offers 720p,
30/60 FPS caps, mouse sensitivity/inversion and sound volume. Windows and a
working OpenGL 3.3 graphics driver are required.

Play-With-Neural-AI.bat enables the bundled evolved policy using the included
portable Python 3.12.10 runtime. Authored AI is the normal default and fallback.
C++ controls all authoritative state; Python returns bounded intentions.
F10 lets you watch your survivor play automatically. This toggles in-game;
it does not immediately restart the session.

CONTROLS
WASD move      Mouse camera        Shift sprint       Ctrl crouch
Space jump     RMB aim             LMB attack         1/2 pistol/sword
E interact/pick up/revive           R reload           H medkit
F eat          G offer ammo        X cancel action
Esc pause      F5 save             F9 load            Tab spectate
F10 autoplay   F1 diagnostics      Backspace return to start

MISSION
One player and four independent survivors need supplies, the yellow yard key,
the radio signal, then the green extraction pad. Hold E on one blue control
while a different survivor holds the other to raise the gate. The southern
bypass works alone. Downed survivors can be revived using a medkit; otherwise
they bleed out. Extracting some survivors can still end with casualties.
The mission ends when the living team finishes, the team is lost or time expires.

SAVE / CONTINUE
Use F5 or the pause menu. Continue loads the last compatible save. Saves and
options are stored under %APPDATA%\Godot\app_userdata\Last Light.
Old procedural-prototype saves use a different schema and are rejected safely.
Losing focus pauses gameplay. Use Resume after returning to the game.

CHECK THE PACKAGE
Double-click Verify-Game.bat. It verifies file hashes and runs 20 headless game
cases using only the included executable and portable Python. Diagnostics go
under diagnostics/ and test saves are isolated from your personal save.
These checks validate logic/packaging; Play.bat is the graphics/hardware test.

INCLUDED
UAL Standard skeletal locomotion, stance/aim/action blending and hand-bone
weapon attachments; actual sword/Glock meshes; Dwarven Expedition modular
courtyard art and reduced PBR textures; combat/resources/revival; independent
survivors and distractors; cooperative gate and solo route; menus/HUD/minimap,
options, sound cues, save/continue and results.

The shipped neural policy was evaluated on four held-out seeds (20/20 arrivals;
authored baseline 16/20). A memory ablation also reached 20/20, so this small
experiment does not demonstrate learned social intelligence. Full source,
training/checkpoint tools, metrics and detailed limits are in the source ZIP.

This is a playable survival MVP, not a large campaign or a commercial asset
collection. Free Standard clips do not provide dedicated authored strafe clips
or foot IK. Target Windows 10 Vega FPS and long-session behavior still need
measurement on your PC. Start with Low settings and Peaceful mode.

Godot engine and client C++ are compiled into the EXE with MSVC static CRT.
Python is an optional separate process. Normal Windows/GPU libraries remain
system dependencies. BUILD-INFO.json records build provenance.
See ASSET-CREDITS.txt for art scope/terms. In particular the Free3D weapon is
Personal Use and the user-supplied sword had no separate license text.
Godot notices and the portable Python license are included.
