#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
premake_bin="$(command -v premake5 || true)"
if [[ -x ./premake5 ]]; then premake_bin=./premake5; fi
if [[ -z "$premake_bin" ]]; then
    echo 'Place your Premake 5 executable here or add premake5 to PATH.' >&2
    exit 1
fi
action="${1:-gmake2}"
if [[ $# -gt 0 ]]; then shift; fi
"$premake_bin" "$action" "$@"
