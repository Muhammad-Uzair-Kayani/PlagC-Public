# Client-owned game systems

## Ownership

`client_game.hpp` and `client_game.cpp` form a backend-neutral C++ campaign
layer above the shared survival rules. They contain no JSON, console I/O,
Python, UAL, physics SDK or renderer. `game_io.cpp` loads/validates text and
serializes saves/traces. `console_game.cpp` is the input/display adapter.
The old synthetic adapter and GameRuntime remain a separate training laboratory.

The console supplies integer-meter X/Z positions at y=0, a known navigation
map and local perception. The client makes no live engine queries. A future
PlagC adapter supplies physical movement results and consumes the same gameplay
commands and computed animation plans. Character collision here is against
walls/gate cells; actors may share a cell. Continuous rigid-body physics,
imported animation poses and rendering belong to PlagC, not this source package.

## State machines

Campaign states: Playing, Paused, Victory and Defeat. Pause freezes timers,
movement, AI, hunger and blend clocks. Three objective chapters progress in
order; health/ammunition/inventory persist and lost actors do not respawn.

Character states: Idle, Moving, Aiming, Firing, Reloading, Interacting, Healing,
Helping, Stunned, Downed, Dead and Extracted. The allowed transition graph is
text data. Gameplay guards still enforce life status, range, capacity and
resource constraints: editing a transition never grants ammo or a valid target.
Reload/heal/revive/fire/hit reaction have explicit timers. Reload and healing
commit resources only at completion. Cancel interrupts a pending player action.
A hit may interrupt an action. Revive rechecks the victim and range on completion;
two simultaneous helpers cannot revive/consume a kit twice. Downed characters
cannot move, fire or hold controls; they bleed out or can be rescued. Dead and
Extracted states are terminal within a chapter.

## Locomotion and blending

Desired walk/run/crouch speed approaches its target under configured
acceleration. Turning uses shortest-angle bounded yaw change. Speed*fixed-dt
accumulates fractional cell credit; no command can advance more than two cells,
and each intermediate cell is collision-checked. Sprint drains stamina and
falls back to walking when exhausted. Idle/walking regenerate stamina. The
actual velocity derives from validated displacement, so an actor blocked by a
wall does not report successful root movement.

A normalized idle/walk/run/crouch blend space is crossfaded using fixed-step
weights. A separate normalized forward/backward/left/right space uses actual
velocity relative to facing yaw. Aim and action overlays have independent
weights; they are not added into the locomotion normalization. Gait phase
advances with actual distance and stays fixed at rest. Every state change also
records from/to names and crossfade progress. These are deterministic text
animation plans for a later UAL consumer, not skeletal pose evaluation.

## Navigation and authored behaviour

Manhattan A* on the current map returns shortest unit-cost cardinal routes.
BFS checks optimality; DFS and greedy provide comparison modes. Every movement
step rechecks current collision, and paths are recomputed when decisions run,
so an opened gate or blocked corridor changes the next route. No path produces
a safe wait rather than tunnelling or fabricating a waypoint.

The authored selector prioritizes self-care, witnessed rescue, reload,
currently armed threats, required mission keys, locally visible supplies,
optional cooperation, and extraction. Thresholds and action durations come
from behaviour.json. The selector order is a documented fixed algorithm.
Threat routing temporarily blocks nearby dangerous cells and tries a route
toward the objective, with a reachable fallback. It does not perpetually flee
from an exhausted attacker. Neural intentions can replace ordinary intent
selection while mandatory self-care/rescue/key logic retains priority.

Local vision, occlusion, hearing and independent trust/threat histories are
shared with the original core. Offers transfer a loaded round and create
observable evidence. Assistance does not create permanent faction membership.
Aggressor, runner and scavenger policies are authored and explicitly separated
from survivor decision making. Mission key locations are disclosed by briefing;
ordinary supplies never enter observations through global omniscience.

## Determinism and save contract

The campaign is authored text: the same data, seed identifier, human commands
and policy responses produce identical ticks. The current campaign has fixed
spawns/layouts; its seed identifies the run and does not silently randomize
text-defined positions. No wall-clock delta, engine state or random global
clock affects it.

Versioned JSON saves include chapter, all actors/objects, inventory, pending
actions, fractional movement credit, blend/gait state, perception memories,
route/debug data and journal. A stable content fingerprint rejects saves made
against different text definitions. Decoding and invariant checks happen
before replacing a live campaign. Invalid saves leave the running game intact.
Saves use a temporary file and replacement with rollback backup. They are
editable data, not a cryptographic anti-cheat system. Large input files are
bounded to 8 MiB; gameplay command lines to 4096 bytes.

Per-tick JSONL traces can be replayed and inspected without any engine. Command
scripts feed the exact same input parser as interactive play. `auto` uses the
authored AI and is explicitly distinguished from a human command replay.
