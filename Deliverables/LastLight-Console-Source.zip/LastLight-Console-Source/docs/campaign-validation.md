# Console campaign validation — November 12, 2026

## Implemented deliverable

Standalone client source with a three-chapter console game, text configuration,
character/campaign state machines, locomotion and blend plans, local social
perception, authored behaviour, navigation, survival/inventory/combat,
cooperative and solo routes, rescue, extraction, save/load and script replay.
PlagC's assumed engine services are outside this source package.

## Executed checks

- Clean CMake Release build with GCC 14 / C++20 and Python 3.12.
- Four CTest groups pass: complete_client_campaign, backend_independent_core,
  seeded_scenarios and python_and_protocol (11 Python tests).
- Premake gmake2 Release builds both applications and all three C++ test
  executables. The test launcher runs the same C++/Python checks against it.
- Generated Visual Studio 2022 debugger settings use the correct startup
  application, working directory and quoted campaign/interpreter paths.
- Full campaign repeated tick-for-tick with identical serialized state.
- Mid-action/full-state JSON save/load and 150 subsequent ticks match an
  uninterrupted campaign exactly. Failed load/restore preserves live state.
- Reload completion and resource accounting, reload cancellation, healing,
  downed rescue, blocked sprint, locked extraction, all-dead failure, timeout,
  normalized blend weights, malformed input/configuration and invalid saves.
- Command script exercises inspection, A*/BFS, state/blend output, pause,
  save/load, automatic completion and a JSONL trace.
- Legacy laboratory checks still cover deterministic seeded worlds, gate
  interaction requirements, sole bypass, social visibility, hidden loot,
  ammo/death, malformed/late/duplicate neural replies, checkpoint resume and
  held-out partition separation.

The included `samples/campaign-summary.json` is a real authored autoplay result.
Victory means every chapter was completed by the surviving team; casualties
are recorded rather than resurrected. The seed identifies the deterministic
run; these campaign spawns/layouts are authored text, not random seed variants.

## Practical limits

Linux builds/tests were executed here. Windows project files and launch scripts
are supplied; Windows execution was not available in this environment. A local
Visual Studio C++ workload is required. Premake itself is a build tool and is
not bundled in this source-only ZIP; use your existing working executable.

Animation results are blend parameters/clip labels, phase and actual movement
vectors, not imported skeletal poses. World collision is a flat grid with
three-coordinate DTOs; character bodies may co-locate. PlagC is responsible for
its own UAL, physics, imports, rendering and later adapter execution. The
optional bundled neural champion was trained on the older laboratory and is
not claimed to have learned this campaign, rescue or team formation.

An UndefinedBehaviorSanitizer run of the campaign state/action/save checks also
passed. The default authored autoplay completed three chapters in 167 ticks
(41.75 simulated seconds) with score 11850 in this build. This is a reproducible
scripted demonstration, not a claim that every human command sequence wins.
