# Client game architecture

```text
JSON text definitions -> loadDefinition -> Campaign (C++ client gameplay)
Console / command script -> Input -> Campaign tick
  perception + independent blackboards
  authored selector / optional Python neural intention
  character state machine + action timers
  navigation + locomotion planning
  shared validated survival rules
  actual displacement -> blend space / gait / overlays
Campaign Data -> console / save / JSONL trace
```

`survival_core` contains shared rules and the client campaign. It depends only
on the C++ standard library. The full console executable links that library
plus JSON I/O and optional process transport. `survival_synthetic` and
`GameRuntime` remain the separate laboratory used for the original seeded
neuroevolution experiments. New campaign gameplay does not link that adapter.

PlagC is assumed to provide UAL, asset imports, world creation, physics and
rendering. The application owns campaign objectives, survival/inventory rules,
blackboards, AI decisions, navigation requests, locomotion goals and state/blend
plans. The engine can consume the exported plans and feed movement/query
results through an adapter later. This source package intentionally consumes
only text data, not live PlagC state. See client-game.md for state semantics.
