@echo off
setlocal
pushd "%~dp0" || exit /b 1
py -3 scripts\test_all.py %*
set "result=%errorlevel%"
popd
exit /b %result%
