#pragma once
#include <nlohmann/json.hpp>
#include <survival/client_game.hpp>
namespace survival::game {
using Json = nlohmann::json;
Definition loadDefinition(const std::string &);
Json encode(const Data &);
Data decode(const Json &);
void save(const Campaign &, const std::string &);
void load(Campaign &, const std::string &);
Json summary(const Campaign &);
void display(const Campaign &);
void inspect(const Campaign &, Id);
Input parseInput(const std::string &);
} // namespace survival::game
