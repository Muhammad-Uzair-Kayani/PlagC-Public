#include "game_io.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
namespace survival::game {
namespace {
Json read(const std::string &path) {
    std::ifstream f(path);
    if (!f)
        throw std::runtime_error("Cannot open " + path);
    if (std::filesystem::file_size(path) > 8 * 1024 * 1024)
        throw std::runtime_error("Text file exceeds 8 MiB");
    Json j;
    f >> j;
    if (!j.is_object())
        throw std::invalid_argument("Expected JSON object in " + path);
    return j;
}
int integer(const Json &j) {
    if (!j.is_number_integer())
        throw std::invalid_argument("integer required");
    auto n = j.get<std::int64_t>();
    if (n < std::numeric_limits<int>::min() || n > std::numeric_limits<int>::max())
        throw std::invalid_argument("integer out of range");
    return int(n);
}
Id id(const Json &j) {
    int n = integer(j);
    if (n < 0)
        throw std::invalid_argument("nonnegative ID required");
    return Id(n);
}
Vec3 pos(const Json &j) {
    if (!j.is_array() || j.size() != 3)
        throw std::invalid_argument("position must be [x,y,z]");
    Vec3 p{integer(j[0]), integer(j[1]), integer(j[2])};
    if (std::abs(std::int64_t(p.x)) > 1000 || p.y != 0 || std::abs(std::int64_t(p.z)) > 1000)
        throw std::invalid_argument("position outside supported flat world");
    return p;
}
Json jp(Vec3 p) { return {p.x, p.y, p.z}; }
Json je(const Event &e) {
    return {{"id", e.id},
            {"tick", e.tick},
            {"actor", e.actor},
            {"target", e.target},
            {"kind", e.kind},
            {"position", jp(e.position)},
            {"intensity", e.intensity}};
}
Event de(const Json &j) {
    return {j.at("id").get<std::uint64_t>(),
            integer(j.at("tick")),
            id(j.at("actor")),
            id(j.at("target")),
            j.at("kind"),
            pos(j.at("position")),
            j.at("intensity").get<float>()};
}
Json jo(const Object &o) {
    return {
        {"id", o.id}, {"type", o.type}, {"position", jp(o.position)}, {"available", o.available}};
}
Object object(const Json &j) {
    return {id(j.at("id")), j.at("type"), pos(j.at("position")), j.value("available", true)};
}
Json ja(const Actor &a) {
    return {{"id", a.id},
            {"position", jp(a.position)},
            {"facing", jp(a.facing)},
            {"health", a.health},
            {"ammo", a.ammo},
            {"weapon", a.weapon},
            {"alive", a.alive},
            {"arrived", a.arrived},
            {"role", a.role},
            {"arrival_tick", a.arrivalTick},
            {"path_cost", a.pathCost},
            {"damage", a.damageReceived},
            {"first_attacks", a.firstAttacks},
            {"pickups", a.pickups},
            {"attackers", a.attackers}};
}
Actor da(const Json &j) {
    Actor a;
    a.id = id(j.at("id"));
    a.position = pos(j.at("position"));
    a.facing = pos(j.value("facing", Json{1, 0, 0}));
    a.health = integer(j.value("health", Json(100)));
    a.ammo = integer(j.value("ammo", Json(0)));
    a.weapon = j.value("weapon", false);
    a.alive = j.value("alive", true);
    a.arrived = j.value("arrived", false);
    a.role = j.value("role", std::string("survivor"));
    a.arrivalTick = j.value("arrival_tick", -1);
    a.pathCost = j.value("path_cost", 0);
    a.damageReceived = j.value("damage", 0);
    a.firstAttacks = j.value("first_attacks", 0);
    a.pickups = j.value("pickups", 0);
    a.attackers = j.value("attackers", std::vector<Id>{});
    return a;
}
Json jw(const Snapshot &s) {
    Json j{{"seed", s.seed},
           {"tick", s.tick},
           {"max_ticks", s.maxTicks},
           {"gate_hold", s.gateHold},
           {"gate_open", s.gateOpen},
           {"gate_position", jp(s.gatePosition)},
           {"control_a", s.controlA},
           {"control_b", s.controlB},
           {"gate_ticks", s.requiredGateTicks},
           {"goal", jp(s.goal)},
           {"map", s.map},
           {"actors", Json::array()},
           {"objects", Json::array()},
           {"events", Json::array()}};
    for (auto &a : s.actors)
        j["actors"].push_back(ja(a));
    for (auto &o : s.objects)
        j["objects"].push_back(jo(o));
    for (auto &e : s.events)
        j["events"].push_back(je(e));
    return j;
}
Snapshot dw(const Json &j) {
    Snapshot s;
    s.seed = j.value("seed", 1u);
    s.tick = j.value("tick", 0);
    s.maxTicks = integer(j.at("max_ticks"));
    s.gateHold = j.value("gate_hold", 0);
    s.gateOpen = j.value("gate_open", false);
    s.gatePosition = pos(j.value("gate_position", Json{9, 0, 5}));
    s.controlA = id(j.value("control_a", Json(201)));
    s.controlB = id(j.value("control_b", Json(202)));
    s.requiredGateTicks = integer(j.value("gate_ticks", Json(2)));
    s.goal = pos(j.at("goal"));
    s.map = j.at("map").get<std::vector<std::string>>();
    for (auto &a : j.at("actors"))
        s.actors.push_back(da(a));
    for (auto &o : j.at("objects"))
        s.objects.push_back(object(o));
    for (auto &e : j.value("events", Json::array()))
        s.events.push_back(de(e));
    return s;
}
Json jb(const Blend &b) {
    return {{"idle", b.idle},
            {"walk", b.walk},
            {"run", b.run},
            {"crouch", b.crouch},
            {"aim", b.aim},
            {"action", b.action},
            {"forward", b.forward},
            {"backward", b.backward},
            {"left", b.left},
            {"right", b.right},
            {"yaw", b.yaw},
            {"phase", b.phase},
            {"speed", b.speed},
            {"vx", b.velocityX},
            {"vz", b.velocityZ},
            {"credit", b.credit},
            {"from", b.from},
            {"to", b.to},
            {"transition", b.transition}};
}
Blend db(const Json &j) {
    Blend b;
    b.idle = j.at("idle");
    b.walk = j.at("walk");
    b.run = j.at("run");
    b.crouch = j.at("crouch");
    b.aim = j.at("aim");
    b.action = j.at("action");
    b.forward = j.at("forward");
    b.backward = j.at("backward");
    b.left = j.at("left");
    b.right = j.at("right");
    b.yaw = j.at("yaw");
    b.phase = j.at("phase");
    b.speed = j.at("speed");
    b.velocityX = j.at("vx");
    b.velocityZ = j.at("vz");
    b.credit = j.at("credit");
    b.from = j.at("from");
    b.to = j.at("to");
    b.transition = j.at("transition");
    return b;
}
} // namespace
Definition loadDefinition(const std::string &path) {
    auto campaign = read(path);
    if (campaign.at("version") != 1)
        throw std::invalid_argument("unsupported campaign version");
    auto base = std::filesystem::path(path).parent_path();
    auto anim = read((base / campaign.at("animation").get<std::string>()).string());
    auto behaviour = read((base / campaign.at("behaviour").get<std::string>()).string());
    Definition d;
    d.title = campaign.at("title");
    auto &t = d.tuning;
    t.dt = anim.at("dt");
    t.walk = anim.at("walk_mps");
    t.run = anim.at("run_mps");
    t.crouch = anim.at("crouch_mps");
    t.acceleration = anim.at("acceleration");
    t.turnRate = anim.at("turn_degrees_per_second");
    t.blendSeconds = anim.at("crossfade_seconds");
    t.magazine = integer(behaviour.at("magazine"));
    t.reloadTicks = integer(behaviour.at("reload_ticks"));
    t.fireTicks = integer(behaviour.at("fire_ticks"));
    t.healTicks = integer(behaviour.at("heal_ticks"));
    t.reviveTicks = integer(behaviour.at("revive_ticks"));
    t.bleedTicks = integer(behaviour.at("bleed_ticks"));
    t.hungerTicks = integer(behaviour.at("hunger_interval_ticks"));
    t.sprintDrain = behaviour.at("sprint_drain_per_second");
    t.staminaRegen = behaviour.at("stamina_regen_per_second");
    d.healBelow = integer(behaviour.at("heal_below"));
    d.eatBelow = integer(behaviour.at("eat_below"));
    d.rescueRange = integer(behaviour.at("rescue_range"));
    for (auto it = anim.at("clips").begin(); it != anim.at("clips").end(); ++it)
        d.clips[it.key()] = it.value().get<std::string>();
    auto stateFrom = [](const std::string &value) {
        for (int i = 0; i < 12; ++i)
            if (name(static_cast<State>(i)) == value)
                return static_cast<State>(i);
        throw std::invalid_argument("unknown state label " + value);
    };
    for (auto it = behaviour.at("transitions").begin(); it != behaviour.at("transitions").end();
         ++it) {
        auto from = stateFrom(it.key());
        d.transitions[from] = {};
        for (auto &value : it.value())
            d.transitions[from].push_back(stateFrom(value.get<std::string>()));
    }
    for (auto &j : campaign.at("levels")) {
        Level l;
        l.title = j.at("title");
        l.briefing = j.at("briefing");
        l.requiredKeys = integer(j.at("required_keys"));
        l.preferCooperation = j.value("prefer_cooperation", false);
        l.world = dw(j.at("world"));
        d.levels.push_back(l);
    }
    // Stable content fingerprint, including every loaded text configuration.
    std::string canonical = campaign.dump() + anim.dump() + behaviour.dump();
    std::uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : canonical) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    d.fingerprint = std::to_string(hash);
    validate(d);
    return d;
}
Json encode(const Data &d) {
    Json j{{"version", 1},
           {"phase", int(d.phase)},
           {"seed", d.seed},
           {"level", d.level},
           {"total_ticks", d.totalTicks},
           {"keys", d.keys},
           {"score", d.score},
           {"world", jw(d.world)},
           {"completed", d.completed},
           {"brains", Json::array()},
           {"journal", Json::array()}};
    for (auto &[id, b] : d.brains) {
        Json m{{"beliefs", Json::array()}, {"history", Json::array()}, {"loot", Json::array()}};
        for (auto &[other, v] : b.memory.beliefs)
            m["beliefs"].push_back({{"id", other},
                                    {"trust", v.trust},
                                    {"threat", v.threat},
                                    {"last_seen", v.lastSeen},
                                    {"position", jp(v.position)}});
        for (auto &e : b.memory.history)
            m["history"].push_back(je(e));
        for (auto &[key, pair] : b.memory.loot)
            m["loot"].push_back({{"object", jo(pair.first)}, {"tick", pair.second}});
        Json route = Json::array();
        for (auto &p : b.route)
            route.push_back(jp(p));
        j["brains"].push_back({{"id", id},
                               {"state", int(b.state)},
                               {"remaining", b.remaining},
                               {"bleed", b.bleed},
                               {"hunger", b.hunger},
                               {"reserve", b.reserve},
                               {"medkits", b.medkits},
                               {"food", b.food},
                               {"stamina", b.stamina},
                               {"pending", b.pending},
                               {"reason", b.reason},
                               {"intent", b.lastIntent},
                               {"blend", jb(b.blend)},
                               {"memory", m},
                               {"route", route},
                               {"search", b.search},
                               {"shots", b.shots},
                               {"reloads", b.reloads},
                               {"revives", b.revives},
                               {"cooperations", b.cooperations}});
    }
    for (auto &e : d.journal)
        j["journal"].push_back(je(e));
    return j;
}
Data decode(const Json &j) {
    if (j.at("version") != 1)
        throw std::invalid_argument("unsupported save version");
    Data d;
    d.phase = static_cast<Phase>(integer(j.at("phase")));
    d.seed = j.at("seed");
    d.level = integer(j.at("level"));
    d.totalTicks = integer(j.at("total_ticks"));
    d.keys = integer(j.at("keys"));
    d.score = integer(j.at("score"));
    d.world = dw(j.at("world"));
    d.completed = j.at("completed").get<std::vector<std::string>>();
    for (auto &v : j.at("brains")) {
        Id key = id(v.at("id"));
        if (d.brains.count(key))
            throw std::invalid_argument("duplicate saved brain");
        Brain b;
        b.state = static_cast<State>(integer(v.at("state")));
        b.remaining = integer(v.at("remaining"));
        b.bleed = integer(v.at("bleed"));
        b.hunger = integer(v.at("hunger"));
        b.reserve = integer(v.at("reserve"));
        b.medkits = integer(v.at("medkits"));
        b.food = integer(v.at("food"));
        b.stamina = v.at("stamina");
        b.pending = id(v.at("pending"));
        b.reason = v.at("reason");
        b.lastIntent = v.at("intent");
        b.blend = db(v.at("blend"));
        b.search = v.at("search");
        b.shots = integer(v.at("shots"));
        b.reloads = integer(v.at("reloads"));
        b.revives = integer(v.at("revives"));
        b.cooperations = integer(v.at("cooperations"));
        for (auto &p : v.at("route"))
            b.route.push_back(pos(p));
        for (auto &x : v.at("memory").at("beliefs")) {
            Belief belief;
            belief.trust = x.at("trust");
            belief.threat = x.at("threat");
            belief.lastSeen = integer(x.at("last_seen"));
            belief.position = pos(x.at("position"));
            b.memory.beliefs[id(x.at("id"))] = belief;
        }
        for (auto &x : v.at("memory").at("history"))
            b.memory.history.push_back(de(x));
        for (auto &x : v.at("memory").at("loot")) {
            auto o = object(x.at("object"));
            b.memory.loot[o.id] = {o, integer(x.at("tick"))};
        }
        d.brains.emplace(key, b);
    }
    for (auto &e : j.at("journal"))
        d.journal.push_back(de(e));
    return d;
}
void save(const Campaign &c, const std::string &path) {
    Json j = encode(c.data());
    j["fingerprint"] = c.definition().fingerprint;
    auto dest = std::filesystem::path(path);
    if (dest.has_parent_path())
        std::filesystem::create_directories(dest.parent_path());
    auto temp = dest;
    temp += ".tmp";
    {
        std::ofstream out(temp);
        if (!out)
            throw std::runtime_error("Cannot create save");
        out << j.dump(2);
        out.flush();
        if (!out)
            throw std::runtime_error("Save write failed");
    } // Windows rename cannot replace an existing file; keep a rollback backup.
    auto backup = dest;
    backup += ".bak";
    std::error_code ec;
    std::filesystem::remove(backup, ec);
    bool exists = std::filesystem::exists(dest);
    if (exists)
        std::filesystem::rename(dest, backup);
    try {
        std::filesystem::rename(temp, dest);
    } catch (...) {
        if (exists)
            std::filesystem::rename(backup, dest);
        throw;
    }
    std::filesystem::remove(backup, ec);
}
void load(Campaign &c, const std::string &path) {
    auto j = read(path);
    if (j.at("fingerprint") != c.definition().fingerprint)
        throw std::invalid_argument("Save belongs to different campaign content");
    auto candidate = decode(j);
    c.restore(std::move(candidate));
}
Json summary(const Campaign &c) {
    auto &d = c.data();
    Json a = Json::array();
    for (auto &actor : d.world.actors)
        if (actor.role == "survivor") {
            auto &b = d.brains.at(actor.id);
            a.push_back({{"id", actor.id},
                         {"state", name(b.state)},
                         {"health", actor.health},
                         {"arrived", actor.arrived},
                         {"path_cost", actor.pathCost},
                         {"reserve", b.reserve},
                         {"revives", b.revives},
                         {"blend", jb(b.blend)}});
        }
    return {{"phase", name(d.phase)},
            {"chapter", d.level + 1},
            {"total_ticks", d.totalTicks},
            {"seconds", d.totalTicks * c.definition().tuning.dt},
            {"score", d.score},
            {"completed", d.completed},
            {"keys", d.keys},
            {"gate_open", d.world.gateOpen},
            {"actors", a}};
}
void display(const Campaign &c) {
    auto &d = c.data();
    auto rows = d.world.map;
    for (auto &o : d.world.objects)
        if (o.available)
            rows[o.position.z][o.position.x] = o.type == "plate" ? '='
                                               : o.type == "key" ? 'K'
                                                                 : '*';
    if (d.world.gatePosition.z >= 0 && d.world.gatePosition.z < int(rows.size()) &&
        d.world.gatePosition.x >= 0 &&
        d.world.gatePosition.x < int(rows[d.world.gatePosition.z].size()))
        rows[d.world.gatePosition.z][d.world.gatePosition.x] = d.world.gateOpen ? '/' : 'G';
    rows[d.world.goal.z][d.world.goal.x] = 'X';
    for (auto &a : d.world.actors)
        if (!a.arrived && d.brains.at(a.id).state != State::Dead)
            rows[a.position.z][a.position.x] = a.alive ? (a.id <= 5 ? char('0' + a.id) : 'B') : '!';
    std::cout << "\n"
              << c.definition().title << " | " << name(d.phase) << " | chapter " << d.level + 1
              << "/" << c.definition().levels.size() << " | tick " << d.world.tick << "/"
              << d.world.maxTicks << "\n"
              << c.definition().levels[d.level].title << "\n"
              << c.definition().levels[d.level].briefing << "\n";
    for (auto &row : rows)
        std::cout << row << '\n';
    std::cout << "Keys " << d.keys << '/' << c.definition().levels[d.level].requiredKeys
              << " | Score " << d.score << "\n";
    for (auto &a : d.world.actors)
        if (a.role == "survivor") {
            auto &b = d.brains.at(a.id);
            std::cout << a.id << " HP " << a.health << " ammo " << a.ammo << '/' << b.reserve
                      << " stamina " << int(b.stamina) << " hunger " << b.hunger << " "
                      << name(b.state) << " (" << b.reason << ")\n";
        }
}
void inspect(const Campaign &c, Id id) {
    auto &d = c.data();
    auto it = d.brains.find(id);
    if (it == d.brains.end())
        throw std::invalid_argument("Unknown actor");
    auto &b = it->second;
    for (auto &[layer, clip] : c.definition().clips)
        std::cout << "Layer " << layer << " clip=" << clip << "\n";
    std::cout << "State " << name(b.state) << " remaining " << b.remaining << " intention "
              << b.lastIntent << "\n"
              << "Locomotion blend " << jb(b.blend).dump(2) << "\n"
              << "Inventory medkits=" << b.medkits << " food=" << b.food << " reserve=" << b.reserve
              << "\n";
    for (auto &[other, v] : b.memory.beliefs)
        std::cout << "Actor " << other << " trust=" << v.trust << " threat=" << v.threat
                  << " lastSeen=" << v.lastSeen << "\n";
    std::cout << "Route ";
    for (auto &p : b.route)
        std::cout << '(' << p.x << ',' << p.z << ") ";
    std::cout << '\n';
}
Input parseInput(const std::string &line) {
    std::istringstream stream(line);
    std::string verb;
    stream >> verb;
    std::transform(verb.begin(), verb.end(), verb.begin(),
                   [](unsigned char c) { return char(std::tolower(c)); });
    Input in;
    in.command.actor = 1;
    std::string extra;
    auto direction = [&](const std::string &d) {
        if (d == "w")
            return Vec3{0, 0, -1};
        if (d == "s")
            return Vec3{0, 0, 1};
        if (d == "a")
            return Vec3{-1, 0, 0};
        if (d == "d")
            return Vec3{1, 0, 0};
        throw std::invalid_argument("Direction must be w/a/s/d");
    };
    auto target = [&]() {
        long long value;
        if (!(stream >> value) || value < 1 || value > 2147483647)
            throw std::invalid_argument("Positive actor/object ID required");
        in.command.target = Id(value);
    };
    if (verb.empty() || verb == "wait") {
    } else if (verb == "w" || verb == "a" || verb == "s" || verb == "d")
        in.command.move = direction(verb);
    else if (verb == "sprint" || verb == "crouch" || verb == "strafe") {
        std::string d;
        stream >> d;
        in.command.move = direction(d);
        in.command.sprint = verb == "sprint";
        in.command.crouch = verb == "crouch";
        if (verb == "strafe") {
            target();
            in.command.aim = true;
        }
    } else if (verb == "e" || verb == "interact") {
        in.command.interact = true;
        stream >> std::ws;
        if (!stream.eof())
            target();
    } else if (verb == "fire" || verb == "f" || verb == "aim" || verb == "offer" ||
               verb == "revive") {
        target();
        in.command.fire = verb == "fire" || verb == "f";
        in.command.aim = verb == "aim";
        in.command.offer = verb == "offer";
        if (verb == "revive")
            in.action = "revive";
    } else if (verb == "reload")
        in.action = "reload";
    else if (verb == "use") {
        stream >> in.action;
        if (in.action != "medkit" && in.action != "food")
            throw std::invalid_argument("Use medkit or food");
    } else if (verb == "cancel")
        in.command.cancel = true;
    else
        throw std::invalid_argument("Unknown gameplay command; type help");
    if (stream >> extra)
        throw std::invalid_argument("Unexpected extra input");
    return in;
}
} // namespace survival::game
