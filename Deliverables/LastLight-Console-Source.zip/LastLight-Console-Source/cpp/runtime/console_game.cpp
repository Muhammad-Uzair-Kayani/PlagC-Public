#include "game_io.hpp"
#include "transport.hpp"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
using namespace survival;
using namespace survival::game;
namespace {
const char *help = R"(LAST LIGHT — turn-stepped client game. One tick = configured simulated dt.
W/A/S/D move; sprint <w/a/s/d>; crouch <w/a/s/d>; Enter or wait advances.
E [object-id] interacts/picks up/holds plate; aim <id>; fire <id>; reload;
use medkit; use food; revive <id>; offer <id>; cancel interrupts timed actions.
map, look, inventory, state [id], blend [id] inspect without advancing time.
path <x> <z> [astar|bfs|dfs|greedy] inspects a route; journal shows recent events.
auto [ticks] lets all survivors act; step [ticks] waits while your team acts.
pause / resume; save [path]; load [path]; restart [seed]; quit.
K=mission key, *=supply, ==pressure plate, G=gate, X=exit, !=downed, B=bot.
Complete every chapter. Survivors carry health/inventory; lost survivors stay lost.
)";
int bounded(const std::string &text, int max = 100000) {
    std::size_t used;
    long n = std::stol(text, &used);
    if (used != text.size() || n < 1 || n > max)
        throw std::invalid_argument("Expected positive bounded integer");
    return int(n);
}
std::string remaining(std::istringstream &s) {
    std::string out;
    std::getline(s >> std::ws, out);
    if (out.size() >= 2 && out.front() == '"' && out.back() == '"')
        out = out.substr(1, out.size() - 2);
    return out;
}
} // namespace
int main(int argc, char **argv) {
    try {
        std::string content = "content/campaign.json", script, tracePath, loadPath,
                    python = "python3", service, model;
        bool headless = false;
        int limit = 10000;
        std::uint32_t seed = 1;
        for (int i = 1; i < argc; ++i) {
            std::string arg = argv[i];
            auto value = [&]() {
                if (++i >= argc)
                    throw std::invalid_argument("Missing value for " + arg);
                return std::string(argv[i]);
            };
            if (arg == "--content")
                content = value();
            else if (arg == "--seed")
                seed = bounded(value(), 2147483647);
            else if (arg == "--headless")
                headless = true;
            else if (arg == "--ticks")
                limit = bounded(value());
            else if (arg == "--script")
                script = value();
            else if (arg == "--trace")
                tracePath = value();
            else if (arg == "--load")
                loadPath = value();
            else if (arg == "--python")
                python = value();
            else if (arg == "--policy-service")
                service = value();
            else if (arg == "--model")
                model = value();
            else if (arg == "--help") {
                std::cout
                    << help
                    << "Options: --content FILE --headless --ticks N --script FILE --trace FILE "
                       "--load FILE --seed N --python EXE --policy-service FILE --model FILE\n";
                return 0;
            } else
                throw std::invalid_argument("Unknown option " + arg);
        }
        Campaign game(loadDefinition(content), seed);
        if (!loadPath.empty())
            load(game, loadPath);
        std::unique_ptr<client::PythonTransport> transport;
        int policyFailures = 0;
        if (!service.empty()) {
            transport = std::make_unique<client::PythonTransport>(python, service);
            if (!model.empty())
                transport->request({{"v", 1},
                                    {"type", "load_policy"},
                                    {"request_id", 0},
                                    {"episode", 0},
                                    {"path", model}});
        }
        std::ofstream trace;
        if (!tracePath.empty()) {
            auto p = std::filesystem::path(tracePath);
            if (p.has_parent_path())
                std::filesystem::create_directories(p.parent_path());
            trace.open(p);
            if (!trace)
                throw std::runtime_error("Cannot open trace output");
        }
        auto tick = [&](const Input *human) {
            std::vector<AgentIntent> intents;
            if (transport && game.data().phase == Phase::Playing) {
                try {
                    auto obs = game.observations();
                    intents = transport->infer(obs, game.data().totalTicks + 1, game.data().level,
                                               game.data().world.tick);
                } catch (const std::exception &e) {
                    if (policyFailures++ == 0)
                        std::cerr << "Neural fallback: " << e.what() << '\n';
                }
            }
            game.tick(human, intents);
            if (trace)
                trace << encode(game.data()).dump() << '\n';
        };
        if (headless) {
            for (int i = 0; i < limit && game.data().phase == Phase::Playing; ++i)
                tick(nullptr);
            auto report = summary(game);
            report["policy_failures"] = policyFailures;
            std::cout << report.dump(2) << '\n';
            return game.data().phase == Phase::Victory ? 0 : 2;
        }
        std::ifstream scriptFile;
        if (!script.empty()) {
            scriptFile.open(script);
            if (!scriptFile)
                throw std::runtime_error("Cannot open command script");
        }
        std::istream &input = script.empty() ? std::cin : scriptFile;
        display(game);
        std::cout << help;
        std::string line;
        while ((script.empty() ? (std::cout << "> ", true) : true) && std::getline(input, line)) {
            try {
                if (line.size() > 4096)
                    throw std::invalid_argument("Command exceeds 4096 bytes");
                if (!line.empty() && line[0] == '#')
                    continue;
                std::istringstream words(line);
                std::string verb;
                words >> verb;
                std::transform(verb.begin(), verb.end(), verb.begin(),
                               [](unsigned char c) { return char(std::tolower(c)); });
                if (verb == "quit" || verb == "q")
                    break;
                if (verb == "help") {
                    std::cout << help;
                    continue;
                }
                if (verb == "map" || verb == "look" || verb == "inventory") {
                    display(game);
                    continue;
                }
                if (verb == "pause" || verb == "resume") {
                    game.pause(verb == "pause");
                    std::cout << name(game.data().phase) << '\n';
                    continue;
                }
                if (verb == "state" || verb == "blend") {
                    std::string arg;
                    words >> arg;
                    inspect(game, arg.empty() ? 1 : bounded(arg));
                    continue;
                }
                if (verb == "journal") {
                    auto &events = game.data().journal;
                    for (std::size_t i = events.size() > 25 ? events.size() - 25 : 0;
                         i < events.size(); ++i) {
                        auto &e = events[i];
                        std::cout << e.tick << " actor=" << e.actor << " target=" << e.target << " "
                                  << e.kind << '\n';
                    }
                    continue;
                }
                if (verb == "save" || verb == "load") {
                    std::string path = remaining(words);
                    if (path.empty())
                        path = "saves/campaign.json";
                    if (verb == "save")
                        save(game, path);
                    else
                        load(game, path);
                    std::cout << verb << " complete: " << path << '\n';
                    continue;
                }
                if (verb == "restart") {
                    std::string arg;
                    words >> arg;
                    game.reset(arg.empty() ? seed : bounded(arg));
                    display(game);
                    continue;
                }
                if (verb == "path") {
                    int x, z;
                    std::string algorithm = "astar";
                    if (!(words >> x >> z) || x < 0 || x >= 128 || z < 0 || z >= 128)
                        throw std::invalid_argument("path requires bounded x z [algorithm]");
                    words >> algorithm;
                    auto &a = game.data().world.actors.front();
                    auto route = navigate(game.data().world, a.position, {x, 0, z}, algorithm);
                    std::cout << algorithm << " cost=" << route.size() << " ";
                    for (auto &p : route)
                        std::cout << '(' << p.x << ',' << p.z << ") ";
                    std::cout << '\n';
                    continue;
                }
                if (verb == "auto" || verb == "step") {
                    std::string count, extra;
                    words >> count;
                    if (words >> extra)
                        throw std::invalid_argument("Unexpected input after step count");
                    int n = count.empty() ? 1 : bounded(count);
                    Input wait;
                    wait.command.actor = 1;
                    for (int k = 0; k < n && game.data().phase == Phase::Playing; ++k)
                        tick(verb == "auto" ? nullptr : &wait);
                    display(game);
                    if (game.data().phase == Phase::Victory || game.data().phase == Phase::Defeat)
                        std::cout << summary(game).dump(2) << '\n';
                    continue;
                }
                auto command = parseInput(line);
                tick(&command);
                display(game);
            } catch (const std::exception &e) {
                std::cerr << "Command rejected: " << e.what() << '\n';
                if (!script.empty())
                    return 1;
            }
        }
        if (!script.empty())
            std::cout << summary(game).dump(2) << '\n';
        return 0;
    } catch (const std::exception &e) {
        std::cerr << "Error: " << e.what() << '\n';
        return 1;
    }
}
