#include "game_io.hpp"
#include <cmath>
#include <filesystem>
#include <iostream>
#include <stdexcept>
using namespace survival;
using namespace survival::game;
namespace {
void check(bool condition, const char *message) {
    if (!condition)
        throw std::runtime_error(message);
}
template <class F> void rejects(F f, const char *message) {
    bool rejected = false;
    try {
        f();
    } catch (const std::exception &) {
        rejected = true;
    }
    check(rejected, message);
}
void steps(Campaign &c, int n, const Input *in = nullptr) {
    for (int i = 0; i < n && c.data().phase == Phase::Playing; ++i)
        c.tick(in);
}
} // namespace
int main() {
    try {
        auto definition = loadDefinition("content/campaign.json");
        Campaign a(definition, 17), b(definition, 17);
        for (int tick = 0; tick < 4000 && a.data().phase == Phase::Playing; ++tick) {
            a.tick();
            b.tick();
            check(encode(a.data()) == encode(b.data()),
                  "full deterministic campaign replay mismatch");
            for (auto &[id, brain] : a.data().brains) {
                auto &v = brain.blend;
                check(std::abs(v.idle + v.walk + v.run + v.crouch - 1) < 1e-8,
                      "normalized locomotion blend");
                for (double weight :
                     {v.idle, v.walk, v.run, v.crouch, v.aim, v.action, v.transition})
                    check(std::isfinite(weight) && weight >= 0 && weight <= 1, "blend range");
            }
        }
        check(a.data().phase == Phase::Victory, "authored team must complete all three chapters");
        check(a.data().completed.size() == 3, "three campaign objectives");
        Campaign c(definition, 3);
        steps(c, 21);
        auto atSave = encode(c.data());
        auto path = std::filesystem::temp_directory_path() / "last-light-test-save.json";
        save(c, path.string());
        Campaign resumed(definition, 99);
        load(resumed, path.string());
        check(atSave == encode(resumed.data()), "save/load full state");
        for (int i = 0; i < 150; ++i) {
            c.tick();
            resumed.tick();
            check(encode(c.data()) == encode(resumed.data()),
                  "resume must preserve memory/action/blend determinism");
        }
        auto before = encode(c.data());
        c.pause(true);
        auto paused = encode(c.data());
        steps(c, 5);
        check(encode(c.data()) == paused, "pause must freeze simulation");
        c.pause(false);
        auto bad = c.data();
        bad.brains.at(1).blend.idle = 2;
        rejects([&] { c.restore(bad); }, "reject invalid blend save");
        check(encode(c.data()) == before, "failed restore must not mutate world");
        c.reset(1);
        auto d = c.data();
        d.world.actors[0].weapon = true;
        d.world.actors[0].ammo = 0;
        c.restore(d);
        Input reload = parseInput("reload");
        c.tick(&reload);
        check(c.data().brains.at(1).state == State::Reloading, "reload enters timed state");
        int reserve = c.data().brains.at(1).reserve;
        Input cancel = parseInput("cancel");
        c.tick(&cancel);
        check(c.data().brains.at(1).state == State::Idle && c.data().world.actors[0].ammo == 0,
              "cancel must interrupt reload");
        c.tick(&reload);
        Input wait = parseInput("wait");
        steps(c, definition.tuning.reloadTicks, &wait);
        check(c.data().world.actors[0].ammo == 6 && c.data().brains.at(1).reserve == reserve - 6,
              "reload consumes exactly magazine capacity");
        c.reset(1);
        d = c.data();
        d.world.actors[0].health = 40;
        c.restore(d);
        auto med = parseInput("use medkit");
        c.tick(&med);
        steps(c, definition.tuning.healTicks, &wait);
        check(c.data().world.actors[0].health == 80 && c.data().brains.at(1).medkits == 0,
              "timed healing consumes exactly one kit");
        c.reset(1);
        d = c.data();
        d.world.actors[0].position = {3, 0, 4};
        d.world.actors[1].position = {4, 0, 4};
        d.world.actors[1].health = 0;
        d.world.actors[1].alive = false;
        d.brains.at(2).state = State::Downed;
        d.brains.at(2).bleed = 80;
        c.restore(d);
        auto revive = parseInput("revive 2");
        c.tick(&revive);
        steps(c, definition.tuning.reviveTicks, &wait);
        check(c.data().world.actors[1].alive && c.data().brains.at(1).revives == 1 &&
                  c.data().brains.at(1).medkits == 0,
              "rescue restores survivor and consumes one kit");
        c.reset(1);
        d = c.data();
        d.world.actors[0].position = {8, 0, 3};
        d.world.actors[1].position = {8, 0, 3};
        c.restore(d);
        auto move = parseInput("sprint d");
        c.tick(&move);
        check(c.data().world.actors[0].position.x == 8, "sprint cannot tunnel through wall");
        auto &blend = c.data().brains.at(1).blend;
        check(blend.velocityX == 0 && blend.velocityZ == 0,
              "blocked locomotion actual velocity zero");
        c.reset(1);
        d = c.data();
        d.world.actors[0].position = d.world.goal;
        c.restore(d);
        c.tick(&wait);
        check(!c.data().world.actors[0].arrived, "locked extraction cannot complete before keys");
        c.reset(1);
        d = c.data();
        for (auto &v : d.world.actors) {
            v.alive = false;
            v.health = 0;
            d.brains.at(v.id).state = State::Dead;
        }
        c.restore(d);
        c.tick();
        check(c.data().phase == Phase::Defeat, "all lost survivors fail campaign");
        c.reset(1);
        d = c.data();
        d.world.tick = d.world.maxTicks - 1;
        c.restore(d);
        c.tick(&wait);
        check(c.data().phase == Phase::Defeat, "mission timeout");
        for (auto text : {"fire -1", "fire 1xyz", "fire 2 extra", "sprint diagonal", "use grenade",
                          "reload extra", "e banana", "revive 0", "nonsense"})
            rejects([&] { parseInput(text); }, "bad command accepted");
        // A relocated text-defined gate must have real interaction semantics.
        auto custom = definition;
        custom.levels.resize(1);
        custom.levels[0].world.gatePosition = {10, 0, 5};
        custom.levels[0].world.gateOpen = true;
        custom.levels[0].world.map[5][9] = '.';
        custom.levels[0].world.controlA = 301;
        custom.levels[0].world.controlB = 302;
        for (auto &obj : custom.levels[0].world.objects) {
            if (obj.id == 201)
                obj.id = 301;
            if (obj.id == 202)
                obj.id = 302;
        }
        validate(custom);
        Campaign relocated(custom);
        check(!blocked(relocated.data().world, {10, 0, 5}), "text-defined gate coordinates");
        auto invalid = definition;
        invalid.levels[0].world.map[1] = ".";
        rejects([&] { validate(invalid); }, "ragged text world accepted");
        invalid = definition;
        invalid.levels[0].world.actors[1].id = 1;
        rejects([&] { validate(invalid); }, "duplicate text actor accepted");
        invalid = definition;
        invalid.tuning.dt = std::nan("");
        rejects([&] { validate(invalid); }, "nonfinite locomotion accepted");
        std::filesystem::remove(path);
        std::cout << "Campaign, state machines, locomotion/blends, survival, rescue, save/replay, "
                     "input/content validation: passed\n";
        return 0;
    } catch (const std::exception &e) {
        std::cerr << "FAILED: " << e.what() << '\n';
        return 1;
    }
}
