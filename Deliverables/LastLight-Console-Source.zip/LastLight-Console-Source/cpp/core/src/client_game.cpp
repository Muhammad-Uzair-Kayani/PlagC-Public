#include <algorithm>
#include <cmath>
#include <set>
#include <stdexcept>
#include <survival/client_game.hpp>
namespace survival::game {
namespace {
Actor *actor(Snapshot &s, Id id) {
    for (auto &a : s.actors)
        if (a.id == id)
            return &a;
    return nullptr;
}
const Actor *actor(const Snapshot &s, Id id) {
    for (auto &a : s.actors)
        if (a.id == id)
            return &a;
    return nullptr;
}
bool active(const Actor &a) { return a.alive && !a.arrived; }
bool busy(State s) {
    return s == State::Reloading || s == State::Healing || s == State::Helping ||
           s == State::Stunned || s == State::Firing;
}
double approach(double a, double b, double step) {
    return a < b ? std::min(b, a + step) : std::max(b, a - step);
}
const std::vector<std::string> states{"Idle",      "Moving",      "Aiming",  "Firing",
                                      "Reloading", "Interacting", "Healing", "Helping",
                                      "Stunned",   "Downed",      "Dead",    "Extracted"};
} // namespace
std::string name(State s) { return states.at(static_cast<unsigned>(s)); }
std::string name(Phase p) {
    static std::vector<std::string> n{"Playing", "Paused", "Victory", "Defeat"};
    return n.at(static_cast<unsigned>(p));
}
void validate(const Definition &d) {
    if (d.levels.empty() || d.levels.size() > 32)
        throw std::invalid_argument("campaign needs 1..32 levels");
    if (d.healBelow < 1 || d.healBelow > 100 || d.eatBelow < 1 || d.eatBelow > 100 ||
        d.rescueRange < 1 || d.rescueRange > 20)
        throw std::invalid_argument("invalid behaviour thresholds");
    if (d.transitions.size() != 12)
        throw std::invalid_argument("state graph must define all 12 states");
    for (auto &[from, targets] : d.transitions) {
        if (static_cast<unsigned>(from) > 11)
            throw std::invalid_argument("unknown state graph node");
        for (auto to : targets)
            if (static_cast<unsigned>(to) > 11)
                throw std::invalid_argument("unknown transition target");
    }
    for (auto key : {"idle", "walk", "run", "crouch", "aim", "action"})
        if (!d.clips.count(key) || d.clips.at(key).empty())
            throw std::invalid_argument("missing text animation clip label");
    const auto &t = d.tuning;
    for (double v : {t.dt, t.walk, t.run, t.crouch, t.acceleration, t.turnRate, t.blendSeconds,
                     t.sprintDrain, t.staminaRegen})
        if (!std::isfinite(v) || v <= 0 || v > 1000)
            throw std::invalid_argument("invalid finite positive movement tuning");
    if (t.dt > 1 || t.run * t.dt > 2 || t.walk > t.run || t.crouch > t.walk)
        throw std::invalid_argument(
            "movement must obey crouch <= walk <= run and run*dt <= 2 cells");
    for (int v : {t.magazine, t.reloadTicks, t.fireTicks, t.healTicks, t.reviveTicks, t.bleedTicks,
                  t.hungerTicks})
        if (v < 1 || v > 10000)
            throw std::invalid_argument("invalid gameplay duration/capacity");
    for (const auto &l : d.levels) {
        auto &s = l.world;
        if (s.map.size() < 3 || s.map.size() > 128 || s.map[0].size() < 3 ||
            s.map[0].size() > 128 || s.maxTicks < 1 || s.maxTicks > 100000)
            throw std::invalid_argument("invalid level size or timeout");
        for (auto &row : s.map) {
            if (row.size() != s.map[0].size())
                throw std::invalid_argument("nonrectangular map");
            for (char c : row)
                if (c != '.' && c != '#')
                    throw std::invalid_argument("map only accepts . and #");
        }
        if (blocked(s, s.goal))
            throw std::invalid_argument("blocked goal");
        std::set<Id> ids;
        int survivors = 0, keys = 0;
        for (auto &a : s.actors) {
            if (!a.id || !a.alive || a.arrived || !ids.insert(a.id).second ||
                blocked(s, a.position) || a.health < 1 || a.health > 100 || a.ammo < 0 ||
                a.ammo > t.magazine)
                throw std::invalid_argument("invalid/duplicate actor");
            if (a.role != "survivor" && a.role != "aggressor" && a.role != "runner" &&
                a.role != "scavenger")
                throw std::invalid_argument("unknown actor role");
            if (a.role == "survivor") {
                ++survivors;
                if (navigate(s, a.position, s.goal).empty() && a.position != s.goal)
                    throw std::invalid_argument("survivor lacks solo route");
            }
        }
        if (!survivors || !actor(s, 1) || actor(s, 1)->role != "survivor")
            throw std::invalid_argument("human survivor 1 required");
        for (auto &o : s.objects) {
            if (!o.id || !ids.insert(o.id).second || blocked(s, o.position))
                throw std::invalid_argument("invalid/duplicate object");
            if (o.type != "weapon" && o.type != "ammo" && o.type != "medkit" && o.type != "food" &&
                o.type != "key" && o.type != "plate")
                throw std::invalid_argument("unknown object type");
            if (o.type == "key") {
                ++keys;
                if (!o.available || (navigate(s, actor(s, 1)->position, o.position).empty() &&
                                     actor(s, 1)->position != o.position))
                    throw std::invalid_argument("mission key lacks a reachable solo route");
            }
        }
        if (l.requiredKeys < 0 || l.requiredKeys > keys)
            throw std::invalid_argument("insufficient objective keys");
        if (s.requiredGateTicks < 1 || s.requiredGateTicks > 1000)
            throw std::invalid_argument("invalid gate hold duration");
        if (!s.gateOpen) {
            auto open = s;
            open.gateOpen = true;
            if (blocked(open, s.gatePosition))
                throw std::invalid_argument("gate position is not traversable");
            auto p = std::find_if(s.objects.begin(), s.objects.end(),
                                  [&](auto &o) { return o.id == s.controlA && o.type == "plate"; });
            auto q = std::find_if(s.objects.begin(), s.objects.end(),
                                  [&](auto &o) { return o.id == s.controlB && o.type == "plate"; });
            if (p == s.objects.end() || q == s.objects.end() || p->position == q->position)
                throw std::invalid_argument("gate needs two distinct controls");
        }
    }
}
Campaign::Campaign(Definition d, std::uint32_t seed) : definition_(std::move(d)) {
    validate(definition_);
    reset(seed);
}
void Campaign::reset(std::uint32_t seed) {
    data_ = {};
    data_.seed = seed;
    enterLevel(0, false);
}
void Campaign::enterLevel(int level, bool carry) {
    auto old = data_;
    data_.level = level;
    data_.keys = 0;
    data_.world = definition_.levels.at(level).world;
    data_.world.seed = data_.seed;
    data_.world.tick = 0;
    data_.world.events.clear();
    data_.brains.clear();
    for (auto &a : data_.world.actors) {
        Brain b;
        if (carry && a.role == "survivor") {
            auto prev = actor(old.world, a.id);
            auto it = old.brains.find(a.id);
            if (prev && it != old.brains.end()) {
                b = it->second;
                b.state = State::Idle;
                b.remaining = 0;
                b.pending = 0;
                b.memory = {};
                b.route.clear();
                b.blend = {};
                a.health = prev->health;
                a.weapon = prev->weapon;
                a.ammo = prev->ammo;
                a.alive = prev->alive;
                a.attackers.clear();
                if (!a.alive) {
                    b.state = State::Dead;
                    a.health = 0;
                }
            }
        }
        data_.brains[a.id] = b;
    }
    event(0, 0, "level_started");
}
void Campaign::pause(bool value) {
    if (data_.phase == Phase::Playing && value)
        data_.phase = Phase::Paused;
    else if (data_.phase == Phase::Paused && !value)
        data_.phase = Phase::Playing;
}
void Campaign::event(Id a, Id t, const std::string &kind) {
    auto p = actor(data_.world, a);
    Event e{1000000000000ULL + std::uint64_t(data_.totalTicks) * 10000 + data_.journal.size(),
            data_.world.tick,
            a,
            t,
            kind,
            p ? p->position : Vec3{},
            1};
    data_.world.events.push_back(e);
    data_.journal.push_back(e);
    if (data_.journal.size() > 2000)
        data_.journal.erase(data_.journal.begin());
}
void Campaign::transition(Id id, State to, int ticks, Id target) {
    auto &b = data_.brains.at(id);
    if (b.state != to) {
        auto &allowed = definition_.transitions.at(b.state);
        if (std::find(allowed.begin(), allowed.end(), to) == allowed.end())
            throw std::logic_error("Disallowed state transition " + name(b.state) + " -> " +
                                   name(to));
        b.blend.from = name(b.state);
        b.blend.to = name(to);
        b.blend.transition = 0;
    }
    b.state = to;
    b.remaining = ticks;
    b.pending = target;
}
std::vector<Observation> Campaign::observations() {
    std::vector<Observation> obs;
    for (auto &a : data_.world.actors)
        if (active(a) && a.role == "survivor")
            obs.push_back(observe(data_.world, a.id, data_.brains.at(a.id).memory));
    return obs;
}
Input Campaign::behaviour(Id id, const Observation &o) {
    auto &a = *actor(data_.world, id);
    auto &b = data_.brains.at(id);
    Input in;
    in.command.actor = id;
    // Priority selector: urgent self-care, rescue, danger, objectives, supplies, social shortcut,
    // exit.
    if (a.health < definition_.healBelow && b.medkits > 0) {
        in.action = "medkit";
        b.reason = "Heal before continuing";
        return in;
    }
    if (b.hunger < definition_.eatBelow && b.food > 0) {
        in.action = "food";
        b.reason = "Eat carried food";
        return in;
    }
    for (auto &other : data_.world.actors) {
        auto &ob = data_.brains.at(other.id);
        if (other.role == "survivor" && ob.state == State::Downed && b.medkits > 0 &&
            distance(a.position, other.position) <= definition_.rescueRange &&
            lineOfSight(data_.world, a.position, other.position)) {
            b.reason = "Rescue downed survivor";
            if (distance(a.position, other.position) <= 1) {
                in.action = "revive";
                in.command.target = other.id;
            } else {
                b.route = navigate(data_.world, a.position, other.position, b.search);
                if (!b.route.empty())
                    in.command.move = {b.route[0].x - a.position.x, 0, b.route[0].z - a.position.z};
            }
            return in;
        }
    }
    if (a.weapon && a.ammo == 0 && b.reserve > 0) {
        in.action = "reload";
        b.reason = "Reload empty weapon";
        return in;
    }
    if (o.valid[3]) {
        std::vector<const Actor *> threats;
        for (auto visible : o.visibleActors) {
            auto enemy = actor(data_.world, visible);
            auto belief = b.memory.beliefs.find(visible);
            if (enemy && active(*enemy) && enemy->weapon && enemy->ammo > 0 &&
                belief != b.memory.beliefs.end() && belief->second.threat > 0.2f)
                threats.push_back(enemy);
        }
        if (!threats.empty()) {
            if (a.weapon && a.ammo > 0 && a.health >= 50) {
                auto defend = resolve(data_.world, {id, Intent::Defend, 0}, o, b.memory);
                if (defend.fire) {
                    in.command = defend;
                    b.lastIntent = "Defend";
                    b.reason = "Defend against observed armed threat";
                    return in;
                }
            }
            Vec3 destination = data_.world.goal;
            if (data_.keys < definition_.levels[data_.level].requiredKeys)
                for (auto &ob : data_.world.objects)
                    if (ob.type == "key" && ob.available) {
                        destination = ob.position;
                        break;
                    }
            auto safer = data_.world;
            for (int z = 0; z < int(safer.map.size()); ++z)
                for (int x = 0; x < int(safer.map[z].size()); ++x) {
                    Vec3 cell{x, 0, z};
                    if (cell == a.position || cell == destination)
                        continue;
                    for (auto enemy : threats)
                        if (distance(cell, enemy->position) <= 3)
                            safer.map[z][x] = '#';
                }
            b.route = navigate(safer, a.position, destination, b.search);
            if (b.route.empty())
                b.route = navigate(data_.world, a.position, destination, b.search);
            if (!b.route.empty())
                in.command.move = {b.route[0].x - a.position.x, 0, b.route[0].z - a.position.z};
            in.command.sprint = true;
            b.lastIntent = "Avoid";
            b.reason = "Route around armed threat toward objective";
            return in;
        }
    }
    if (data_.keys < definition_.levels[data_.level].requiredKeys) {
        const Object *target = nullptr;
        int best = 99999;
        for (auto &object : data_.world.objects)
            if (object.type == "key" && object.available) {
                auto route = navigate(data_.world, a.position, object.position, b.search);
                if ((!route.empty() || a.position == object.position) && int(route.size()) < best) {
                    best = int(route.size());
                    target = &object;
                }
            }
        // Mission key locations are disclosed by the briefing; ordinary loot still requires
        // perception.
        if (target) {
            b.reason = "Recover mission access key";
            in.command.target = target->id;
            if (distance(a.position, target->position) <= 1)
                in.command.interact = true;
            else {
                b.route = navigate(data_.world, a.position, target->position, b.search);
                if (!b.route.empty())
                    in.command.move = {b.route[0].x - a.position.x, 0, b.route[0].z - a.position.z};
            }
            return in;
        }
    }
    if (o.valid[1]) {
        const Object *target = nullptr;
        int best = 99999;
        for (auto visible : o.visibleObjects) {
            auto oi = std::find_if(data_.world.objects.begin(), data_.world.objects.end(),
                                   [&](auto &ob) { return ob.id == visible; });
            if (oi == data_.world.objects.end())
                continue;
            bool need =
                (oi->type == "weapon" && !a.weapon) || (oi->type == "ammo" && b.reserve < 8) ||
                (oi->type == "food" && b.food < 1) || (oi->type == "medkit" && b.medkits < 1);
            if (!need)
                continue;
            auto path = navigate(data_.world, a.position, oi->position, b.search);
            if ((!path.empty() || a.position == oi->position) && int(path.size()) < best) {
                best = int(path.size());
                target = &*oi;
            }
        }
        if (target) {
            b.reason = "Collect visible supplies";
            b.lastIntent = "Acquire";
            in.command.target = target->id;
            if (distance(a.position, target->position) <= 1)
                in.command.interact = true;
            else {
                b.route = navigate(data_.world, a.position, target->position, b.search);
                if (!b.route.empty())
                    in.command.move = {b.route[0].x - a.position.x, 0, b.route[0].z - a.position.z};
            }
            return in;
        }
    }
    Intent intent = Intent::Progress;
    if (definition_.levels[data_.level].preferCooperation && o.valid[2])
        intent = Intent::Cooperate;
    b.reason = intent == Intent::Cooperate ? "Activate complementary control; bypass after deadline"
                                           : "Follow route to extraction";
    b.lastIntent = name(intent);
    in.command = resolve(data_.world, {id, intent, 0}, o, b.memory);
    b.route = navigate(data_.world, a.position, data_.world.goal, b.search);
    return in;
}
void Campaign::locomotion(Actor &a, Brain &b, Command &c) {
    auto &t = definition_.tuning;
    bool moving = c.move.y == 0 && c.move.x >= -1 && c.move.x <= 1 && c.move.z >= -1 &&
                  c.move.z <= 1 && std::abs(c.move.x) + std::abs(c.move.z) == 1;
    if (!moving) {
        c.move = {};
        b.blend.speed = approach(b.blend.speed, 0, t.acceleration * t.dt);
        b.blend.credit = 0;
        b.stamina = std::min(100., b.stamina + t.staminaRegen * t.dt);
        return;
    }
    bool sprint = c.sprint && b.stamina >= t.sprintDrain * t.dt && !c.crouch;
    c.sprint = false;
    double target = c.crouch ? t.crouch : (sprint ? t.run : t.walk);
    b.blend.speed = approach(b.blend.speed, target, t.acceleration * t.dt);
    auto facing = c.move;
    if (c.aim)
        if (auto target = actor(data_.world, c.target))
            facing = {target->position.x - a.position.x, 0, target->position.z - a.position.z};
    double desired = std::atan2(double(facing.x), double(facing.z)) * 180 / 3.141592653589793;
    double delta = std::remainder(desired - b.blend.yaw, 360.);
    b.blend.yaw = std::remainder(
        b.blend.yaw + std::clamp(delta, -t.turnRate * t.dt, t.turnRate * t.dt), 360.);
    b.blend.credit = std::min(2., b.blend.credit + b.blend.speed * t.dt);
    int cells = int(b.blend.credit);
    b.blend.credit -= cells;
    if (cells < 1)
        c.move = {};
    else
        c.sprint = cells == 2;
    if (sprint)
        b.stamina = std::max(0., b.stamina - t.sprintDrain * t.dt);
    else
        b.stamina = std::min(100., b.stamina + t.staminaRegen * t.dt);
    (void)a;
}
void Campaign::blend(Actor &a, Brain &b, Vec3 before) {
    auto &t = definition_.tuning;
    auto &v = b.blend;
    double actual = distance(before, a.position) / t.dt;
    v.velocityX = (a.position.x - before.x) / t.dt;
    v.velocityZ = (a.position.z - before.z) / t.dt;
    double yaw = v.yaw * 3.141592653589793 / 180.;
    double localForward = v.velocityX * std::sin(yaw) + v.velocityZ * std::cos(yaw);
    double localRight = v.velocityX * std::cos(yaw) - v.velocityZ * std::sin(yaw);
    double length = std::abs(localForward) + std::abs(localRight);
    v.forward = length > 0 ? std::max(0., localForward) / length : 0;
    v.backward = length > 0 ? std::max(0., -localForward) / length : 0;
    v.right = length > 0 ? std::max(0., localRight) / length : 0;
    v.left = length > 0 ? std::max(0., -localRight) / length : 0;
    // 1D locomotion blend space, crossfaded independently from upper-body/action layers.
    double idle = actual == 0 ? 1 : 0,
           run = actual == 0 ? 0
                             : std::clamp((v.speed - t.walk) / (t.run - t.walk + 0.00001), 0., 1.);
    double crouch = actual > 0 && v.speed <= t.crouch + 0.001 ? 1 : 0;
    double walk = 1 - idle - run - crouch;
    walk = std::max(0., walk);
    if (b.state == State::Downed || b.state == State::Dead || b.state == State::Extracted) {
        idle = 1;
        walk = run = crouch = 0;
        v.speed = 0;
    }
    double alpha = std::min(1., t.dt / t.blendSeconds);
    v.idle += (idle - v.idle) * alpha;
    v.walk += (walk - v.walk) * alpha;
    v.run += (run - v.run) * alpha;
    v.crouch += (crouch - v.crouch) * alpha;
    double total = v.idle + v.walk + v.run + v.crouch;
    v.idle /= total;
    v.walk /= total;
    v.run /= total;
    v.crouch /= total;
    double aim = b.state == State::Aiming || b.state == State::Firing ? 1 : 0;
    double action = busy(b.state) || b.state == State::Interacting ? 1 : 0;
    v.aim += (aim - v.aim) * alpha;
    v.action += (action - v.action) * alpha;
    v.phase = std::fmod(v.phase + actual * t.dt / 2., 1.);
    v.transition = std::min(1., v.transition + alpha);
}
void Campaign::tick(const Input *human, const std::vector<AgentIntent> &policy) {
    if (data_.phase != Phase::Playing)
        return;
    auto &t = definition_.tuning;
    auto &world = data_.world;
    auto obs = observations();
    std::vector<Event> pending;
    std::vector<Command> commands;
    std::map<Id, Vec3> before;
    auto journalSize = data_.journal.size();
    ++data_.totalTicks;
    for (auto &a : world.actors) {
        auto &b = data_.brains.at(a.id);
        before[a.id] = a.position;
        if (b.state == State::Downed) {
            if (--b.bleed <= 0) {
                transition(a.id, State::Dead);
                event(a.id, 0, "bled_out");
            }
            continue;
        }
        if (!active(a))
            continue;
        if (human && human->command.actor == a.id && human->command.cancel)
            transition(a.id, State::Idle);
        if (b.remaining > 0) {
            --b.remaining;
            if (b.remaining == 0) {
                auto state = b.state;
                Id target = b.pending;
                if (state == State::Reloading) {
                    int amount = std::min(t.magazine - a.ammo, b.reserve);
                    a.ammo += amount;
                    b.reserve -= amount;
                    ++b.reloads;
                    event(a.id, 0, "reload_complete");
                }
                if (state == State::Healing && b.medkits > 0) {
                    --b.medkits;
                    a.health = std::min(100, a.health + 40);
                    event(a.id, 0, "heal_complete");
                }
                if (state == State::Helping && b.medkits > 0) {
                    auto victim = actor(world, target);
                    auto it = data_.brains.find(target);
                    if (victim && it != data_.brains.end() && it->second.state == State::Downed &&
                        distance(a.position, victim->position) <= 1) {
                        --b.medkits;
                        victim->alive = true;
                        victim->health = 35;
                        transition(target, State::Idle);
                        ++b.revives;
                        event(a.id, target, "help");
                    }
                }
                transition(a.id, State::Idle);
            } else {
                commands.push_back({a.id});
                continue;
            }
        }
        auto oi = std::find_if(obs.begin(), obs.end(), [&](auto &o) { return o.agent == a.id; });
        Input in;
        in.command.actor = a.id;
        if (a.role == "survivor" && oi != obs.end()) {
            in = behaviour(a.id, *oi);
            int found = 0;
            for (auto &i : policy)
                if (i.agent == a.id) {
                    ++found;
                    if (!busy(b.state) && in.action.empty() &&
                        b.reason != "Recover mission access key" &&
                        b.reason != "Rescue downed survivor") {
                        in.command = resolve(world, i, *oi, b.memory);
                        b.lastIntent = name(i.intent);
                        b.reason = "Neural high-level intention";
                    }
                }
            if (found > 1)
                in = behaviour(a.id, *oi);
        } else if (a.role == "aggressor") {
            const Actor *target = nullptr;
            int best = 7;
            for (auto &v : world.actors)
                if (v.role == "survivor" && active(v) && distance(a.position, v.position) < best &&
                    lineOfSight(world, a.position, v.position)) {
                    best = distance(a.position, v.position);
                    target = &v;
                }
            if (target) {
                in.command.target = target->id;
                in.command.fire = true;
                b.reason = "Scripted aggressor trigger";
            } else
                b.reason = "Guard post";
        } else if (a.role == "runner") {
            static Vec3 directions[] = {{0, 0, -1}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}};
            in.command.move = directions[(world.tick / 8) % 4];
            in.command.sprint = true;
            b.reason = "Panicked patrol";
        } else if (a.role == "scavenger") {
            Object *target = nullptr;
            int best = 999;
            for (auto &o : world.objects)
                if (o.available && o.type != "plate" && o.type != "key" &&
                    distance(a.position, o.position) < best) {
                    best = distance(a.position, o.position);
                    target = &o;
                }
            if (target) {
                in.command.target = target->id;
                if (best <= 1)
                    in.command.interact = true;
                else {
                    auto route = navigate(world, a.position, target->position);
                    if (!route.empty())
                        in.command.move = {route[0].x - a.position.x, 0, route[0].z - a.position.z};
                }
            }
            b.reason = "Scripted supply competition";
        }
        if (human && a.id == human->command.actor) {
            in = *human;
            b.reason = "Human command";
        }
        auto &c = in.command;
        c.actor = a.id;
        if (c.cancel) {
            transition(a.id, State::Idle);
            c = {};
            c.actor = a.id;
        }
        if (in.action == "reload" && a.weapon && a.ammo < t.magazine && b.reserve > 0) {
            transition(a.id, State::Reloading, t.reloadTicks);
            c = {};
            c.actor = a.id;
        }
        if (in.action == "medkit" && b.medkits > 0 && a.health < 100) {
            transition(a.id, State::Healing, t.healTicks);
            c = {};
            c.actor = a.id;
        }
        if (in.action == "food" && b.food > 0 && b.hunger < 100) {
            --b.food;
            b.hunger = std::min(100, b.hunger + 50);
            event(a.id, 0, "ate_food");
        }
        if (in.action == "revive" && b.medkits > 0) {
            auto victim = actor(world, c.target);
            if (victim && victim->id != a.id &&
                data_.brains.at(victim->id).state == State::Downed &&
                distance(a.position, victim->position) <= 1) {
                transition(a.id, State::Helping, t.reviveTicks, victim->id);
                c = {};
                c.actor = a.id;
            }
        }
        if (c.interact) {
            for (auto &o : world.objects) {
                if (!o.available || o.type == "plate" || (c.target && c.target != o.id) ||
                    distance(a.position, o.position) > 1 ||
                    !lineOfSight(world, a.position, o.position))
                    continue;
                if (o.type == "weapon") {
                    a.weapon = true;
                    b.reserve += 6;
                    if (a.ammo == 0) {
                        a.ammo = std::min(6, t.magazine);
                        b.reserve -= a.ammo;
                    }
                } else if (o.type == "ammo")
                    b.reserve += 8;
                else if (o.type == "medkit")
                    ++b.medkits;
                else if (o.type == "food")
                    ++b.food;
                else if (o.type == "key") {
                    if (a.role != "survivor")
                        continue;
                    ++data_.keys;
                }
                o.available = false;
                ++a.pickups;
                event(a.id, o.id, "pickup_" + o.type);
                c.interact = false;
                transition(a.id, State::Interacting);
                break;
            }
        }
        if (c.fire) {
            if (auto victim = actor(world, c.target);
                a.weapon && a.ammo > 0 && victim && victim->id != a.id && active(*victim) &&
                distance(a.position, victim->position) <= 6 &&
                lineOfSight(world, a.position, victim->position)) {
                transition(a.id, State::Firing, t.fireTicks, c.target);
            } else
                c.fire = false;
        } else if (c.aim)
            transition(a.id, State::Aiming, 0, c.target);
        if (!busy(b.state) && !c.aim && !c.fire) {
            if (c.move.x || c.move.z)
                transition(a.id, State::Moving);
            else if (c.interact)
                transition(a.id, State::Interacting);
            else
                transition(a.id, State::Idle);
        }
        if (busy(b.state)) {
            c.move = {};
            c.interact = false;
        }
        locomotion(a, b, c);

        if (a.role == "survivor" && data_.totalTicks % t.hungerTicks == 0) {
            b.hunger = std::max(0, b.hunger - 5);
            if (b.hunger == 0) {
                a.health = std::max(1, a.health - 5);
                event(a.id, 0, "starvation");
            }
        }
        commands.push_back(c);
    }
    for (std::size_t i = journalSize; i < data_.journal.size(); ++i)
        pending.push_back(data_.journal[i]);
    auto goal = world.goal;
    if (data_.keys < definition_.levels[data_.level].requiredKeys)
        world.goal = {-1, 0, -1};
    if (finished(world)) {
        ++world.tick;
        world.events.clear();
    } else
        stepGameplay(world, commands);
    world.goal = goal;
    auto generated = world.events;
    for (auto &e : generated) {
        data_.journal.push_back(e);
        if (e.kind == "attack" && data_.brains.count(e.actor))
            ++data_.brains.at(e.actor).shots;
    }
    world.events.insert(world.events.end(), pending.begin(), pending.end());
    for (auto &a : world.actors) {
        auto &b = data_.brains.at(a.id);
        if (!a.alive && b.state != State::Dead && b.state != State::Downed) {
            transition(a.id, State::Downed);
            b.bleed = t.bleedTicks;
            event(a.id, 0, "downed");
        }
        auto oldActor = std::find_if(generated.begin(), generated.end(), [&](auto &e) {
            return e.kind == "attack" && e.target == a.id;
        });
        if (a.alive && !a.arrived && oldActor != generated.end())
            transition(a.id, State::Stunned, 2);
        if (a.arrived && b.state != State::Extracted) {
            transition(a.id, State::Extracted);
            data_.score += 1000 + a.health;
            event(a.id, 0, "extracted");
        }
        blend(a, b, before[a.id]);
    }
    for (auto &e : world.events)
        if (e.kind == "help" && data_.brains.count(e.actor))
            ++data_.brains.at(e.actor).cooperations;
    bool remaining = false, extracted = false;
    for (auto &a : world.actors)
        if (a.role == "survivor") {
            remaining |= active(a);
            extracted |= a.arrived;
        }
    if (world.tick >= world.maxTicks) {
        data_.phase = Phase::Defeat;
        event(0, 0, "mission_timeout");
    } else if (!remaining) {
        if (extracted) {
            for (auto &member : world.actors)
                if (data_.brains.at(member.id).state == State::Downed) {
                    transition(member.id, State::Dead);
                    event(member.id, 0, "left_behind");
                }
            data_.completed.push_back(definition_.levels[data_.level].title);
            if (data_.level + 1 == int(definition_.levels.size())) {
                data_.phase = Phase::Victory;
                event(0, 0, "campaign_complete");
            } else
                enterLevel(data_.level + 1, true);
        } else {
            data_.phase = Phase::Defeat;
            event(0, 0, "no_survivors");
        }
    }
    if (data_.journal.size() > 2000)
        data_.journal.erase(data_.journal.begin(), data_.journal.end() - 2000);
}
void Campaign::restore(Data d) {
    if (d.level < 0 || d.level >= int(definition_.levels.size()) || d.totalTicks < 0 ||
        d.totalTicks > 10000000 || d.keys < 0 || d.keys > 1000 || d.world.tick < 0 ||
        d.world.tick > d.world.maxTicks || d.world.gateHold < 0 || d.world.gateHold > 1000 ||
        static_cast<unsigned>(d.phase) > 3)
        throw std::invalid_argument("invalid saved campaign progress");
    auto &expected = definition_.levels[d.level].world;
    if (d.world.map != expected.map || d.world.goal != expected.goal ||
        d.world.gatePosition != expected.gatePosition || d.world.controlA != expected.controlA ||
        d.world.controlB != expected.controlB ||
        d.world.requiredGateTicks != expected.requiredGateTicks ||
        d.world.maxTicks != expected.maxTicks || d.world.actors.size() != expected.actors.size() ||
        d.world.objects.size() != expected.objects.size() ||
        d.brains.size() != d.world.actors.size())
        throw std::invalid_argument("save does not match campaign topology");
    int collected = 0;
    for (auto &o : d.world.objects)
        if (o.type == "key" && !o.available)
            ++collected;
    if (d.keys != collected)
        throw std::invalid_argument("save key count does not match pickups");
    std::set<Id> ids;
    for (auto &a : d.world.actors) {
        if (!actor(expected, a.id) || !ids.insert(a.id).second || !d.brains.count(a.id) ||
            a.health < 0 || a.health > 100 || a.ammo < 0 || a.ammo > definition_.tuning.magazine ||
            blocked(d.world, a.position))
            throw std::invalid_argument("invalid saved actor");
        auto &b = d.brains.at(a.id);
        auto original = actor(expected, a.id);
        if (a.role != original->role || a.pathCost < 0 || a.damageReceived < 0 ||
            a.firstAttacks < 0 || a.pickups < 0 || a.arrivalTick > d.world.tick)
            throw std::invalid_argument("invalid saved actor metadata");
        if (a.alive != (a.health > 0) || (a.arrived != (b.state == State::Extracted)) ||
            ((!a.alive) != (b.state == State::Downed || b.state == State::Dead)))
            throw std::invalid_argument("saved life state is inconsistent");

        if (static_cast<unsigned>(b.state) > 11 || b.remaining < 0 || b.remaining > 10000 ||
            b.medkits < 0 || b.medkits > 10000 || b.food < 0 || b.food > 10000 || b.reserve < 0 ||
            b.reserve > 100000 || b.hunger < 0 || b.hunger > 100 || b.bleed < 0 ||
            b.bleed > 10000 || !std::isfinite(b.stamina) || b.stamina < 0 || b.stamina > 100)
            throw std::invalid_argument("invalid saved actor runtime");
        for (double x : {b.blend.idle, b.blend.walk, b.blend.run, b.blend.crouch, b.blend.aim,
                         b.blend.action, b.blend.forward, b.blend.backward, b.blend.left,
                         b.blend.right, b.blend.transition, b.blend.phase})
            if (!std::isfinite(x) || x < 0 || x > 1)
                throw std::invalid_argument("invalid blend weight");
        if (std::abs(b.blend.idle + b.blend.walk + b.blend.run + b.blend.crouch - 1) > 0.0001)
            throw std::invalid_argument("blend weights not normalized");
        for (double x :
             {b.blend.yaw, b.blend.speed, b.blend.credit, b.blend.velocityX, b.blend.velocityZ})
            if (!std::isfinite(x) || std::abs(x) > 1000)
                throw std::invalid_argument("invalid locomotion save");
        if (b.pending && !actor(d.world, b.pending))
            throw std::invalid_argument("invalid pending actor target");
        for (auto &[other, belief] : b.memory.beliefs) {
            if (!std::isfinite(belief.trust) || !std::isfinite(belief.threat) || belief.trust < 0 ||
                belief.trust > 1 || belief.threat < 0 || belief.threat > 1 ||
                belief.lastSeen > d.world.tick)
                throw std::invalid_argument("invalid social memory");
        }
        if (b.search != "astar" && b.search != "bfs" && b.search != "dfs" && b.search != "greedy")
            throw std::invalid_argument("unknown saved search");
    }
    for (std::size_t i = 0; i < d.world.objects.size(); ++i) {
        auto &a = d.world.objects[i];
        auto &b = expected.objects[i];
        if (a.id != b.id || a.type != b.type || a.position != b.position)
            throw std::invalid_argument("invalid saved object");
    }
    data_ = std::move(d);
}
} // namespace survival::game
