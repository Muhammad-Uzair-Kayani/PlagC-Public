#pragma once
#include <survival/simulation.hpp>
namespace survival::game {
enum class Phase { Playing, Paused, Victory, Defeat };
enum class State {
    Idle,
    Moving,
    Aiming,
    Firing,
    Reloading,
    Interacting,
    Healing,
    Helping,
    Stunned,
    Downed,
    Dead,
    Extracted
};
std::string name(State);
std::string name(Phase);
struct Tuning {
    double dt{0.25}, walk{3}, run{6}, crouch{1.5}, acceleration{12}, turnRate{360},
        blendSeconds{0.2};
    int magazine{6}, reloadTicks{8}, fireTicks{3}, healTicks{6}, reviveTicks{8}, bleedTicks{80},
        hungerTicks{160};
    double sprintDrain{8}, staminaRegen{5};
};
struct Blend {
    double idle{1}, walk{}, run{}, crouch{}, aim{}, action{}, forward{}, backward{}, left{},
        right{}, yaw{}, phase{}, speed{}, velocityX{}, velocityZ{}, credit{};
    std::string from{"Idle"}, to{"Idle"};
    double transition{1};
};
struct Brain {
    State state{State::Idle};
    int remaining{}, bleed{}, hunger{100}, reserve{12}, medkits{1}, food{1};
    double stamina{100};
    Id pending{};
    std::string reason{"Spawned"}, lastIntent{"Progress"};
    Blend blend;
    Memory memory;
    std::vector<Vec3> route;
    std::string search{"astar"};
    int shots{}, reloads{}, revives{}, cooperations{};
};
struct Level {
    std::string title, briefing;
    Snapshot world;
    int requiredKeys{};
    bool preferCooperation{};
};
struct Definition {
    int healBelow{65}, eatBelow{50}, rescueRange{7};
    std::map<State, std::vector<State>> transitions;
    std::map<std::string, std::string> clips;
    std::string title{"Last Light"}, fingerprint;
    Tuning tuning;
    std::vector<Level> levels;
};
struct Input {
    Command command;
    std::string action;
};
struct Data {
    Phase phase{Phase::Playing};
    std::uint32_t seed{1};
    int level{}, totalTicks{}, keys{}, score{};
    Snapshot world;
    std::map<Id, Brain> brains;
    std::vector<Event> journal;
    std::vector<std::string> completed;
};
class Campaign {
  public:
    explicit Campaign(Definition, std::uint32_t seed = 1);
    const Definition &definition() const { return definition_; }
    const Data &data() const { return data_; }
    void reset(std::uint32_t);
    void pause(bool);
    void restore(Data);
    std::vector<Observation> observations();
    void tick(const Input *human = nullptr, const std::vector<AgentIntent> &policy = {});

  private:
    Definition definition_;
    Data data_;
    void enterLevel(int, bool);
    void transition(Id, State, int = 0, Id = 0);
    void event(Id, Id, const std::string &);
    Input behaviour(Id, const Observation &);
    void locomotion(Actor &, Brain &, Command &);
    void blend(Actor &, Brain &, Vec3);
};
void validate(const Definition &);
} // namespace survival::game
