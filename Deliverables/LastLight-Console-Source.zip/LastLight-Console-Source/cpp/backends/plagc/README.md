# Engine handoff

PlagC is assumed to supply UAL, asset imports, world creation, physics and
rendering. This source package is solely the client game and text simulation.
`game::Data` supplies high-level character state, locomotion, directional
weights, gait phase, aim/action overlays and objectives for an engine consumer.
No live engine data or engine build dependency is required by the console.
