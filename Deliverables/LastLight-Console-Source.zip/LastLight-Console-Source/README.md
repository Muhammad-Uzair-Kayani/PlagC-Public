# Last Light — standalone survival console game

This source package contains the **client game only**. It does not contain or
require PlagC. Worlds, characters, inventory, state-machine transitions,
locomotion parameters and animation clip labels come from editable JSON text.
The console runs fixed simulation steps, never real-time engine data.

The complete game executable is **SurvivalConsole**. **GameRuntime** is the
separate legacy simulation/training laboratory retained for neural experiments.

## Windows: Premake first

Use your working Premake 5 executable: put `premake5.exe` beside
`GenerateProjects.bat`, or have it on PATH. For VS2026, use a Premake build
supporting the `vs2026` action. Visual Studio needs its C++ workload and Windows
SDK; Premake generates projects and does not replace the compiler.

```cmd
GenerateProjects.bat vs2026
start "" "build\premake\vs2026\SurvivalGame.sln"
```

For VS2022 substitute `vs2022`. Set **SurvivalConsole** as startup project,
select **Release | x64** and press **Ctrl+F5**. The debugger working directory
and campaign data path are configured automatically. There is no CMake step
in this workflow. GameRuntime, core_tests, scenario_tests and campaign_tests
are additional projects in the same solution.

After building, launch from this folder:

```cmd
RunGame.bat
RunGame.bat --headless
```

Other launch examples:

```cmd
RunGame.bat --script examples\demonstration.txt
RunGame.bat --trace saves\session.jsonl
RunGame.bat --load saves\campaign.json
TestGame.bat
```

Python 3.10+ is needed for these convenience launchers and neural training, but
not to play the authored campaign directly:

```cmd
build\premake\vs2026\bin\Release\SurvivalConsole.exe --content content\campaign.json
```

## Linux / CMake alternatives

```sh
premake5 gmake2
make -C build/premake/gmake2 config=release -j4
python3 scripts/run_game.py
python3 scripts/test_all.py
```

Or use CMake >=3.20 with a C++20 compiler:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j4
ctest --test-dir build -C Release --output-on-failure
./build/SurvivalConsole --content content/campaign.json
```

Windows CMake multi-configuration outputs are in `build/Release/`. A direct
GCC/Clang fallback is `python3 scripts/build.py`. No pip packages are required
for gameplay, inference, training or tests. Matplotlib is optional for plots.

## Play

Survivor **1** is yours; **2–5** make independent decisions. Commands execute
one fixed tick (default 0.25 simulated seconds) when you press Enter. Slow
movement may need multiple steps to accumulate a cell; this models acceleration
and crouched speed instead of teleporting on every input.

| Command | Effect |
|---|---|
| `w`, `a`, `s`, `d` | Walk one input step |
| `sprint d`, `crouch w` | Run with stamina cost, or crouch-walk |
| `strafe d 10` | Move while facing/aiming at actor 10 |
| Enter / `wait` | Wait one tick |
| `e` / `e 106` | Pick up reachable object, or explicitly hold a plate |
| `aim 10`, `fire 10` | Aim/fire at a valid actor; weapon, ammo, LOS and range required |
| `reload` | Start timed magazine reload from reserve |
| `use medkit`, `use food` | Heal over time, or eat carried food |
| `revive 2` | Start rescuing nearby downed survivor using one medkit |
| `offer 2` | Transfer one loaded round to a nearby survivor |
| `cancel` | Interrupt your pending action without consuming its reserved item |
| `auto 100` | Advance up to 100 ticks with everyone on autopilot |
| `step 10` | Wait ten ticks while teammates act |
| `state 2`, `blend 2` | State, timer, inventory, blend layers, gait and social memory |
| `path 7 9 astar` | Inspect a route; also bfs, dfs or greedy |
| `map`, `look`, `inventory`, `journal`, `help` | Inspect without advancing time |
| `pause`, `resume` | Freeze/resume the simulation |
| `save`, `load` | Save/load saves/campaign.json; optional path, including quoted spaces |
| `restart 42`, `quit` | Restart with a seed identifier, or exit |

`K` is a mission key, `*` a supply, `=` a pressure plate, `G` the closed gate,
`X` the chapter exit, `!` a downed survivor and `B` a scripted distractor.

Recover the keys described by each briefing and reach X. Key locations are
briefing knowledge; ordinary supplies and other actors require local perception.
Two distinct actors must explicitly hold complementary controls for consecutive
ticks; merely standing nearby cannot open the shortcut. A solo bypass exists.
Living survivors must extract or be lost before advancing to the next chapter.
Health and inventory carry over. Lost survivors stay lost; downed survivors left
behind at departure are recorded as dead. Finish all three chapters to win.
Losing the team or exceeding a chapter deadline fails the campaign. If survivor
1 is lost, you may spectate with `auto` rather than being forced to restart.

## Inspect the full game automatically

```cmd
RunGame.bat --headless --trace saves\autoplay.jsonl
```

Or run `SurvivalConsole --headless --content content/campaign.json` directly.
The output is a JSON summary. Exit code 0 means victory, 2 means defeat or the
requested tick budget ended before victory, and 1 means an input/configuration
error. The default authored team completes all three chapters, with casualties
possible. Autoplay is a demonstration of authored behaviour, not learned skill.

## Text data / engine handoff

- `content/campaign.json`: maps, spawns, objects, chapter objectives and briefings.
- `content/behaviour.json`: timed-action durations, inventory capacity, survival
  thresholds and explicit allowed character state transitions.
- `content/animation.json`: fixed dt, speed/acceleration/turn rates, crossfade
  duration and clip labels. No animation asset is imported by the console.
- `--trace FILE`: per-tick world, per-character states, beliefs, routes, timers,
  directional weights, locomotion weights and action/aim overlay weights.

See `docs/client-game.md` for ownership and algorithms. PlagC can consume these
client-owned intentions/state/blend outputs while supplying UAL, imports,
physics and rendering. The console computes animation **plans and weights**;
it does not pretend to render skeletal poses or execute an engine UAL plugin.

## Optional neural policy and genetic training

```cmd
RunGame.bat --neural
GenerateProjects.bat vs2026 --python-exe="C:\Path To Python\python.exe"
```

The included 16-16-6 champion was evolved on the legacy laboratory scenarios,
not on the new campaign. In the campaign it optionally proposes intentions;
self-care, rescue and mandatory key objectives retain priority. No learned
cooperation or guaranteed campaign performance is claimed. Python runs as a
persistent subprocess: no pybind11, Python headers, import libraries or Debug
Python build is required.

For reproducible GA training, use the separate `GameRuntime` executable:

```cmd
python python\train.py train --runtime build\premake\vs2026\bin\Release\GameRuntime.exe --population 30 --generations 10 --seed 42 --output data\training
python python\train.py evaluate --runtime build\premake\vs2026\bin\Release\GameRuntime.exe --model data\training\champion.json --output data\evaluation
```

Population checkpoints, held-out comparisons, masks and protocol failure tests
are preserved from the laboratory. The historical sample results in docs/samples
refer to that laboratory, not to the new campaign. See docs/validation.md for
this source package's measured test results and reproducibility notes.
