"""Run all client/C++/Python checks on a built Premake or CMake configuration."""
import os
from pathlib import Path
import subprocess
import sys
from run_game import ROOT, locate_runtime

def main():
    runtime = locate_runtime(sys.argv[1] if len(sys.argv)>1 else None)
    folder=runtime.parent
    os.chdir(ROOT)
    env=os.environ.copy()
    env['SURVIVAL_RUNTIME']=str(folder/('GameRuntime.exe' if os.name=='nt' else 'GameRuntime'))
    env['SURVIVAL_CONSOLE']=str(runtime)
    for name in ('core_tests','scenario_tests','campaign_tests'):
        subprocess.run([str(folder/(name+('.exe' if os.name=='nt' else '')))],check=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-s','python/tests','-v'],env=env,check=True)
    subprocess.run([str(runtime),'--headless','--content',str(ROOT/'content/campaign.json')],check=True)

if __name__=='__main__':
    main()
