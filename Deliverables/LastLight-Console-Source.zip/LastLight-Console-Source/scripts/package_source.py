"""Create the standalone source ZIP, excluding engines and generated outputs."""
import hashlib
from pathlib import Path
import sys
import zipfile
ROOT=Path(__file__).resolve().parents[1]
EXCLUDE={'build','data','models','saves','__pycache__','.git','.github'}
def package(destination):
    destination=Path(destination).resolve()
    destination.parent.mkdir(parents=True,exist_ok=True)
    manifest=[]
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file():continue
            relative=path.relative_to(ROOT)
            if any(part in EXCLUDE for part in relative.parts):continue
            if path.suffix.lower() in ('.exe','.dll','.so','.a','.o','.obj','.pdb','.pyc','.zip','.tmp'):continue
            content=path.read_bytes()
            if path.suffix.lower()=='.bat':content=content.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
            manifest.append(f'{hashlib.sha256(content).hexdigest()}  {relative.as_posix()}')
            archive.writestr('LastLight-Console-Source/'+relative.as_posix(),content)
        archive.writestr('LastLight-Console-Source/MANIFEST.sha256','\n'.join(manifest)+'\n')
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip():raise RuntimeError('Archive integrity check failed')
    print(destination)
    print(f'{len(manifest)} source/data/documentation files; {destination.stat().st_size} bytes')
if __name__=='__main__':
    package(sys.argv[1] if len(sys.argv)>1 else ROOT.parent/'LastLight-Console-Source.zip')
