import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
RUNTIME=os.environ.get('SURVIVAL_CONSOLE',str(ROOT/'build/SurvivalConsole'))
@unittest.skipUnless(Path(RUNTIME).exists(),'build SurvivalConsole first')
class CampaignConsoleTests(unittest.TestCase):
    def run_game(self,*args,**kw):
        return subprocess.run([RUNTIME,'--content',str(ROOT/'content/campaign.json'),*args],text=True,capture_output=True,timeout=25,**kw)

    def test_headless_complete_campaign(self):
        p=self.run_game('--headless',check=True)
        j=json.loads(p.stdout)
        self.assertEqual(j['phase'],'Victory')
        self.assertEqual(len(j['completed']),3)
        self.assertGreater(j['score'],0)
        self.assertTrue(any(a['arrived'] for a in j['actors']))
        self.assertTrue(all(a['state'] in ('Dead','Extracted') for a in j['actors']))

    def test_console_save_pause_trace_replay(self):
        with tempfile.TemporaryDirectory(prefix='Last Light ') as d:
            d=Path(d); save=d/'save slot.json';script=d/'commands.txt';trace=d/'trace.jsonl'
            script.write_text(f'auto 15\nstate 1\npath 7 9 bfs\nsave "{save}"\npause\nauto 2\nresume\nauto 5\nload "{save}"\nauto 5\nquit\n')
            p=self.run_game('--script',str(script),'--trace',str(trace),check=True)
            self.assertTrue(save.exists())
            self.assertNotIn('Command rejected',p.stderr)
            rows=[json.loads(line) for line in trace.read_text().splitlines()]
            self.assertEqual(rows[19],rows[24])

    def test_bad_text_input_and_content(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);script=d/'bad.txt';script.write_text('fire -1\n')
            self.assertEqual(self.run_game('--script',str(script)).returncode,1)
            config=json.loads((ROOT/'content/campaign.json').read_text())
            config['animation']=str(ROOT/'content/animation.json');config['behaviour']=str(ROOT/'content/behaviour.json')
            config['levels'][0]['world']['map'][0]='?'
            path=d/'bad.json';path.write_text(json.dumps(config))
            p=subprocess.run([RUNTIME,'--content',str(path),'--headless'],text=True,capture_output=True)
            self.assertEqual(p.returncode,1)

    def test_optional_neural_transport(self):
        p=self.run_game('--headless','--ticks','4','--python',sys.executable,'--policy-service',str(ROOT/'python/service.py'),'--model',str(ROOT/'docs/samples/champion.json'))
        self.assertEqual(p.returncode,2) # bounded run still playing, not a false win
        self.assertEqual(json.loads(p.stdout)['policy_failures'],0)
